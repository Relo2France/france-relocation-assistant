<?php
/**
 * Shortcode Template - France Relocation Assistant Chat Interface
 * 
 * Renders the main AI-powered chat interface with:
 * - Left sidebar with knowledge base categories and members area
 * - Right panel with chat messages and input
 * 
 * Usage: [france_relocation_assistant]
 * 
 * @package France_Relocation_Assistant
 * @since 2.0.0
 */

if (!defined('ABSPATH')) {
    exit;
}

// =============================================================================
// KNOWLEDGE BASE CATEGORIES
// Defines the navigation structure for the sidebar
// =============================================================================
$categories = array(
    'visas' => array(
        'icon' => '🛂',
        'label' => 'Visas & Immigration',
        'subtopics' => array(
            'overview' => 'Visa Types Overview',
            'visitor' => 'Visitor Visa (Non-Working)',
            'work' => 'Work Visa (Employment)',
            'talent' => 'Talent Passport',
            'spouse' => 'Spouse & Family Visas',
            'validation' => 'Visa Validation (OFII)',
        )
    ),
    'property' => array(
        'icon' => '🏠',
        'label' => 'Property Purchase',
        'subtopics' => array(
            'overview' => 'Buying Property Overview',
            'process' => 'Purchase Process Steps',
            'mortgage' => 'French Mortgages',
            'notaire' => 'Role of the Notaire',
            'costs' => 'Purchase Costs & Fees',
        )
    ),
    'healthcare' => array(
        'icon' => '🏥',
        'label' => 'Healthcare',
        'subtopics' => array(
            'overview' => 'Healthcare Overview',
            'puma' => 'PUMA & Carte Vitale',
            'mutuelle' => 'Mutuelle (Supplemental)',
        )
    ),
    'taxes' => array(
        'icon' => '📋',
        'label' => 'Taxes',
        'subtopics' => array(
            'overview' => 'Tax Obligations Overview',
            'residency' => '183-Day Rule',
            'fbar' => 'FBAR & FATCA',
        )
    ),
    'driving' => array(
        'icon' => '🚗',
        'label' => 'Driving',
        'subtopics' => array(
            'overview' => 'Driving Overview',
            'exchange' => 'License Exchange',
        )
    ),
    'shipping' => array(
        'icon' => '📦',
        'label' => 'Shipping & Pets',
        'subtopics' => array(
            'overview' => 'Shipping Overview',
            'pets' => 'Moving Pets',
        )
    ),
    'banking' => array(
        'icon' => '🏦',
        'label' => 'Banking',
        'subtopics' => array(
            'overview' => 'Banking Overview',
        )
    ),
    'settling' => array(
        'icon' => '🏡',
        'label' => 'Settling In',
        'subtopics' => array(
            'overview' => 'Settling In Guide',
        )
    ),
);

// =============================================================================
// QUICK TOPIC BUTTONS
// Shortcut buttons shown in the welcome screen
// =============================================================================
$quick_topics = array(
    array('cat' => 'visas', 'topic' => 'overview', 'label' => 'What visa do I need?'),
    array('cat' => 'property', 'topic' => 'overview', 'label' => 'Buying property'),
    array('cat' => 'taxes', 'topic' => 'residency', 'label' => '183-day rule'),
    array('cat' => 'healthcare', 'topic' => 'puma', 'label' => 'French healthcare'),
);

// =============================================================================
// LOAD CUSTOMIZER SETTINGS
// =============================================================================
$customizer = get_option('fra_customizer', array());

// Sidebar header settings
$header_bg           = $customizer['header_bg_color'] ?? '#1e3a5f';
$header_text         = $customizer['header_text_color'] ?? '#ffffff';
$header_title        = $customizer['header_title'] ?? 'France Relocation';
$header_subtitle     = $customizer['header_subtitle'] ?? 'US → France Guide';
$header_show_flag    = $customizer['header_show_flag'] ?? true;

// Display toggles
$show_free_badge     = $customizer['show_free_badge'] ?? true;
$show_members_preview = $customizer['show_members_preview'] ?? true;
?>

<!-- ==========================================================================
     FRANCE RELOCATION ASSISTANT - MAIN CONTAINER
     ========================================================================== -->
<div id="fra-app" class="fra-container">
    
    <!-- Mobile Header (visible on small screens only) -->
    <div class="fra-mobile-header" style="background-color: <?php echo esc_attr($header_bg); ?>; color: <?php echo esc_attr($header_text); ?>;">
        <button class="fra-mobile-menu-btn" id="fra-mobile-menu-btn" aria-label="Open menu">
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                <line x1="3" y1="6" x2="21" y2="6"></line>
                <line x1="3" y1="12" x2="21" y2="12"></line>
                <line x1="3" y1="18" x2="21" y2="18"></line>
            </svg>
        </button>
        <h1><?php echo $header_show_flag ? '🇫🇷 ' : ''; ?><?php echo esc_html($header_title); ?></h1>
        <div style="width: 40px;"></div><!-- Spacer for centering -->
    </div>
    
    <!-- Mobile Overlay (for closing sidebar) -->
    <div class="fra-mobile-overlay" id="fra-mobile-overlay"></div>
    
    <div class="fra-app">
        
        <!-- ====================================================================
             LEFT PANEL - NAVIGATION SIDEBAR
             Contains: Header, Knowledge Base categories, Members Area, Tools
             ==================================================================== -->
        <aside class="fra-nav-panel" id="fra-nav-panel">
            
            <!-- Mobile Close Button -->
            <button class="fra-mobile-close-btn" id="fra-mobile-close-btn" aria-label="Close menu">×</button>
            
            <!-- Sidebar Header -->
            <div class="fra-nav-header" style="background-color: <?php echo esc_attr($header_bg); ?>; color: <?php echo esc_attr($header_text); ?>;">
                <h1><?php echo $header_show_flag ? '🇫🇷 ' : ''; ?><?php echo esc_html($header_title); ?></h1>
                <p><?php echo esc_html($header_subtitle); ?></p>
            </div>
            
            <!-- Scrollable Content Area (Knowledge Base + Members) -->
            <div class="fra-nav-scrollable">
            
                <!-- FREE Badge Label -->
                <?php if ($show_free_badge) : ?>
                <div class="fra-section-label fra-free-section">
                    <span class="fra-free-badge">✓ FREE</span>
                    <span class="fra-section-text"><?php _e('Knowledge Base', 'france-relocation-assistant'); ?></span>
                </div>
                <?php endif; ?>
                
                <!-- Knowledge Base Navigation Menu -->
                <nav class="fra-nav-menu">
                    <?php foreach ($categories as $cat_key => $category) : ?>
                        <div class="fra-nav-category" data-category="<?php echo esc_attr($cat_key); ?>">
                            <button class="fra-category-header" data-category="<?php echo esc_attr($cat_key); ?>">
                                <span class="fra-category-left">
                                    <span class="fra-category-icon"><?php echo $category['icon']; ?></span>
                                    <span><?php echo esc_html($category['label']); ?></span>
                                </span>
                                <span class="fra-category-arrow">▶</span>
                            </button>
                            <div class="fra-subtopics" data-category="<?php echo esc_attr($cat_key); ?>">
                                <?php foreach ($category['subtopics'] as $topic_key => $topic_label) : ?>
                                    <button class="fra-subtopic-btn" 
                                            data-category="<?php echo esc_attr($cat_key); ?>" 
                                            data-topic="<?php echo esc_attr($topic_key); ?>">
                                        <?php echo esc_html($topic_label); ?>
                                    </button>
                                <?php endforeach; ?>
                            </div>
                        </div>
                    <?php endforeach; ?>
                </nav>
                <!-- /Knowledge Base Navigation Menu -->
                
                <!-- ============================================================
                     MEMBERS AREA SECTION
                     Shows member pages (unlocked for members, locked preview for non-members)
                     ============================================================ -->
                <?php
                $membership = FRA_Membership::get_instance();
                $member_settings = get_option('fra_membership', array());
                $member_pages = isset($member_settings['member_pages']) ? $member_settings['member_pages'] : array();
                $has_access = $membership->user_has_access();
                $is_enabled = $membership->is_enabled();
                
                // Only show if membership is enabled and there are member pages configured
                if ($is_enabled && !empty($member_pages)) :
                ?>
                <div class="fra-members-section">
                    <?php if ($has_access) : ?>
                    
                    <!-- MEMBER VIEW: Unlocked pages -->
                    <div class="fra-section-label fra-members-label">
                        <span class="fra-unlock-badge">🔓</span>
                        <span class="fra-section-text"><?php _e('Members Area', 'france-relocation-assistant'); ?></span>
                    </div>
                    <div class="fra-members-links">
                        <?php foreach ($member_pages as $page) : 
                            if (empty($page['title']) || empty($page['url'])) continue;
                        ?>
                            <a href="<?php echo esc_url($page['url']); ?>" class="fra-member-link">
                                <?php if (!empty($page['icon'])) : ?>
                                    <span class="fra-member-link-icon"><?php echo esc_html($page['icon']); ?></span>
                                <?php endif; ?>
                                <span><?php echo esc_html($page['title']); ?></span>
                            </a>
                        <?php endforeach; ?>
                    </div>
                    
                    <?php else : ?>
                    
                    <!-- NON-MEMBER VIEW: Locked preview + upgrade prompt -->
                    <div class="fra-section-label fra-members-label fra-locked-label">
                        <span class="fra-lock-badge">🔒</span>
                        <span class="fra-section-text"><?php _e('Members Area', 'france-relocation-assistant'); ?></span>
                    </div>
                    
                    <?php if ($show_members_preview) : ?>
                    <!-- Locked Page Preview (visible but not clickable) -->
                    <div class="fra-members-links fra-locked-links">
                        <?php foreach ($member_pages as $page) : 
                            if (empty($page['title']) || empty($page['url'])) continue;
                        ?>
                            <div class="fra-member-link fra-member-link-locked">
                                <?php if (!empty($page['icon'])) : ?>
                                    <span class="fra-member-link-icon"><?php echo esc_html($page['icon']); ?></span>
                                <?php endif; ?>
                                <span><?php echo esc_html($page['title']); ?></span>
                                <span class="fra-link-lock-icon">🔒</span>
                            </div>
                        <?php endforeach; ?>
                    </div>
                    <?php endif; ?>
                    
                    <!-- Upgrade Prompt -->
                    <div class="fra-upgrade-prompt">
                        <p><?php echo esc_html($member_settings['teaser_message'] ?? 'Get access to exclusive member resources!'); ?></p>
                        <?php if (!empty($member_settings['upgrade_url'])) : ?>
                            <a href="<?php echo esc_url($member_settings['upgrade_url']); ?>" class="fra-upgrade-btn">
                                <?php echo esc_html($member_settings['upgrade_button_text'] ?? 'Get Access'); ?>
                            </a>
                        <?php endif; ?>
                    </div>
                    
                    <?php endif; ?>
                </div>
                <?php endif; ?>
                <!-- /MEMBERS AREA SECTION -->
                
            </div>
            <!-- /Scrollable Content Area -->
            
            <!-- Tools Section (fixed at bottom) -->
            <div class="fra-nav-tools">
                <button id="fra-day-counter-btn" class="fra-tool-btn">
                    📅 183-Day Counter
                </button>
            </div>
            
        </aside>
        <!-- /LEFT PANEL -->
        
        <!-- ====================================================================
             RIGHT PANEL - CHAT INTERFACE
             Contains: Message area, Welcome screen, Chat input
             ==================================================================== -->
        <main class="fra-chat-panel">
            
            <!-- Chat Messages Container -->
            <div id="fra-chat-messages" class="fra-chat-messages">
                
                <!-- Welcome State (shown before first message) -->
                <div id="fra-welcome" class="fra-welcome">
                    <div class="fra-welcome-icon">🇫🇷</div>
                    <h2>Welcome to France Relocation Assistant</h2>
                    <p>Select a topic from the menu or ask a question below. AI-powered answers based on official French sources.</p>
                    
                    <!-- Quick Topic Buttons -->
                    <div class="fra-quick-topics">
                        <?php foreach ($quick_topics as $qt) : ?>
                            <button class="fra-quick-topic" data-category="<?php echo esc_attr($qt['cat']); ?>" data-topic="<?php echo esc_attr($qt['topic']); ?>">
                                <?php echo esc_html($qt['label']); ?>
                            </button>
                        <?php endforeach; ?>
                    </div>
                </div>
                <!-- /Welcome State -->
                
            </div>
            <!-- /Chat Messages Container -->
            
            <!-- Chat Input Area -->
            <div class="fra-chat-input-area">
                <div class="fra-chat-input-wrapper">
                    <textarea 
                        id="fra-chat-input" 
                        class="fra-chat-input" 
                        placeholder="Ask AI about relocating to France..."
                        rows="1"
                    ></textarea>
                    <button id="fra-chat-send" class="fra-chat-send" aria-label="Send">
                        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                            <path d="M22 2L11 13M22 2l-7 20-4-9-9-4 20-7z"/>
                        </svg>
                    </button>
                </div>
                <div class="fra-input-footer">
                    <div class="fra-input-hint">
                        AI answers powered by Claude • Information from official French sources
                    </div>
                    <!-- Help Icon - Opens prompting tips -->
                    <button id="fra-help-btn" class="fra-help-btn" aria-label="Tips for asking questions">
                        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" width="16" height="16">
                            <circle cx="12" cy="12" r="10"/>
                            <path d="M9.09 9a3 3 0 0 1 5.83 1c0 2-3 3-3 3"/>
                            <line x1="12" y1="17" x2="12.01" y2="17"/>
                        </svg>
                    </button>
                </div>
            </div>
            <!-- /Chat Input Area -->
            
        </main>
        <!-- /RIGHT PANEL -->
        
    </div>
</div>
<!-- /FRANCE RELOCATION ASSISTANT -->


<!-- ==========================================================================
     PROMPTING TIPS MODAL
     Helps users understand how to ask better questions
     ========================================================================== -->
<div id="fra-help-modal" class="fra-modal-overlay fra-help-modal-overlay">
    <div class="fra-modal fra-help-modal">
        
        <!-- Modal Header -->
        <div class="fra-modal-header fra-help-modal-header">
            <h3>💡 Tips for Better Answers</h3>
            <button id="fra-close-help-modal" class="fra-close-btn">×</button>
        </div>
        
        <div class="fra-modal-content fra-help-modal-content">
            
            <p class="fra-help-intro">
                Getting the most helpful answers depends on how you ask your questions. Here are some tips to get better results:
            </p>
            
            <!-- Tip 1 -->
            <div class="fra-help-tip">
                <div class="fra-help-tip-header">
                    <span class="fra-help-tip-icon">🎯</span>
                    <strong>Be specific about your situation</strong>
                </div>
                <p>Include relevant details like your nationality, visa type, timeline, or location in France.</p>
                <div class="fra-help-example">
                    <span class="fra-example-label">Example:</span>
                    <em>"I'm a US citizen planning to buy property in Dordogne. What taxes will I pay as a non-resident?"</em>
                </div>
            </div>
            
            <!-- Tip 2 -->
            <div class="fra-help-tip">
                <div class="fra-help-tip-header">
                    <span class="fra-help-tip-icon">📋</span>
                    <strong>Ask one question at a time</strong>
                </div>
                <p>Break complex topics into focused questions for clearer, more detailed answers.</p>
                <div class="fra-help-example">
                    <span class="fra-example-label">Instead of:</span>
                    <em>"Tell me everything about moving to France"</em>
                    <br>
                    <span class="fra-example-label fra-example-better">Try:</span>
                    <em>"What are the steps to get a long-stay visitor visa?"</em>
                </div>
            </div>
            
            <!-- Tip 3 -->
            <div class="fra-help-tip">
                <div class="fra-help-tip-header">
                    <span class="fra-help-tip-icon">🔍</span>
                    <strong>Mention what you already know</strong>
                </div>
                <p>This helps avoid repeating basics and gets you more advanced information.</p>
                <div class="fra-help-example">
                    <span class="fra-example-label">Example:</span>
                    <em>"I know I need to validate my visa with OFII. What documents should I prepare for the appointment?"</em>
                </div>
            </div>
            
            <!-- Tip 4 -->
            <div class="fra-help-tip">
                <div class="fra-help-tip-header">
                    <span class="fra-help-tip-icon">📅</span>
                    <strong>Include your timeline</strong>
                </div>
                <p>Deadlines and dates help prioritize what's most urgent for your situation.</p>
                <div class="fra-help-example">
                    <span class="fra-example-label">Example:</span>
                    <em>"I'm closing on a property in February. What do I need to have ready before then?"</em>
                </div>
            </div>
            
            <!-- Quick Start Topics -->
            <div class="fra-help-quickstart">
                <h4>Popular Topics to Explore</h4>
                <div class="fra-help-topics">
                    <button class="fra-help-topic-btn" data-question="What visa do I need to live in France as a US citizen?">Visa options</button>
                    <button class="fra-help-topic-btn" data-question="What are the steps to buy property in France?">Buying property</button>
                    <button class="fra-help-topic-btn" data-question="How does the 183-day tax residency rule work?">Tax residency</button>
                    <button class="fra-help-topic-btn" data-question="How do I get healthcare coverage in France?">Healthcare</button>
                    <button class="fra-help-topic-btn" data-question="How do I exchange my US driver's license for a French one?">Driver's license</button>
                </div>
            </div>
            
        </div>
    </div>
</div>
<!-- /PROMPTING TIPS MODAL -->
<div id="fra-day-counter-modal" class="fra-modal-overlay">
    <div class="fra-modal">
        
        <!-- Modal Header -->
        <div class="fra-modal-header">
            <h3>📅 183-Day Tax Residency Tracker</h3>
            <button id="fra-close-modal" class="fra-close-btn">×</button>
        </div>
        
        <div class="fra-modal-content">
            
            <!-- Status Message (OK/Warning/Danger) -->
            <div id="fra-status-message" class="fra-status-message fra-status-ok">
                <strong>✓ OK:</strong> Add trips to start tracking.
            </div>
            
            <!-- Progress Bar (Rolling 183-Day Window) -->
            <div class="fra-progress-container">
                <div class="fra-progress-labels">
                    <span>Rolling 183-Day Window</span>
                    <span><span id="fra-rolling-used">0</span> / 183 days in France</span>
                </div>
                <div class="fra-progress-track">
                    <div id="fra-progress-bar" class="fra-progress-bar" style="width: 0%;"></div>
                </div>
            </div>
            
            <!-- Day Statistics by Location -->
            <div class="fra-dc-stats">
                <div class="fra-dc-stat fra-stat-france">
                    <span id="fra-stat-france" class="fra-stat-number">0</span>
                    <span class="fra-stat-label">🇫🇷 France</span>
                </div>
                <div class="fra-dc-stat fra-stat-us">
                    <span id="fra-stat-us" class="fra-stat-number">0</span>
                    <span class="fra-stat-label">🇺🇸 US</span>
                </div>
                <div class="fra-dc-stat fra-stat-other">
                    <span id="fra-stat-other" class="fra-stat-number">0</span>
                    <span class="fra-stat-label">🌍 Other</span>
                </div>
                <div class="fra-dc-stat">
                    <span id="fra-stat-untracked" class="fra-stat-number">0</span>
                    <span class="fra-stat-label">Untracked</span>
                </div>
            </div>
            
            <!-- Calendar Year Navigation -->
            <div class="fra-calendar-nav">
                <button id="fra-prev-year" class="fra-nav-btn">◀ Prev</button>
                <span id="fra-current-year" class="fra-year-label">2025</span>
                <button id="fra-next-year" class="fra-nav-btn">Next ▶</button>
            </div>
            
            <!-- Calendar Grid (populated by JavaScript) -->
            <div id="fra-calendar-grid" class="fra-calendar-grid"></div>
            
            <!-- Calendar Legend -->
            <div class="fra-calendar-legend">
                <span class="fra-legend-item"><span class="fra-legend-color fra-legend-france"></span> France</span>
                <span class="fra-legend-item"><span class="fra-legend-color fra-legend-us"></span> US</span>
                <span class="fra-legend-item"><span class="fra-legend-color fra-legend-other"></span> Other</span>
                <span class="fra-legend-item"><span class="fra-legend-color fra-legend-today"></span> Today</span>
            </div>
            
            <!-- Add Trip Button -->
            <div class="fra-add-trip-section">
                <button id="fra-add-trip-btn" class="fra-btn-primary">+ Add Trip</button>
            </div>
            
            <!-- Add Trip Form (hidden by default) -->
            <div id="fra-add-trip-form" class="fra-add-trip-form">
                <h4>Add New Trip</h4>
                <div class="fra-form-row">
                    <div class="fra-form-group">
                        <label for="fra-trip-start">Start Date</label>
                        <input type="date" id="fra-trip-start" required>
                    </div>
                    <div class="fra-form-group">
                        <label for="fra-trip-end">End Date</label>
                        <input type="date" id="fra-trip-end" required>
                    </div>
                    <div class="fra-form-group">
                        <label for="fra-trip-location">Location</label>
                        <select id="fra-trip-location">
                            <option value="france">🇫🇷 France</option>
                            <option value="us">🇺🇸 United States</option>
                            <option value="other">🌍 Other</option>
                        </select>
                    </div>
                </div>
                <div class="fra-form-group fra-form-full">
                    <label for="fra-trip-notes">Notes (optional)</label>
                    <input type="text" id="fra-trip-notes" placeholder="e.g., Business trip to Paris">
                </div>
                <div class="fra-form-actions">
                    <button id="fra-save-trip" class="fra-btn-primary">Save Trip</button>
                    <button id="fra-cancel-trip" class="fra-btn-secondary">Cancel</button>
                </div>
            </div>
            
            <!-- Trip List -->
            <div class="fra-trip-list-section">
                <h4>Recorded Trips</h4>
                <div id="fra-trip-list" class="fra-trip-list"></div>
            </div>
            
            <!-- Data Import/Export -->
            <div class="fra-data-management">
                <button id="fra-export-data" class="fra-btn-secondary">Export</button>
                <label class="fra-btn-secondary fra-import-label">
                    Import
                    <input type="file" id="fra-import-data" accept=".json" style="display:none;">
                </label>
                <button id="fra-clear-all-data" class="fra-btn-danger">Clear All</button>
            </div>
            
            <!-- Disclaimer -->
            <p class="fra-dc-disclaimer">
                <strong>Note:</strong> This tool is for personal tracking only. French tax residency depends on multiple factors. Consult a tax professional.
            </p>
            
        </div>
    </div>
</div>
<!-- /183-DAY TAX RESIDENCY TRACKER MODAL -->
