<?php
/**
 * AI Review Admin Page
 * 
 * @package France_Relocation_Assistant
 */

if (!defined('ABSPATH')) {
    exit;
}

$ai_review = FRA_AI_Review::get_instance();
$pending_reviews = $ai_review->get_pending_reviews();
$review_history = get_option('fra_review_history', array());
$api_key_configured = !empty(get_option('fra_api_key', ''));
?>

<div class="wrap fra-admin-wrap">
    <h1>
        <span class="dashicons dashicons-superhero"></span>
        <?php _e('AI Knowledge Base Review', 'france-relocation-assistant'); ?>
    </h1>
    
    <div class="fra-admin-header">
        <p class="fra-description">
            <?php _e('Use AI to automatically verify and update your knowledge base. Claude will check current values against official sources and suggest updates.', 'france-relocation-assistant'); ?>
        </p>
    </div>
    
    <?php if (!$api_key_configured): ?>
    <div class="notice notice-error">
        <p>
            <strong><?php _e('API Key Required', 'france-relocation-assistant'); ?></strong><br>
            <?php _e('Please configure your Claude API key in', 'france-relocation-assistant'); ?>
            <a href="<?php echo admin_url('admin.php?page=france-relocation-assistant-settings'); ?>"><?php _e('Settings', 'france-relocation-assistant'); ?></a>
            <?php _e('before using AI Review.', 'france-relocation-assistant'); ?>
        </p>
    </div>
    <?php endif; ?>
    
    <div class="fra-review-grid">
        <!-- Start Review Card -->
        <div class="fra-card fra-card-highlight">
            <h2><?php _e('🔍 Start AI Review', 'france-relocation-assistant'); ?></h2>
            
            <p><?php _e('Claude will verify all data points that may change over time, including:', 'france-relocation-assistant'); ?></p>
            
            <ul class="fra-check-list">
                <li>✓ <?php _e('Visa fees and requirements', 'france-relocation-assistant'); ?></li>
                <li>✓ <?php _e('OFII validation tax amounts', 'france-relocation-assistant'); ?></li>
                <li>✓ <?php _e('Income thresholds (SMIC-based)', 'france-relocation-assistant'); ?></li>
                <li>✓ <?php _e('Notaire fees and property costs', 'france-relocation-assistant'); ?></li>
                <li>✓ <?php _e('Healthcare costs and thresholds', 'france-relocation-assistant'); ?></li>
                <li>✓ <?php _e('FBAR/FATCA reporting limits', 'france-relocation-assistant'); ?></li>
                <li>✓ <?php _e('License exchange fees', 'france-relocation-assistant'); ?></li>
            </ul>
            
            <div class="fra-review-actions">
                <button type="button" id="fra-start-review" class="button button-primary button-hero" <?php echo !$api_key_configured ? 'disabled' : ''; ?>>
                    <span class="dashicons dashicons-search" style="margin-top: 5px;"></span>
                    <?php _e('Start AI Review', 'france-relocation-assistant'); ?>
                </button>
                <div id="fra-review-progress" style="display: none; margin-top: 15px;">
                    <span class="spinner is-active" style="float: none;"></span>
                    <span id="fra-review-status-text"><?php _e('Starting review...', 'france-relocation-assistant'); ?></span>
                </div>
            </div>
        </div>
        
        <!-- Review History Card -->
        <div class="fra-card">
            <h2><?php _e('📊 Review History', 'france-relocation-assistant'); ?></h2>
            
            <?php if (empty($review_history)): ?>
            <p class="fra-empty-state"><?php _e('No reviews yet. Start your first AI review to see history.', 'france-relocation-assistant'); ?></p>
            <?php else: ?>
            <table class="fra-history-table">
                <thead>
                    <tr>
                        <th><?php _e('Date', 'france-relocation-assistant'); ?></th>
                        <th><?php _e('Checked', 'france-relocation-assistant'); ?></th>
                        <th><?php _e('Verified', 'france-relocation-assistant'); ?></th>
                        <th><?php _e('Changes', 'france-relocation-assistant'); ?></th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach (array_reverse($review_history) as $entry): ?>
                    <tr>
                        <td><?php echo date_i18n(get_option('date_format') . ' ' . get_option('time_format'), $entry['timestamp']); ?></td>
                        <td><?php echo intval($entry['total_checked']); ?></td>
                        <td><span class="fra-badge fra-badge-success"><?php echo intval($entry['verified']); ?></span></td>
                        <td>
                            <?php if ($entry['changes_found'] > 0): ?>
                            <span class="fra-badge fra-badge-warning"><?php echo intval($entry['changes_found']); ?></span>
                            <?php else: ?>
                            <span class="fra-badge fra-badge-muted">0</span>
                            <?php endif; ?>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
            <?php endif; ?>
        </div>
    </div>
    
    <!-- Pending Reviews Section -->
    <div class="fra-card fra-card-full" style="margin-top: 20px;">
        <div class="fra-card-header">
            <h2>
                <?php _e('📝 Pending Reviews', 'france-relocation-assistant'); ?>
                <?php if (!empty($pending_reviews)): ?>
                <span class="fra-count-badge"><?php echo count($pending_reviews); ?></span>
                <?php endif; ?>
            </h2>
            
            <?php if (!empty($pending_reviews)): ?>
            <div class="fra-bulk-actions">
                <button type="button" id="fra-approve-all" class="button button-primary">
                    <?php _e('✓ Approve All', 'france-relocation-assistant'); ?>
                </button>
                <button type="button" id="fra-reject-all" class="button">
                    <?php _e('✗ Reject All', 'france-relocation-assistant'); ?>
                </button>
            </div>
            <?php endif; ?>
        </div>
        
        <div id="fra-pending-reviews-container">
            <?php if (empty($pending_reviews)): ?>
            <div class="fra-empty-state">
                <span class="dashicons dashicons-yes-alt" style="font-size: 48px; color: #00a32a;"></span>
                <p><?php _e('No pending reviews. Your knowledge base is up to date!', 'france-relocation-assistant'); ?></p>
            </div>
            <?php else: ?>
            <div class="fra-reviews-list">
                <?php foreach ($pending_reviews as $review): ?>
                <div class="fra-review-item" data-review-id="<?php echo esc_attr($review['id']); ?>">
                    <div class="fra-review-header">
                        <div class="fra-review-label">
                            <span class="fra-review-category"><?php echo esc_html(ucfirst($review['category'])); ?> → <?php echo esc_html(ucfirst($review['topic'])); ?></span>
                            <h4><?php echo esc_html($review['label']); ?></h4>
                        </div>
                        <div class="fra-review-status">
                            <?php if ($review['status'] === 'needs_update'): ?>
                            <span class="fra-status-badge fra-status-update"><?php _e('Update Found', 'france-relocation-assistant'); ?></span>
                            <?php elseif ($review['status'] === 'uncertain'): ?>
                            <span class="fra-status-badge fra-status-uncertain"><?php _e('Uncertain', 'france-relocation-assistant'); ?></span>
                            <?php endif; ?>
                        </div>
                    </div>
                    
                    <div class="fra-review-comparison">
                        <div class="fra-review-current">
                            <span class="fra-label"><?php _e('Current', 'france-relocation-assistant'); ?></span>
                            <div class="fra-value fra-value-old"><?php echo esc_html($review['current_value']); ?></div>
                        </div>
                        
                        <?php if ($review['status'] === 'needs_update' && isset($review['suggested_value'])): ?>
                        <div class="fra-review-arrow">→</div>
                        <div class="fra-review-suggested">
                            <span class="fra-label"><?php _e('Suggested', 'france-relocation-assistant'); ?></span>
                            <div class="fra-value fra-value-new"><?php echo esc_html($review['suggested_value']); ?></div>
                        </div>
                        <?php endif; ?>
                    </div>
                    
                    <?php if (!empty($review['explanation'])): ?>
                    <div class="fra-review-explanation">
                        <strong><?php _e('Explanation:', 'france-relocation-assistant'); ?></strong>
                        <?php echo esc_html($review['explanation']); ?>
                    </div>
                    <?php endif; ?>
                    
                    <?php if (!empty($review['source'])): ?>
                    <div class="fra-review-source">
                        <strong><?php _e('Source:', 'france-relocation-assistant'); ?></strong>
                        <?php echo esc_html($review['source']); ?>
                    </div>
                    <?php endif; ?>
                    
                    <div class="fra-review-actions-row">
                        <?php if ($review['status'] === 'needs_update'): ?>
                        <button type="button" class="button button-primary fra-approve-btn" data-id="<?php echo esc_attr($review['id']); ?>">
                            <?php _e('✓ Approve Change', 'france-relocation-assistant'); ?>
                        </button>
                        <?php endif; ?>
                        <button type="button" class="button fra-reject-btn" data-id="<?php echo esc_attr($review['id']); ?>">
                            <?php _e('✗ Dismiss', 'france-relocation-assistant'); ?>
                        </button>
                    </div>
                </div>
                <?php endforeach; ?>
            </div>
            <?php endif; ?>
        </div>
    </div>
</div>

<style>
.fra-review-grid {
    display: grid;
    grid-template-columns: 1fr 1fr;
    gap: 20px;
    margin-top: 20px;
}
@media (max-width: 1200px) {
    .fra-review-grid { grid-template-columns: 1fr; }
}

.fra-card {
    background: #fff;
    border: 1px solid #ddd;
    border-radius: 8px;
    padding: 20px;
}
.fra-card h2 {
    margin: 0 0 15px 0;
    padding: 0;
    border: 0;
    font-size: 16px;
    display: flex;
    align-items: center;
    gap: 10px;
}
.fra-card-highlight {
    border-left: 4px solid #ff6b00;
}
.fra-card-full {
    grid-column: 1 / -1;
}
.fra-card-header {
    display: flex;
    justify-content: space-between;
    align-items: center;
    margin-bottom: 20px;
    flex-wrap: wrap;
    gap: 10px;
}
.fra-card-header h2 {
    margin: 0;
}

.fra-check-list {
    list-style: none;
    margin: 15px 0;
    padding: 0;
}
.fra-check-list li {
    padding: 5px 0;
    color: #555;
}

.fra-review-actions {
    margin-top: 20px;
}

.fra-count-badge {
    display: inline-flex;
    align-items: center;
    justify-content: center;
    min-width: 24px;
    height: 24px;
    padding: 0 8px;
    background: #ff6b00;
    color: white;
    border-radius: 12px;
    font-size: 13px;
    font-weight: 600;
}

.fra-history-table {
    width: 100%;
    border-collapse: collapse;
}
.fra-history-table th,
.fra-history-table td {
    padding: 10px;
    text-align: left;
    border-bottom: 1px solid #eee;
}
.fra-history-table th {
    font-weight: 600;
    color: #444;
}

.fra-badge {
    display: inline-block;
    padding: 3px 10px;
    border-radius: 10px;
    font-size: 12px;
    font-weight: 500;
}
.fra-badge-success { background: #dcfce7; color: #15803d; }
.fra-badge-warning { background: #fef3c7; color: #b45309; }
.fra-badge-muted { background: #f3f4f6; color: #6b7280; }

.fra-empty-state {
    text-align: center;
    padding: 40px;
    color: #666;
}

.fra-reviews-list {
    display: flex;
    flex-direction: column;
    gap: 15px;
}

.fra-review-item {
    border: 1px solid #e5e7eb;
    border-radius: 8px;
    padding: 20px;
    background: #fafafa;
}
.fra-review-item:hover {
    border-color: #d1d5db;
}

.fra-review-header {
    display: flex;
    justify-content: space-between;
    align-items: flex-start;
    margin-bottom: 15px;
}
.fra-review-category {
    font-size: 12px;
    color: #666;
    text-transform: uppercase;
    letter-spacing: 0.5px;
}
.fra-review-label h4 {
    margin: 5px 0 0 0;
    font-size: 15px;
}

.fra-status-badge {
    padding: 4px 12px;
    border-radius: 4px;
    font-size: 12px;
    font-weight: 500;
}
.fra-status-update {
    background: #fef3c7;
    color: #b45309;
}
.fra-status-uncertain {
    background: #e0f2fe;
    color: #0369a1;
}

.fra-review-comparison {
    display: flex;
    align-items: center;
    gap: 20px;
    margin: 15px 0;
    flex-wrap: wrap;
}
.fra-review-current,
.fra-review-suggested {
    flex: 1;
    min-width: 150px;
}
.fra-label {
    display: block;
    font-size: 11px;
    text-transform: uppercase;
    color: #888;
    margin-bottom: 5px;
}
.fra-value {
    padding: 12px 15px;
    border-radius: 6px;
    font-size: 16px;
    font-weight: 600;
}
.fra-value-old {
    background: #fee2e2;
    color: #b91c1c;
    text-decoration: line-through;
}
.fra-value-new {
    background: #dcfce7;
    color: #15803d;
}
.fra-review-arrow {
    font-size: 24px;
    color: #999;
}

.fra-review-explanation,
.fra-review-source {
    margin: 10px 0;
    padding: 10px;
    background: #fff;
    border-radius: 4px;
    font-size: 13px;
    color: #555;
}

.fra-review-actions-row {
    display: flex;
    gap: 10px;
    margin-top: 15px;
    padding-top: 15px;
    border-top: 1px solid #e5e7eb;
}

.fra-bulk-actions {
    display: flex;
    gap: 10px;
}
</style>

<script>
jQuery(document).ready(function($) {
    var nonce = '<?php echo wp_create_nonce('fra_admin_nonce'); ?>';
    
    // Start AI Review
    $('#fra-start-review').on('click', function() {
        var $btn = $(this);
        var $progress = $('#fra-review-progress');
        var $statusText = $('#fra-review-status-text');
        
        $btn.prop('disabled', true);
        $progress.show();
        $statusText.text('<?php _e('Connecting to Claude AI...', 'france-relocation-assistant'); ?>');
        
        $.ajax({
            url: ajaxurl,
            type: 'POST',
            data: {
                action: 'fra_start_ai_review',
                nonce: nonce
            },
            success: function(response) {
                $progress.hide();
                $btn.prop('disabled', false);
                
                if (response.success) {
                    var data = response.data;
                    var msg = '<?php _e('Review complete!', 'france-relocation-assistant'); ?> ';
                    msg += data.verified + ' <?php _e('verified', 'france-relocation-assistant'); ?>, ';
                    msg += data.changes_found + ' <?php _e('changes found', 'france-relocation-assistant'); ?>';
                    
                    alert(msg);
                    location.reload();
                } else {
                    alert('<?php _e('Error:', 'france-relocation-assistant'); ?> ' + response.data);
                }
            },
            error: function() {
                $progress.hide();
                $btn.prop('disabled', false);
                alert('<?php _e('Connection error. Please try again.', 'france-relocation-assistant'); ?>');
            }
        });
    });
    
    // Approve single change
    $(document).on('click', '.fra-approve-btn', function() {
        var $btn = $(this);
        var reviewId = $btn.data('id');
        var $item = $btn.closest('.fra-review-item');
        
        $btn.prop('disabled', true).text('<?php _e('Applying...', 'france-relocation-assistant'); ?>');
        
        $.ajax({
            url: ajaxurl,
            type: 'POST',
            data: {
                action: 'fra_approve_change',
                nonce: nonce,
                review_id: reviewId
            },
            success: function(response) {
                if (response.success) {
                    $item.slideUp(300, function() {
                        $(this).remove();
                        updatePendingCount();
                    });
                } else {
                    alert('<?php _e('Error:', 'france-relocation-assistant'); ?> ' + response.data);
                    $btn.prop('disabled', false).text('<?php _e('✓ Approve Change', 'france-relocation-assistant'); ?>');
                }
            },
            error: function() {
                alert('<?php _e('Connection error', 'france-relocation-assistant'); ?>');
                $btn.prop('disabled', false).text('<?php _e('✓ Approve Change', 'france-relocation-assistant'); ?>');
            }
        });
    });
    
    // Reject single change
    $(document).on('click', '.fra-reject-btn', function() {
        var $btn = $(this);
        var reviewId = $btn.data('id');
        var $item = $btn.closest('.fra-review-item');
        
        $item.slideUp(300, function() {
            $(this).remove();
            updatePendingCount();
        });
        
        $.ajax({
            url: ajaxurl,
            type: 'POST',
            data: {
                action: 'fra_reject_change',
                nonce: nonce,
                review_id: reviewId
            }
        });
    });
    
    // Approve all
    $('#fra-approve-all').on('click', function() {
        if (!confirm('<?php _e('Apply all pending changes to your knowledge base?', 'france-relocation-assistant'); ?>')) return;
        
        var $btn = $(this);
        $btn.prop('disabled', true).text('<?php _e('Applying...', 'france-relocation-assistant'); ?>');
        
        $.ajax({
            url: ajaxurl,
            type: 'POST',
            data: {
                action: 'fra_approve_all',
                nonce: nonce
            },
            success: function(response) {
                if (response.success) {
                    location.reload();
                } else {
                    alert('<?php _e('Error:', 'france-relocation-assistant'); ?> ' + response.data);
                    $btn.prop('disabled', false).text('<?php _e('✓ Approve All', 'france-relocation-assistant'); ?>');
                }
            }
        });
    });
    
    // Reject all
    $('#fra-reject-all').on('click', function() {
        if (!confirm('<?php _e('Dismiss all pending changes?', 'france-relocation-assistant'); ?>')) return;
        
        $.ajax({
            url: ajaxurl,
            type: 'POST',
            data: {
                action: 'fra_reject_all',
                nonce: nonce
            },
            success: function(response) {
                location.reload();
            }
        });
    });
    
    function updatePendingCount() {
        var count = $('.fra-review-item').length;
        if (count === 0) {
            $('#fra-pending-reviews-container').html(
                '<div class="fra-empty-state">' +
                '<span class="dashicons dashicons-yes-alt" style="font-size: 48px; color: #00a32a;"></span>' +
                '<p><?php _e('No pending reviews. Your knowledge base is up to date!', 'france-relocation-assistant'); ?></p>' +
                '</div>'
            );
            $('.fra-bulk-actions').hide();
            $('.fra-count-badge').remove();
        } else {
            $('.fra-count-badge').text(count);
        }
    }
});
</script>
