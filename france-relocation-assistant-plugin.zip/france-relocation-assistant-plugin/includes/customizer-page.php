<?php
/**
 * Front-End Customizer Page - Enhanced Version
 * 
 * @package France_Relocation_Assistant
 */

if (!defined('ABSPATH')) {
    exit;
}

// Get current customization settings
$defaults = array(
    // Header Section
    'header_bg_color' => '#1e3a5f',
    'header_text_color' => '#ffffff',
    'header_title' => 'France Relocation',
    'header_subtitle' => 'US → France Guide',
    'header_show_flag' => true,
    
    // Main Colors
    'color_primary' => '#1a1a1a',
    'color_accent' => '#ff6b00',
    'color_background' => '#f5f5f5',
    'color_card' => '#ffffff',
    'color_text' => '#1a1a1a',
    'color_text_light' => '#666666',
    'color_border' => '#e0e0e0',
    
    // Navigation Colors
    'color_nav_bg' => '#ffffff',
    'color_nav_text' => '#1a1a1a',
    'color_nav_hover' => '#ff6b00',
    'color_nav_active_bg' => '#fff7ed',
    
    // Chat Area Colors
    'color_chat_bg' => '#f9fafb',
    'color_chat_input_bg' => '#ffffff',
    'color_chat_input_border' => '#e5e7eb',
    'color_user_msg_bg' => '#f3f4f6',
    'color_ai_msg_bg' => '#ffffff',
    'color_ai_header_bg' => '#f9fafb',
    
    // Button Colors
    'color_btn_primary_bg' => '#ff6b00',
    'color_btn_primary_text' => '#ffffff',
    'color_btn_secondary_bg' => '#f3f4f6',
    'color_btn_secondary_text' => '#374151',
    'color_send_btn_bg' => '#ff6b00',
    'color_send_btn_text' => '#ffffff',
    
    // Status Colors
    'color_success' => '#2e7d32',
    'color_warning' => '#e65100',
    'color_danger' => '#c62828',
    
    // Day Counter Colors
    'color_france' => '#0055A4',
    'color_us' => '#B22234',
    'color_other' => '#666666',
    
    // Welcome Screen
    'welcome_icon' => '🇫🇷',
    'welcome_title' => 'Welcome to France Relocation Assistant',
    'welcome_subtitle' => 'Select a topic from the menu or ask a question below. AI-powered answers based on official French sources.',
    'show_quick_topics' => true,
    
    // Sidebar Display Options
    'show_free_badge' => true,
    'show_members_preview' => true,
    
    // Quick Topic Buttons
    'quick_topic_1_label' => '📋 Visa Requirements',
    'quick_topic_1_cat' => 'visas',
    'quick_topic_1_topic' => 'overview',
    'quick_topic_2_label' => '🏠 Buying Property',
    'quick_topic_2_cat' => 'property',
    'quick_topic_2_topic' => 'overview',
    'quick_topic_3_label' => '🏥 Healthcare',
    'quick_topic_3_cat' => 'healthcare',
    'quick_topic_3_topic' => 'overview',
    'quick_topic_4_label' => '📅 183-Day Counter',
    'quick_topic_4_cat' => '_day_counter',
    'quick_topic_4_topic' => '',
    
    // Site Header (WordPress Theme Header)
    'site_header_enabled' => false,
    'site_header_max_width' => '1280',
    'site_header_logo' => '',
    'site_header_logo_size' => '200',
    'site_header_logo_bg_color' => '#ffffff',
    'site_header_site_name' => 'Relo2France',
    'site_header_tagline' => 'Your Relocation Guide from the US to France, in one easy to use site.',
    'site_header_description' => 'Updated daily.',
    'site_header_bg_color' => '#1e3a8a',
    'site_header_utility_bg_color' => '#172554',
    'site_header_text_color' => '#ffffff',
    'site_header_nav_link_color' => '#ffffff',
    'site_header_utility_text' => 'Your complete guide to relocating to France',
    'site_header_cta_text' => 'Get Lifetime Access',
    'site_header_cta_url' => '/membership/',
    'site_header_cta_color' => '#f97316',
    'site_header_login_text' => 'Login',
    'site_header_login_url' => '/login/',
    'site_header_contact_text' => 'Contact',
    'site_header_contact_url' => '/contact/',
    'site_header_nav_items' => 'Guide,Visa,Property,Taxes,Tools',
    'site_header_nav_urls' => '/guide/,/visa/,/property/,/taxes/,/tools/',
    'site_header_hide_theme_header' => false,
    
    // Chat Input
    'chat_placeholder' => 'Ask AI about relocating to France...',
    'chat_hint' => 'AI answers powered by Claude • Information from official French sources',
    
    // Navigation Categories
    'nav_cat_visas' => '📋 Visas & Immigration',
    'nav_cat_property' => '🏠 Property Purchase',
    'nav_cat_healthcare' => '🏥 Healthcare',
    'nav_cat_taxes' => '💰 Taxes',
    'nav_cat_driving' => '🚗 Driving',
    'nav_cat_shipping' => '📦 Shipping & Pets',
    'nav_cat_banking' => '🏦 Banking',
    'nav_cat_settling' => '✅ Settling In',
    
    // Layout
    'max_width' => '1680',
    'min_height' => '850',
    'max_height' => '1200',
    'border_radius' => '12',
    'nav_width' => '280',
    
    // Typography
    'font_family' => '-apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif',
    'font_size_base' => '14',
    'font_size_title' => '18',
    
    // Toolbar
    'show_day_counter_btn' => true,
    'show_search_bar' => true,
    'search_placeholder' => 'Search topics...',
);

$settings = get_option('fra_customizer', array());
$settings = wp_parse_args($settings, $defaults);

// Handle form submission
if (isset($_POST['fra_save_customizer']) && check_admin_referer('fra_customizer_nonce')) {
    $new_settings = array();
    
    // Define which fields are checkboxes (booleans)
    $checkbox_fields = array(
        'header_show_flag',
        'show_quick_topics',
        'show_day_counter_btn',
        'show_search_bar',
        'site_header_enabled',
        'site_header_hide_theme_header',
        'show_free_badge',
        'show_members_preview',
    );
    
    // Define color fields explicitly
    $color_fields = array(
        'header_bg_color',
        'header_text_color',
        'color_primary',
        'color_accent',
        'color_background',
        'color_card',
        'color_text',
        'color_text_light',
        'color_border',
        'color_nav_bg',
        'color_nav_text',
        'color_nav_hover',
        'color_nav_active_bg',
        'color_chat_bg',
        'color_chat_input_bg',
        'color_chat_input_border',
        'color_user_msg_bg',
        'color_ai_msg_bg',
        'color_ai_header_bg',
        'color_btn_primary_bg',
        'color_btn_primary_text',
        'color_btn_secondary_bg',
        'color_btn_secondary_text',
        'color_send_btn_bg',
        'color_send_btn_text',
        'color_success',
        'color_warning',
        'color_danger',
        'color_france',
        'color_us',
        'color_other',
        'site_header_bg_color',
        'site_header_utility_bg_color',
        'site_header_text_color',
        'site_header_cta_color',
        'site_header_logo_bg_color',
        'site_header_nav_link_color',
    );
    
    // Process all fields
    foreach ($defaults as $key => $default) {
        // Check if it's a checkbox field
        if (in_array($key, $checkbox_fields)) {
            $new_settings[$key] = isset($_POST[$key]);
        }
        // Color fields
        elseif (in_array($key, $color_fields)) {
            $color_value = isset($_POST[$key]) ? sanitize_hex_color($_POST[$key]) : null;
            $new_settings[$key] = $color_value ? $color_value : $default;
        }
        // Numeric fields
        elseif (in_array($key, array('max_width', 'min_height', 'max_height', 'border_radius', 'nav_width', 'font_size_base', 'font_size_title', 'site_header_logo_size', 'site_header_max_width'))) {
            $new_settings[$key] = absint($_POST[$key] ?? $default);
        }
        // Logo URL field
        elseif ($key === 'site_header_logo') {
            $new_settings[$key] = esc_url_raw($_POST[$key] ?? $settings[$key] ?? '');
        }
        // All other text fields
        else {
            $value = $_POST[$key] ?? $default;
            $new_settings[$key] = sanitize_textarea_field(wp_unslash($value));
        }
    }
    
    update_option('fra_customizer', $new_settings);
    $settings = $new_settings;
    
    // Also save member pages to membership settings
    if (isset($_POST['member_pages']) && is_array($_POST['member_pages'])) {
        $membership_settings = get_option('fra_membership', array());
        $member_pages = array();
        
        foreach ($_POST['member_pages'] as $index => $page) {
            // Only save if enabled checkbox is checked and has content
            if (!empty($page['enabled']) && (!empty($page['title']) || !empty($page['url']))) {
                $member_pages[] = array(
                    'icon' => sanitize_text_field(wp_unslash($page['icon'] ?? '')),
                    'title' => sanitize_text_field(wp_unslash($page['title'] ?? '')),
                    'url' => esc_url_raw(wp_unslash($page['url'] ?? ''))
                );
            }
        }
        
        $membership_settings['member_pages'] = $member_pages;
        update_option('fra_membership', $membership_settings);
    }
    
    echo '<div class="notice notice-success is-dismissible"><p>' . __('✓ Customization settings saved!', 'france-relocation-assistant') . '</p></div>';
}

// Handle reset
if (isset($_POST['fra_reset_customizer']) && check_admin_referer('fra_customizer_nonce')) {
    delete_option('fra_customizer');
    $settings = $defaults;
    echo '<div class="notice notice-warning is-dismissible"><p>' . __('Settings reset to defaults.', 'france-relocation-assistant') . '</p></div>';
}
?>

<div class="wrap fra-admin-wrap">
    <h1>
        <span class="dashicons dashicons-admin-appearance"></span>
        <?php _e('Appearance Customizer', 'france-relocation-assistant'); ?>
    </h1>
    
    <div class="fra-admin-header">
        <p class="fra-description">
            <?php _e('Customize colors, text, and layout of your France Relocation Assistant.', 'france-relocation-assistant'); ?>
        </p>
    </div>
    
    <form method="post" class="fra-customizer-form">
        <?php wp_nonce_field('fra_customizer_nonce'); ?>
        
        <!-- Tab Navigation -->
        <div class="fra-tabs">
            <button type="button" class="fra-tab active" data-tab="site-header"><?php _e('🌐 Site Header', 'france-relocation-assistant'); ?></button>
            <button type="button" class="fra-tab" data-tab="colors"><?php _e('🎨 Colors', 'france-relocation-assistant'); ?></button>
            <button type="button" class="fra-tab" data-tab="text"><?php _e('✏️ Text & Labels', 'france-relocation-assistant'); ?></button>
            <button type="button" class="fra-tab" data-tab="layout"><?php _e('📐 Layout', 'france-relocation-assistant'); ?></button>
            <button type="button" class="fra-tab" data-tab="navigation"><?php _e('📂 Navigation', 'france-relocation-assistant'); ?></button>
        </div>
        
        <!-- Site Header Tab -->
        <div class="fra-tab-content active" data-tab="site-header">
            <div class="fra-customizer-grid">
                <!-- Enable/Disable -->
                <div class="fra-card fra-card-full">
                    <h2><?php _e('🌐 WordPress Site Header', 'france-relocation-assistant'); ?></h2>
                    <p class="description"><?php _e('Customize your site\'s main header that appears on all pages. This replaces your theme\'s default header.', 'france-relocation-assistant'); ?></p>
                    
                    <table class="form-table">
                        <tr>
                            <th><label for="site_header_enabled"><?php _e('Enable Custom Header', 'france-relocation-assistant'); ?></label></th>
                            <td>
                                <label class="fra-toggle">
                                    <input type="checkbox" name="site_header_enabled" id="site_header_enabled" <?php checked($settings['site_header_enabled']); ?>>
                                    <span class="fra-toggle-slider"></span>
                                </label>
                                <span class="description" style="margin-left: 10px;"><?php _e('Enable the custom header on your site', 'france-relocation-assistant'); ?></span>
                            </td>
                        </tr>
                        <tr>
                            <th><label for="site_header_hide_theme_header"><?php _e('Hide Theme Header', 'france-relocation-assistant'); ?></label></th>
                            <td>
                                <label class="fra-toggle">
                                    <input type="checkbox" name="site_header_hide_theme_header" id="site_header_hide_theme_header" <?php checked($settings['site_header_hide_theme_header']); ?>>
                                    <span class="fra-toggle-slider"></span>
                                </label>
                                <span class="description" style="margin-left: 10px;"><?php _e('Hide your theme\'s default header/hero section', 'france-relocation-assistant'); ?></span>
                            </td>
                        </tr>
                    </table>
                </div>
                
                <!-- Logo Upload -->
                <div class="fra-card">
                    <h2><?php _e('📷 Logo', 'france-relocation-assistant'); ?></h2>
                    
                    <div class="fra-logo-upload-area">
                        <div class="fra-logo-preview" id="logo-preview">
                            <?php if (!empty($settings['site_header_logo'])): ?>
                                <img src="<?php echo esc_url($settings['site_header_logo']); ?>" alt="Logo">
                            <?php else: ?>
                                <div class="fra-logo-placeholder">
                                    <span class="dashicons dashicons-format-image"></span>
                                    <p><?php _e('No logo uploaded', 'france-relocation-assistant'); ?></p>
                                </div>
                            <?php endif; ?>
                        </div>
                        <input type="hidden" name="site_header_logo" id="site_header_logo" value="<?php echo esc_url($settings['site_header_logo']); ?>">
                        <div class="fra-logo-buttons">
                            <button type="button" id="upload-logo-btn" class="button button-primary">
                                <span class="dashicons dashicons-upload" style="margin-top: 4px;"></span>
                                <?php _e('Upload Logo', 'france-relocation-assistant'); ?>
                            </button>
                            <button type="button" id="remove-logo-btn" class="button" <?php echo empty($settings['site_header_logo']) ? 'style="display:none;"' : ''; ?>>
                                <?php _e('Remove', 'france-relocation-assistant'); ?>
                            </button>
                        </div>
                    </div>
                    
                    <table class="form-table">
                        <tr>
                            <th><label for="site_header_logo_size"><?php _e('Logo Size', 'france-relocation-assistant'); ?></label></th>
                            <td>
                                <input type="number" name="site_header_logo_size" id="site_header_logo_size" value="<?php echo esc_attr($settings['site_header_logo_size']); ?>" min="50" max="300" step="10" style="width: 80px;">
                                <span class="description">px (<?php _e('width & height', 'france-relocation-assistant'); ?>)</span>
                            </td>
                        </tr>
                        <tr>
                            <th><label for="site_header_max_width"><?php _e('Header Max Width', 'france-relocation-assistant'); ?></label></th>
                            <td>
                                <input type="number" name="site_header_max_width" id="site_header_max_width" value="<?php echo esc_attr($settings['site_header_max_width']); ?>" min="800" max="1920" step="10" style="width: 100px;">
                                <span class="description">px</span>
                                <p class="description" style="margin-top: 4px;"><?php _e('Match to your content width. Default: 1280px. Use ~1240px to align with the assistant below.', 'france-relocation-assistant'); ?></p>
                            </td>
                        </tr>
                    </table>
                </div>
                
                <!-- Site Name & Tagline -->
                <div class="fra-card">
                    <h2><?php _e('✏️ Site Name & Tagline', 'france-relocation-assistant'); ?></h2>
                    
                    <table class="form-table">
                        <tr>
                            <th><label for="site_header_site_name"><?php _e('Site Name', 'france-relocation-assistant'); ?></label></th>
                            <td>
                                <input type="text" name="site_header_site_name" id="site_header_site_name" value="<?php echo esc_attr($settings['site_header_site_name']); ?>" class="regular-text">
                            </td>
                        </tr>
                        <tr>
                            <th><label for="site_header_tagline"><?php _e('Tagline (Line 1)', 'france-relocation-assistant'); ?></label></th>
                            <td>
                                <input type="text" name="site_header_tagline" id="site_header_tagline" value="<?php echo esc_attr($settings['site_header_tagline']); ?>" class="large-text" style="width: 100%; max-width: 500px;">
                                <p class="description"><?php _e('Main tagline - appears below the site name', 'france-relocation-assistant'); ?></p>
                            </td>
                        </tr>
                        <tr>
                            <th><label for="site_header_description"><?php _e('Description (Line 2)', 'france-relocation-assistant'); ?></label></th>
                            <td>
                                <input type="text" name="site_header_description" id="site_header_description" value="<?php echo esc_attr($settings['site_header_description']); ?>" class="large-text" style="width: 100%; max-width: 500px;">
                                <p class="description"><?php _e('Optional second line - use for trust signals like "Updated daily" or "10,000+ users helped"', 'france-relocation-assistant'); ?></p>
                            </td>
                        </tr>
                    </table>
                </div>
                
                <!-- Colors -->
                <div class="fra-card">
                    <h2><?php _e('🎨 Header Colors', 'france-relocation-assistant'); ?></h2>
                    
                    <div class="fra-color-grid">
                        <div class="fra-color-item">
                            <label for="site_header_bg_color"><?php _e('Header Background', 'france-relocation-assistant'); ?></label>
                            <input type="color" name="site_header_bg_color" id="site_header_bg_color" value="<?php echo esc_attr($settings['site_header_bg_color']); ?>">
                        </div>
                        <div class="fra-color-item">
                            <label for="site_header_utility_bg_color"><?php _e('Utility Bar Background', 'france-relocation-assistant'); ?></label>
                            <input type="color" name="site_header_utility_bg_color" id="site_header_utility_bg_color" value="<?php echo esc_attr($settings['site_header_utility_bg_color']); ?>">
                        </div>
                        <div class="fra-color-item">
                            <label for="site_header_text_color"><?php _e('Text Color', 'france-relocation-assistant'); ?></label>
                            <input type="color" name="site_header_text_color" id="site_header_text_color" value="<?php echo esc_attr($settings['site_header_text_color']); ?>">
                        </div>
                        <div class="fra-color-item">
                            <label for="site_header_nav_link_color"><?php _e('Nav Link Color', 'france-relocation-assistant'); ?></label>
                            <input type="color" name="site_header_nav_link_color" id="site_header_nav_link_color" value="<?php echo esc_attr($settings['site_header_nav_link_color']); ?>">
                        </div>
                        <div class="fra-color-item">
                            <label for="site_header_cta_color"><?php _e('CTA Button Color', 'france-relocation-assistant'); ?></label>
                            <input type="color" name="site_header_cta_color" id="site_header_cta_color" value="<?php echo esc_attr($settings['site_header_cta_color']); ?>">
                        </div>
                        <div class="fra-color-item">
                            <label for="site_header_logo_bg_color"><?php _e('Logo Background', 'france-relocation-assistant'); ?></label>
                            <input type="color" name="site_header_logo_bg_color" id="site_header_logo_bg_color" value="<?php echo esc_attr($settings['site_header_logo_bg_color']); ?>">
                            <p class="description" style="font-size: 11px; margin-top: 4px;"><?php _e('Set to same as header for no box', 'france-relocation-assistant'); ?></p>
                        </div>
                    </div>
                </div>
                
                <!-- Utility Bar -->
                <div class="fra-card">
                    <h2><?php _e('📢 Utility Bar', 'france-relocation-assistant'); ?></h2>
                    <p class="description"><?php _e('The small bar above the main header', 'france-relocation-assistant'); ?></p>
                    
                    <table class="form-table">
                        <tr>
                            <th><label for="site_header_utility_text"><?php _e('Utility Text', 'france-relocation-assistant'); ?></label></th>
                            <td>
                                <input type="text" name="site_header_utility_text" id="site_header_utility_text" value="<?php echo esc_attr($settings['site_header_utility_text']); ?>" class="large-text">
                            </td>
                        </tr>
                        <tr>
                            <th><label for="site_header_login_text"><?php _e('Login Link Text', 'france-relocation-assistant'); ?></label></th>
                            <td>
                                <input type="text" name="site_header_login_text" id="site_header_login_text" value="<?php echo esc_attr($settings['site_header_login_text']); ?>" style="width: 120px;">
                                <input type="text" name="site_header_login_url" id="site_header_login_url" value="<?php echo esc_attr($settings['site_header_login_url']); ?>" placeholder="URL" class="regular-text">
                            </td>
                        </tr>
                        <tr>
                            <th><label for="site_header_contact_text"><?php _e('Contact Link Text', 'france-relocation-assistant'); ?></label></th>
                            <td>
                                <input type="text" name="site_header_contact_text" id="site_header_contact_text" value="<?php echo esc_attr($settings['site_header_contact_text']); ?>" style="width: 120px;">
                                <input type="text" name="site_header_contact_url" id="site_header_contact_url" value="<?php echo esc_attr($settings['site_header_contact_url']); ?>" placeholder="URL" class="regular-text">
                            </td>
                        </tr>
                    </table>
                </div>
                
                <!-- CTA Button -->
                <div class="fra-card">
                    <h2><?php _e('🔘 Call-to-Action Button', 'france-relocation-assistant'); ?></h2>
                    
                    <table class="form-table">
                        <tr>
                            <th><label for="site_header_cta_text"><?php _e('Button Text', 'france-relocation-assistant'); ?></label></th>
                            <td>
                                <input type="text" name="site_header_cta_text" id="site_header_cta_text" value="<?php echo esc_attr($settings['site_header_cta_text']); ?>" class="regular-text">
                            </td>
                        </tr>
                        <tr>
                            <th><label for="site_header_cta_url"><?php _e('Button URL', 'france-relocation-assistant'); ?></label></th>
                            <td>
                                <input type="text" name="site_header_cta_url" id="site_header_cta_url" value="<?php echo esc_attr($settings['site_header_cta_url']); ?>" class="regular-text">
                            </td>
                        </tr>
                    </table>
                </div>
                
                <!-- Navigation -->
                <div class="fra-card fra-card-full">
                    <h2><?php _e('🧭 Navigation Menu', 'france-relocation-assistant'); ?></h2>
                    <p class="description"><?php _e('Enter menu items as comma-separated values. The order of items and URLs must match.', 'france-relocation-assistant'); ?></p>
                    
                    <table class="form-table">
                        <tr>
                            <th><label for="site_header_nav_items"><?php _e('Menu Items', 'france-relocation-assistant'); ?></label></th>
                            <td>
                                <input type="text" name="site_header_nav_items" id="site_header_nav_items" value="<?php echo esc_attr($settings['site_header_nav_items']); ?>" class="large-text">
                                <p class="description"><?php _e('Example: Guide,Visa,Property,Taxes,Tools', 'france-relocation-assistant'); ?></p>
                            </td>
                        </tr>
                        <tr>
                            <th><label for="site_header_nav_urls"><?php _e('Menu URLs', 'france-relocation-assistant'); ?></label></th>
                            <td>
                                <input type="text" name="site_header_nav_urls" id="site_header_nav_urls" value="<?php echo esc_attr($settings['site_header_nav_urls']); ?>" class="large-text">
                                <p class="description"><?php _e('Example: /guide/,/visa/,/property/,/taxes/,/tools/', 'france-relocation-assistant'); ?></p>
                            </td>
                        </tr>
                    </table>
                </div>
            </div>
        </div>
        
        <!-- Colors Tab -->
        <div class="fra-tab-content" data-tab="colors">
            <div class="fra-customizer-grid">
                <!-- Header Section -->
                <div class="fra-card">
                    <h2><?php _e('Header Section', 'france-relocation-assistant'); ?></h2>
                    <p class="description"><?php _e('The dark header bar with title and subtitle', 'france-relocation-assistant'); ?></p>
                    
                    <div class="fra-color-grid">
                        <div class="fra-color-item">
                            <label><?php _e('Header Background', 'france-relocation-assistant'); ?></label>
                            <input type="color" name="header_bg_color" value="<?php echo esc_attr($settings['header_bg_color']); ?>">
                        </div>
                        <div class="fra-color-item">
                            <label><?php _e('Header Text', 'france-relocation-assistant'); ?></label>
                            <input type="color" name="header_text_color" value="<?php echo esc_attr($settings['header_text_color']); ?>">
                        </div>
                    </div>
                    
                    <table class="form-table" style="margin-top: 15px;">
                        <tr>
                            <th><label for="header_title"><?php _e('Header Title', 'france-relocation-assistant'); ?></label></th>
                            <td>
                                <input type="text" name="header_title" id="header_title" value="<?php echo esc_attr($settings['header_title']); ?>" class="regular-text">
                            </td>
                        </tr>
                        <tr>
                            <th><label for="header_subtitle"><?php _e('Header Subtitle', 'france-relocation-assistant'); ?></label></th>
                            <td>
                                <input type="text" name="header_subtitle" id="header_subtitle" value="<?php echo esc_attr($settings['header_subtitle']); ?>" class="regular-text">
                            </td>
                        </tr>
                        <tr>
                            <th><label for="header_show_flag"><?php _e('Show Flag Icon', 'france-relocation-assistant'); ?></label></th>
                            <td>
                                <label>
                                    <input type="checkbox" name="header_show_flag" id="header_show_flag" <?php checked($settings['header_show_flag']); ?>>
                                    <?php _e('Display French flag next to title', 'france-relocation-assistant'); ?>
                                </label>
                            </td>
                        </tr>
                    </table>
                </div>
                
                <!-- Main Colors -->
                <div class="fra-card">
                    <h2><?php _e('Main Colors', 'france-relocation-assistant'); ?></h2>
                    
                    <div class="fra-color-grid">
                        <div class="fra-color-item">
                            <label><?php _e('Background', 'france-relocation-assistant'); ?></label>
                            <input type="color" name="color_background" value="<?php echo esc_attr($settings['color_background']); ?>">
                        </div>
                        <div class="fra-color-item">
                            <label><?php _e('Cards/Panels', 'france-relocation-assistant'); ?></label>
                            <input type="color" name="color_card" value="<?php echo esc_attr($settings['color_card']); ?>">
                        </div>
                        <div class="fra-color-item">
                            <label><?php _e('Primary Text', 'france-relocation-assistant'); ?></label>
                            <input type="color" name="color_text" value="<?php echo esc_attr($settings['color_text']); ?>">
                        </div>
                        <div class="fra-color-item">
                            <label><?php _e('Secondary Text', 'france-relocation-assistant'); ?></label>
                            <input type="color" name="color_text_light" value="<?php echo esc_attr($settings['color_text_light']); ?>">
                        </div>
                        <div class="fra-color-item">
                            <label><?php _e('Accent (Orange)', 'france-relocation-assistant'); ?></label>
                            <input type="color" name="color_accent" value="<?php echo esc_attr($settings['color_accent']); ?>">
                        </div>
                        <div class="fra-color-item">
                            <label><?php _e('Borders', 'france-relocation-assistant'); ?></label>
                            <input type="color" name="color_border" value="<?php echo esc_attr($settings['color_border']); ?>">
                        </div>
                    </div>
                </div>
                
                <!-- Navigation Colors -->
                <div class="fra-card">
                    <h2><?php _e('Navigation Sidebar', 'france-relocation-assistant'); ?></h2>
                    
                    <div class="fra-color-grid">
                        <div class="fra-color-item">
                            <label><?php _e('Nav Background', 'france-relocation-assistant'); ?></label>
                            <input type="color" name="color_nav_bg" value="<?php echo esc_attr($settings['color_nav_bg']); ?>">
                        </div>
                        <div class="fra-color-item">
                            <label><?php _e('Nav Text', 'france-relocation-assistant'); ?></label>
                            <input type="color" name="color_nav_text" value="<?php echo esc_attr($settings['color_nav_text']); ?>">
                        </div>
                        <div class="fra-color-item">
                            <label><?php _e('Hover Color', 'france-relocation-assistant'); ?></label>
                            <input type="color" name="color_nav_hover" value="<?php echo esc_attr($settings['color_nav_hover']); ?>">
                        </div>
                        <div class="fra-color-item">
                            <label><?php _e('Active Item BG', 'france-relocation-assistant'); ?></label>
                            <input type="color" name="color_nav_active_bg" value="<?php echo esc_attr($settings['color_nav_active_bg']); ?>">
                        </div>
                    </div>
                </div>
                
                <!-- Chat Area Colors -->
                <div class="fra-card">
                    <h2><?php _e('Chat Area', 'france-relocation-assistant'); ?></h2>
                    
                    <div class="fra-color-grid">
                        <div class="fra-color-item">
                            <label><?php _e('Chat Background', 'france-relocation-assistant'); ?></label>
                            <input type="color" name="color_chat_bg" value="<?php echo esc_attr($settings['color_chat_bg']); ?>">
                        </div>
                        <div class="fra-color-item">
                            <label><?php _e('Input Background', 'france-relocation-assistant'); ?></label>
                            <input type="color" name="color_chat_input_bg" value="<?php echo esc_attr($settings['color_chat_input_bg']); ?>">
                        </div>
                        <div class="fra-color-item">
                            <label><?php _e('User Message BG', 'france-relocation-assistant'); ?></label>
                            <input type="color" name="color_user_msg_bg" value="<?php echo esc_attr($settings['color_user_msg_bg']); ?>">
                        </div>
                        <div class="fra-color-item">
                            <label><?php _e('AI Message BG', 'france-relocation-assistant'); ?></label>
                            <input type="color" name="color_ai_msg_bg" value="<?php echo esc_attr($settings['color_ai_msg_bg']); ?>">
                        </div>
                        <div class="fra-color-item">
                            <label><?php _e('AI Header BG', 'france-relocation-assistant'); ?></label>
                            <input type="color" name="color_ai_header_bg" value="<?php echo esc_attr($settings['color_ai_header_bg']); ?>">
                        </div>
                        <div class="fra-color-item">
                            <label><?php _e('Input Border', 'france-relocation-assistant'); ?></label>
                            <input type="color" name="color_chat_input_border" value="<?php echo esc_attr($settings['color_chat_input_border']); ?>">
                        </div>
                    </div>
                </div>
                
                <!-- Button Colors -->
                <div class="fra-card">
                    <h2><?php _e('Buttons', 'france-relocation-assistant'); ?></h2>
                    
                    <div class="fra-color-grid">
                        <div class="fra-color-item">
                            <label><?php _e('Primary Button BG', 'france-relocation-assistant'); ?></label>
                            <input type="color" name="color_btn_primary_bg" value="<?php echo esc_attr($settings['color_btn_primary_bg']); ?>">
                        </div>
                        <div class="fra-color-item">
                            <label><?php _e('Primary Button Text', 'france-relocation-assistant'); ?></label>
                            <input type="color" name="color_btn_primary_text" value="<?php echo esc_attr($settings['color_btn_primary_text']); ?>">
                        </div>
                        <div class="fra-color-item">
                            <label><?php _e('Secondary Button BG', 'france-relocation-assistant'); ?></label>
                            <input type="color" name="color_btn_secondary_bg" value="<?php echo esc_attr($settings['color_btn_secondary_bg']); ?>">
                        </div>
                        <div class="fra-color-item">
                            <label><?php _e('Secondary Button Text', 'france-relocation-assistant'); ?></label>
                            <input type="color" name="color_btn_secondary_text" value="<?php echo esc_attr($settings['color_btn_secondary_text']); ?>">
                        </div>
                        <div class="fra-color-item">
                            <label><?php _e('Send Button BG', 'france-relocation-assistant'); ?></label>
                            <input type="color" name="color_send_btn_bg" value="<?php echo esc_attr($settings['color_send_btn_bg']); ?>">
                        </div>
                        <div class="fra-color-item">
                            <label><?php _e('Send Button Icon', 'france-relocation-assistant'); ?></label>
                            <input type="color" name="color_send_btn_text" value="<?php echo esc_attr($settings['color_send_btn_text']); ?>">
                        </div>
                    </div>
                </div>
                
                <!-- Status & Day Counter Colors -->
                <div class="fra-card">
                    <h2><?php _e('Status & Day Counter', 'france-relocation-assistant'); ?></h2>
                    
                    <div class="fra-color-grid">
                        <div class="fra-color-item">
                            <label><?php _e('Success', 'france-relocation-assistant'); ?></label>
                            <input type="color" name="color_success" value="<?php echo esc_attr($settings['color_success']); ?>">
                        </div>
                        <div class="fra-color-item">
                            <label><?php _e('Warning', 'france-relocation-assistant'); ?></label>
                            <input type="color" name="color_warning" value="<?php echo esc_attr($settings['color_warning']); ?>">
                        </div>
                        <div class="fra-color-item">
                            <label><?php _e('Danger', 'france-relocation-assistant'); ?></label>
                            <input type="color" name="color_danger" value="<?php echo esc_attr($settings['color_danger']); ?>">
                        </div>
                        <div class="fra-color-item">
                            <label><?php _e('France (Calendar)', 'france-relocation-assistant'); ?></label>
                            <input type="color" name="color_france" value="<?php echo esc_attr($settings['color_france']); ?>">
                        </div>
                        <div class="fra-color-item">
                            <label><?php _e('US (Calendar)', 'france-relocation-assistant'); ?></label>
                            <input type="color" name="color_us" value="<?php echo esc_attr($settings['color_us']); ?>">
                        </div>
                        <div class="fra-color-item">
                            <label><?php _e('Other (Calendar)', 'france-relocation-assistant'); ?></label>
                            <input type="color" name="color_other" value="<?php echo esc_attr($settings['color_other']); ?>">
                        </div>
                    </div>
                </div>
            </div>
        </div>
        
        <!-- Text & Labels Tab -->
        <div class="fra-tab-content" data-tab="text">
            <div class="fra-customizer-grid">
                <!-- Welcome Screen -->
                <div class="fra-card">
                    <h2><?php _e('Welcome Screen', 'france-relocation-assistant'); ?></h2>
                    
                    <table class="form-table">
                        <tr>
                            <th><label for="welcome_icon"><?php _e('Icon/Emoji', 'france-relocation-assistant'); ?></label></th>
                            <td><input type="text" name="welcome_icon" id="welcome_icon" value="<?php echo esc_attr($settings['welcome_icon']); ?>" class="regular-text"></td>
                        </tr>
                        <tr>
                            <th><label for="welcome_title"><?php _e('Title', 'france-relocation-assistant'); ?></label></th>
                            <td><input type="text" name="welcome_title" id="welcome_title" value="<?php echo esc_attr($settings['welcome_title']); ?>" class="large-text"></td>
                        </tr>
                        <tr>
                            <th><label for="welcome_subtitle"><?php _e('Subtitle', 'france-relocation-assistant'); ?></label></th>
                            <td><textarea name="welcome_subtitle" id="welcome_subtitle" rows="2" class="large-text"><?php echo esc_textarea($settings['welcome_subtitle']); ?></textarea></td>
                        </tr>
                        <tr>
                            <th><?php _e('Quick Topics', 'france-relocation-assistant'); ?></th>
                            <td><label><input type="checkbox" name="show_quick_topics" <?php checked($settings['show_quick_topics']); ?>> <?php _e('Show quick topic buttons', 'france-relocation-assistant'); ?></label></td>
                        </tr>
                    </table>
                </div>
                
                <!-- Quick Topic Buttons -->
                <div class="fra-card">
                    <h2><?php _e('Quick Topic Buttons', 'france-relocation-assistant'); ?></h2>
                    <p class="description"><?php _e('Customize the quick access buttons on the welcome screen.', 'france-relocation-assistant'); ?></p>
                    
                    <?php for ($i = 1; $i <= 4; $i++): ?>
                    <div class="fra-quick-topic-row">
                        <strong><?php printf(__('Button %d:', 'france-relocation-assistant'), $i); ?></strong>
                        <input type="text" name="quick_topic_<?php echo $i; ?>_label" value="<?php echo esc_attr($settings["quick_topic_{$i}_label"]); ?>" placeholder="<?php _e('Label', 'france-relocation-assistant'); ?>" class="regular-text">
                        <input type="text" name="quick_topic_<?php echo $i; ?>_cat" value="<?php echo esc_attr($settings["quick_topic_{$i}_cat"]); ?>" placeholder="<?php _e('Category', 'france-relocation-assistant'); ?>" class="small-text">
                        <input type="text" name="quick_topic_<?php echo $i; ?>_topic" value="<?php echo esc_attr($settings["quick_topic_{$i}_topic"]); ?>" placeholder="<?php _e('Topic', 'france-relocation-assistant'); ?>" class="small-text">
                    </div>
                    <?php endfor; ?>
                    <p class="description"><?php _e('Use "_day_counter" as category for the day counter button.', 'france-relocation-assistant'); ?></p>
                </div>
                
                <!-- Chat Input -->
                <div class="fra-card">
                    <h2><?php _e('Chat Input Area', 'france-relocation-assistant'); ?></h2>
                    
                    <table class="form-table">
                        <tr>
                            <th><label for="chat_placeholder"><?php _e('Input Placeholder', 'france-relocation-assistant'); ?></label></th>
                            <td><input type="text" name="chat_placeholder" id="chat_placeholder" value="<?php echo esc_attr($settings['chat_placeholder']); ?>" class="large-text"></td>
                        </tr>
                        <tr>
                            <th><label for="chat_hint"><?php _e('Hint Text', 'france-relocation-assistant'); ?></label></th>
                            <td><input type="text" name="chat_hint" id="chat_hint" value="<?php echo esc_attr($settings['chat_hint']); ?>" class="large-text"></td>
                        </tr>
                    </table>
                </div>
                
                <!-- Search Bar -->
                <div class="fra-card">
                    <h2><?php _e('Search Bar', 'france-relocation-assistant'); ?></h2>
                    
                    <table class="form-table">
                        <tr>
                            <th><?php _e('Show Search', 'france-relocation-assistant'); ?></th>
                            <td><label><input type="checkbox" name="show_search_bar" <?php checked($settings['show_search_bar']); ?>> <?php _e('Show search bar in navigation', 'france-relocation-assistant'); ?></label></td>
                        </tr>
                        <tr>
                            <th><label for="search_placeholder"><?php _e('Placeholder', 'france-relocation-assistant'); ?></label></th>
                            <td><input type="text" name="search_placeholder" id="search_placeholder" value="<?php echo esc_attr($settings['search_placeholder']); ?>" class="regular-text"></td>
                        </tr>
                    </table>
                </div>
            </div>
        </div>
        
        <!-- Layout Tab -->
        <div class="fra-tab-content" data-tab="layout">
            <div class="fra-customizer-grid">
                <!-- Dimensions -->
                <div class="fra-card">
                    <h2><?php _e('Dimensions', 'france-relocation-assistant'); ?></h2>
                    
                    <table class="form-table">
                        <tr>
                            <th><label for="max_width"><?php _e('Max Width', 'france-relocation-assistant'); ?></label></th>
                            <td><input type="number" name="max_width" id="max_width" value="<?php echo esc_attr($settings['max_width']); ?>" min="800" max="2000" step="10"> px</td>
                        </tr>
                        <tr>
                            <th><label for="min_height"><?php _e('Min Height', 'france-relocation-assistant'); ?></label></th>
                            <td><input type="number" name="min_height" id="min_height" value="<?php echo esc_attr($settings['min_height']); ?>" min="400" max="1200" step="10"> px</td>
                        </tr>
                        <tr>
                            <th><label for="max_height"><?php _e('Max Height', 'france-relocation-assistant'); ?></label></th>
                            <td><input type="number" name="max_height" id="max_height" value="<?php echo esc_attr($settings['max_height']); ?>" min="600" max="1600" step="10"> px</td>
                        </tr>
                        <tr>
                            <th><label for="nav_width"><?php _e('Navigation Width', 'france-relocation-assistant'); ?></label></th>
                            <td><input type="number" name="nav_width" id="nav_width" value="<?php echo esc_attr($settings['nav_width']); ?>" min="200" max="400" step="10"> px</td>
                        </tr>
                        <tr>
                            <th><label for="border_radius"><?php _e('Border Radius', 'france-relocation-assistant'); ?></label></th>
                            <td><input type="number" name="border_radius" id="border_radius" value="<?php echo esc_attr($settings['border_radius']); ?>" min="0" max="24" step="1"> px</td>
                        </tr>
                    </table>
                </div>
                
                <!-- Typography -->
                <div class="fra-card">
                    <h2><?php _e('Typography', 'france-relocation-assistant'); ?></h2>
                    
                    <table class="form-table">
                        <tr>
                            <th><label for="font_family"><?php _e('Font Family', 'france-relocation-assistant'); ?></label></th>
                            <td>
                                <select name="font_family" id="font_family" class="regular-text">
                                    <option value='-apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif' <?php selected($settings['font_family'], '-apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif'); ?>>System Default</option>
                                    <option value='"Helvetica Neue", Helvetica, Arial, sans-serif' <?php selected($settings['font_family'], '"Helvetica Neue", Helvetica, Arial, sans-serif'); ?>>Helvetica Neue</option>
                                    <option value='"Segoe UI", Tahoma, Geneva, sans-serif' <?php selected($settings['font_family'], '"Segoe UI", Tahoma, Geneva, sans-serif'); ?>>Segoe UI</option>
                                    <option value='Georgia, "Times New Roman", serif' <?php selected($settings['font_family'], 'Georgia, "Times New Roman", serif'); ?>>Georgia (Serif)</option>
                                    <option value='"Inter", sans-serif' <?php selected($settings['font_family'], '"Inter", sans-serif'); ?>>Inter</option>
                                </select>
                            </td>
                        </tr>
                        <tr>
                            <th><label for="font_size_base"><?php _e('Base Font Size', 'france-relocation-assistant'); ?></label></th>
                            <td><input type="number" name="font_size_base" id="font_size_base" value="<?php echo esc_attr($settings['font_size_base']); ?>" min="12" max="18" step="1"> px</td>
                        </tr>
                        <tr>
                            <th><label for="font_size_title"><?php _e('Title Font Size', 'france-relocation-assistant'); ?></label></th>
                            <td><input type="number" name="font_size_title" id="font_size_title" value="<?php echo esc_attr($settings['font_size_title']); ?>" min="14" max="24" step="1"> px</td>
                        </tr>
                    </table>
                </div>
                
                <!-- Toolbar Options -->
                <div class="fra-card">
                    <h2><?php _e('Toolbar', 'france-relocation-assistant'); ?></h2>
                    
                    <table class="form-table">
                        <tr>
                            <th><?php _e('Day Counter', 'france-relocation-assistant'); ?></th>
                            <td><label><input type="checkbox" name="show_day_counter_btn" <?php checked($settings['show_day_counter_btn']); ?>> <?php _e('Show 183-Day Counter button', 'france-relocation-assistant'); ?></label></td>
                        </tr>
                    </table>
                </div>
                
                <!-- Sidebar Display Options -->
                <div class="fra-card">
                    <h2><?php _e('📋 Sidebar Display', 'france-relocation-assistant'); ?></h2>
                    <p class="description"><?php _e('Control what appears in the navigation sidebar', 'france-relocation-assistant'); ?></p>
                    
                    <table class="form-table">
                        <tr>
                            <th><?php _e('FREE Badge', 'france-relocation-assistant'); ?></th>
                            <td>
                                <label class="fra-toggle">
                                    <input type="checkbox" name="show_free_badge" <?php checked($settings['show_free_badge']); ?>>
                                    <span class="fra-toggle-slider"></span>
                                </label>
                                <span class="description" style="margin-left: 10px;"><?php _e('Show "✓ FREE Knowledge Base" label above topics', 'france-relocation-assistant'); ?></span>
                            </td>
                        </tr>
                        <tr>
                            <th><?php _e('Members Preview', 'france-relocation-assistant'); ?></th>
                            <td>
                                <label class="fra-toggle">
                                    <input type="checkbox" name="show_members_preview" <?php checked($settings['show_members_preview']); ?>>
                                    <span class="fra-toggle-slider"></span>
                                </label>
                                <span class="description" style="margin-left: 10px;"><?php _e('Show locked member pages to non-members (visible but not clickable)', 'france-relocation-assistant'); ?></span>
                            </td>
                        </tr>
                    </table>
                    
                    <div style="margin-top: 15px; padding: 12px; background: #e7f5ff; border-left: 3px solid #0077cc; border-radius: 0 6px 6px 0;">
                        <p style="margin: 0; font-size: 13px;">
                            <strong><?php _e('Tip:', 'france-relocation-assistant'); ?></strong> 
                            <?php _e('Showing locked member pages to visitors helps them see the value of membership before signing up.', 'france-relocation-assistant'); ?>
                        </p>
                    </div>
                </div>
            </div>
        </div>
        
        <!-- Navigation Tab -->
        <div class="fra-tab-content" data-tab="navigation">
            <div class="fra-customizer-grid">
                <div class="fra-card fra-card-full">
                    <h2><?php _e('Navigation Category Labels', 'france-relocation-assistant'); ?></h2>
                    <p class="description"><?php _e('Customize the labels shown in the navigation sidebar. Include emojis for visual appeal.', 'france-relocation-assistant'); ?></p>
                    
                    <table class="form-table fra-nav-labels-table">
                        <?php
                        $nav_cats = array(
                            'visas' => __('Visas & Immigration', 'france-relocation-assistant'),
                            'property' => __('Property Purchase', 'france-relocation-assistant'),
                            'healthcare' => __('Healthcare', 'france-relocation-assistant'),
                            'taxes' => __('Taxes', 'france-relocation-assistant'),
                            'driving' => __('Driving', 'france-relocation-assistant'),
                            'shipping' => __('Shipping & Pets', 'france-relocation-assistant'),
                            'banking' => __('Banking', 'france-relocation-assistant'),
                            'settling' => __('Settling In', 'france-relocation-assistant'),
                        );
                        foreach ($nav_cats as $key => $default_label):
                        ?>
                        <tr>
                            <th><label for="nav_cat_<?php echo $key; ?>"><?php echo ucfirst($key); ?></label></th>
                            <td><input type="text" name="nav_cat_<?php echo $key; ?>" id="nav_cat_<?php echo $key; ?>" value="<?php echo esc_attr($settings["nav_cat_{$key}"]); ?>" class="regular-text"></td>
                        </tr>
                        <?php endforeach; ?>
                    </table>
                </div>
                
                <!-- Member Pages Section -->
                <div class="fra-card fra-card-full">
                    <h2><?php _e('⭐ Members Area Navigation', 'france-relocation-assistant'); ?></h2>
                    <p class="description"><?php _e('Add links to member-only pages that appear in the sidebar. Members see clickable links; non-members see an upgrade prompt.', 'france-relocation-assistant'); ?></p>
                    
                    <?php
                    // Get member pages from membership settings
                    $membership_settings = get_option('fra_membership', array());
                    $member_pages = isset($membership_settings['member_pages']) ? $membership_settings['member_pages'] : array();
                    // Pad to 8 slots for flexibility
                    while (count($member_pages) < 8) {
                        $member_pages[] = array('icon' => '', 'title' => '', 'url' => '');
                    }
                    ?>
                    
                    <div class="fra-member-pages-editor" style="margin-top: 15px;">
                        <table class="wp-list-table widefat striped">
                            <thead>
                                <tr>
                                    <th style="width: 50px; text-align: center;"><?php _e('Show', 'france-relocation-assistant'); ?></th>
                                    <th style="width: 70px;"><?php _e('Icon', 'france-relocation-assistant'); ?></th>
                                    <th style="width: 200px;"><?php _e('Link Title', 'france-relocation-assistant'); ?></th>
                                    <th><?php _e('Page URL', 'france-relocation-assistant'); ?></th>
                                </tr>
                            </thead>
                            <tbody id="fra-member-pages-list">
                                <?php foreach ($member_pages as $index => $page) : 
                                    $has_content = !empty($page['title']) || !empty($page['url']);
                                ?>
                                <tr class="fra-member-page-row" data-index="<?php echo $index; ?>">
                                    <td style="text-align: center;">
                                        <input type="checkbox" 
                                               name="member_pages[<?php echo $index; ?>][enabled]" 
                                               value="1"
                                               <?php checked($has_content); ?>
                                               class="fra-page-enabled">
                                    </td>
                                    <td>
                                        <input type="text" 
                                               name="member_pages[<?php echo $index; ?>][icon]" 
                                               value="<?php echo esc_attr($page['icon'] ?? ''); ?>" 
                                               placeholder="📝"
                                               style="width: 50px; text-align: center; font-size: 16px;"
                                               class="fra-page-icon">
                                    </td>
                                    <td>
                                        <input type="text" 
                                               name="member_pages[<?php echo $index; ?>][title]" 
                                               value="<?php echo esc_attr($page['title'] ?? ''); ?>" 
                                               placeholder="<?php _e('Page Title', 'france-relocation-assistant'); ?>"
                                               class="regular-text fra-page-title">
                                    </td>
                                    <td>
                                        <input type="url" 
                                               name="member_pages[<?php echo $index; ?>][url]" 
                                               value="<?php echo esc_attr($page['url'] ?? ''); ?>" 
                                               placeholder="https://yoursite.com/member-page/"
                                               class="large-text fra-page-url">
                                    </td>
                                </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                        
                        <div style="margin-top: 15px; padding: 15px; background: #f9f9f9; border-radius: 6px;">
                            <p style="margin: 0 0 10px 0;"><strong><?php _e('Common Icons:', 'france-relocation-assistant'); ?></strong></p>
                            <div class="fra-icon-picker" style="display: flex; gap: 8px; flex-wrap: wrap;">
                                <?php
                                $common_icons = array('📝', '📋', '📄', '🎯', '💡', '📦', '🔑', '✅', '📊', '🗂️', '📁', '🎓', '💼', '🏠', '✈️', '💰');
                                foreach ($common_icons as $icon):
                                ?>
                                <button type="button" class="fra-icon-btn" data-icon="<?php echo $icon; ?>" style="padding: 8px 12px; font-size: 18px; cursor: pointer; border: 1px solid #ddd; background: #fff; border-radius: 4px;" title="<?php _e('Click to copy', 'france-relocation-assistant'); ?>">
                                    <?php echo $icon; ?>
                                </button>
                                <?php endforeach; ?>
                            </div>
                            <p class="description" style="margin-top: 10px;">
                                <?php _e('Click an icon to copy it, then paste into the Icon field. Or use any emoji!', 'france-relocation-assistant'); ?>
                            </p>
                        </div>
                        
                        <div style="margin-top: 15px; padding: 12px; background: #e7f5ff; border-left: 3px solid #0077cc; border-radius: 0 6px 6px 0;">
                            <p style="margin: 0; font-size: 13px;">
                                <strong><?php _e('Note:', 'france-relocation-assistant'); ?></strong> 
                                <?php _e('Members Area only appears if Membership is enabled in', 'france-relocation-assistant'); ?> 
                                <a href="<?php echo admin_url('admin.php?page=france-relocation-assistant-membership'); ?>"><?php _e('Membership Settings', 'france-relocation-assistant'); ?></a>.
                            </p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        
        <!-- Save Actions -->
        <div class="fra-customizer-actions">
            <input type="submit" name="fra_save_customizer" class="button button-primary button-hero" value="<?php _e('💾 Save Changes', 'france-relocation-assistant'); ?>">
            <input type="submit" name="fra_reset_customizer" class="button button-secondary" value="<?php _e('↩️ Reset to Defaults', 'france-relocation-assistant'); ?>" onclick="return confirm('<?php _e('Reset all customizations to default values?', 'france-relocation-assistant'); ?>');">
        </div>
    </form>
</div>

<style>
/* Tabs */
.fra-tabs {
    display: flex;
    gap: 5px;
    margin-bottom: 20px;
    border-bottom: 2px solid #ddd;
    padding-bottom: 0;
}
.fra-tab {
    padding: 12px 20px;
    background: #f5f5f5;
    border: none;
    border-radius: 8px 8px 0 0;
    cursor: pointer;
    font-size: 14px;
    font-weight: 500;
    color: #666;
    transition: all 0.2s ease;
}
.fra-tab:hover {
    background: #eee;
    color: #333;
}
.fra-tab.active {
    background: #fff;
    color: #1e3a5f;
    border: 2px solid #ddd;
    border-bottom: 2px solid #fff;
    margin-bottom: -2px;
}
.fra-tab-content {
    display: none;
}
.fra-tab-content.active {
    display: block;
}

/* Grid */
.fra-customizer-grid {
    display: grid;
    grid-template-columns: repeat(2, 1fr);
    gap: 20px;
}
@media (max-width: 1200px) {
    .fra-customizer-grid { grid-template-columns: 1fr; }
}
.fra-card-full { grid-column: 1 / -1; }

/* Color Grid */
.fra-color-grid {
    display: grid;
    grid-template-columns: repeat(3, 1fr);
    gap: 15px;
}
@media (max-width: 600px) {
    .fra-color-grid { grid-template-columns: repeat(2, 1fr); }
}
.fra-color-item {
    display: flex;
    flex-direction: column;
    gap: 6px;
}
.fra-color-item label {
    font-size: 12px;
    color: #666;
    font-weight: 500;
}
.fra-color-item input[type="color"] {
    width: 100%;
    height: 40px;
    padding: 2px;
    border: 1px solid #ddd;
    border-radius: 6px;
    cursor: pointer;
}

/* Quick Topic Rows */
.fra-quick-topic-row {
    display: flex;
    align-items: center;
    gap: 10px;
    padding: 10px;
    background: #f9f9f9;
    border-radius: 6px;
    margin-bottom: 10px;
}
.fra-quick-topic-row strong {
    min-width: 70px;
}
.fra-quick-topic-row input {
    flex: 1;
}
.fra-quick-topic-row .small-text {
    flex: 0 0 120px;
}

/* Actions */
.fra-customizer-actions {
    display: flex;
    gap: 15px;
    padding: 20px;
    background: #fff;
    border: 1px solid #ddd;
    border-radius: 8px;
    position: sticky;
    bottom: 20px;
    box-shadow: 0 -4px 20px rgba(0,0,0,0.1);
    margin-top: 20px;
}

/* Nav labels table */
.fra-nav-labels-table th {
    width: 120px;
}

/* Logo Upload Area */
.fra-logo-upload-area {
    text-align: center;
    padding: 20px;
    background: #f9f9f9;
    border-radius: 8px;
    margin-bottom: 15px;
}
.fra-logo-preview {
    width: 200px;
    height: 200px;
    margin: 0 auto 15px;
    border: 2px dashed #ddd;
    border-radius: 12px;
    display: flex;
    align-items: center;
    justify-content: center;
    background: #fff;
    overflow: hidden;
}
.fra-logo-preview img {
    max-width: 100%;
    max-height: 100%;
    object-fit: contain;
}
.fra-logo-placeholder {
    text-align: center;
    color: #999;
}
.fra-logo-placeholder .dashicons {
    font-size: 48px;
    width: 48px;
    height: 48px;
    color: #ccc;
}
.fra-logo-placeholder p {
    margin: 10px 0 0;
    font-size: 13px;
}
.fra-logo-buttons {
    display: flex;
    gap: 10px;
    justify-content: center;
}

/* Toggle Switch */
.fra-toggle {
    position: relative;
    display: inline-block;
    width: 50px;
    height: 26px;
    vertical-align: middle;
}
.fra-toggle input {
    opacity: 0;
    width: 0;
    height: 0;
}
.fra-toggle-slider {
    position: absolute;
    cursor: pointer;
    top: 0;
    left: 0;
    right: 0;
    bottom: 0;
    background-color: #ccc;
    transition: .3s;
    border-radius: 26px;
}
.fra-toggle-slider:before {
    position: absolute;
    content: "";
    height: 20px;
    width: 20px;
    left: 3px;
    bottom: 3px;
    background-color: white;
    transition: .3s;
    border-radius: 50%;
}
.fra-toggle input:checked + .fra-toggle-slider {
    background-color: #22c55e;
}
.fra-toggle input:checked + .fra-toggle-slider:before {
    transform: translateX(24px);
}
</style>

<script>
document.addEventListener('DOMContentLoaded', function() {
    // Tab switching
    document.querySelectorAll('.fra-tab').forEach(function(tab) {
        tab.addEventListener('click', function() {
            var targetTab = this.getAttribute('data-tab');
            
            // Update tab buttons
            document.querySelectorAll('.fra-tab').forEach(function(t) {
                t.classList.remove('active');
            });
            this.classList.add('active');
            
            // Update tab content
            document.querySelectorAll('.fra-tab-content').forEach(function(content) {
                content.classList.remove('active');
            });
            document.querySelector('.fra-tab-content[data-tab="' + targetTab + '"]').classList.add('active');
        });
    });
    
    // Icon picker - copy to clipboard and show feedback
    document.querySelectorAll('.fra-icon-btn').forEach(function(btn) {
        btn.addEventListener('click', function() {
            var icon = this.getAttribute('data-icon');
            
            // Copy to clipboard
            navigator.clipboard.writeText(icon).then(function() {
                // Visual feedback
                var originalText = btn.innerHTML;
                btn.innerHTML = '✓';
                btn.style.background = '#dcfce7';
                btn.style.borderColor = '#22c55e';
                
                setTimeout(function() {
                    btn.innerHTML = originalText;
                    btn.style.background = '#fff';
                    btn.style.borderColor = '#ddd';
                }, 800);
            });
        });
    });
    
    // Auto-check enable checkbox when user types in a field
    document.querySelectorAll('.fra-member-page-row').forEach(function(row) {
        var enableCheckbox = row.querySelector('.fra-page-enabled');
        var titleInput = row.querySelector('.fra-page-title');
        var urlInput = row.querySelector('.fra-page-url');
        
        [titleInput, urlInput].forEach(function(input) {
            if (input) {
                input.addEventListener('input', function() {
                    if (this.value.trim() !== '') {
                        enableCheckbox.checked = true;
                    }
                });
            }
        });
    });
    
    // Media uploader for logo
    var logoFrame;
    var uploadBtn = document.getElementById('upload-logo-btn');
    var removeBtn = document.getElementById('remove-logo-btn');
    var logoInput = document.getElementById('site_header_logo');
    var logoPreview = document.getElementById('logo-preview');
    
    if (uploadBtn) {
        uploadBtn.addEventListener('click', function(e) {
            e.preventDefault();
            
            // If frame exists, open it
            if (logoFrame) {
                logoFrame.open();
                return;
            }
            
            // Create media frame
            logoFrame = wp.media({
                title: '<?php _e('Select or Upload Logo', 'france-relocation-assistant'); ?>',
                button: {
                    text: '<?php _e('Use as Logo', 'france-relocation-assistant'); ?>'
                },
                multiple: false
            });
            
            // When image selected
            logoFrame.on('select', function() {
                var attachment = logoFrame.state().get('selection').first().toJSON();
                logoInput.value = attachment.url;
                logoPreview.innerHTML = '<img src="' + attachment.url + '" alt="Logo">';
                removeBtn.style.display = 'inline-block';
            });
            
            logoFrame.open();
        });
    }
    
    if (removeBtn) {
        removeBtn.addEventListener('click', function(e) {
            e.preventDefault();
            logoInput.value = '';
            logoPreview.innerHTML = '<div class="fra-logo-placeholder"><span class="dashicons dashicons-format-image"></span><p><?php _e('No logo uploaded', 'france-relocation-assistant'); ?></p></div>';
            this.style.display = 'none';
        });
    }
});
</script>
