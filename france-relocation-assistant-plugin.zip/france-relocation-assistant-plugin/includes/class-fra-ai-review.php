<?php
/**
 * AI-Assisted Knowledge Base Review
 * 
 * Uses Claude to verify and update knowledge base data
 * 
 * @package France_Relocation_Assistant
 */

if (!defined('ABSPATH')) {
    exit;
}

class FRA_AI_Review {
    
    /**
     * Instance
     */
    private static $instance = null;
    
    /**
     * Pending reviews option name
     */
    const PENDING_REVIEWS_OPTION = 'fra_pending_reviews';
    
    /**
     * Review history option name
     */
    const REVIEW_HISTORY_OPTION = 'fra_review_history';
    
    /**
     * Data points that can change and need verification
     */
    private $verifiable_data = array(
        'visas' => array(
            'visitor' => array(
                'fields' => array(
                    'visa_fee' => array(
                        'label' => 'Visa Application Fee',
                        'search_query' => 'France long stay visa application fee 2025',
                        'pattern' => '/€\s*(\d+)/',
                        'current_value' => '€99'
                    ),
                    'financial_minimum' => array(
                        'label' => 'Minimum Monthly Income Requirement',
                        'search_query' => 'France visitor visa minimum income requirement SMIC 2025',
                        'pattern' => '/€\s*([\d,\.]+)\s*(?:per month|monthly|\/month)/i',
                        'current_value' => '€1,450/month'
                    ),
                    'health_insurance_minimum' => array(
                        'label' => 'Health Insurance Minimum Coverage',
                        'search_query' => 'France visa health insurance minimum coverage requirement',
                        'pattern' => '/€\s*([\d,\.]+)\s*(?:coverage|minimum)/i',
                        'current_value' => '€30,000'
                    )
                ),
                'source_urls' => array(
                    'https://france-visas.gouv.fr/en/web/france-visas/long-stay-visa',
                    'https://www.service-public.fr/particuliers/vosdroits/F16162'
                )
            ),
            'validation' => array(
                'fields' => array(
                    'ofii_tax' => array(
                        'label' => 'OFII Validation Tax (Timbre Fiscal)',
                        'search_query' => 'France OFII visa validation tax timbre fiscal 2025 amount',
                        'pattern' => '/€\s*(\d+)/',
                        'current_value' => '€225'
                    ),
                    'validation_deadline' => array(
                        'label' => 'Validation Deadline After Arrival',
                        'search_query' => 'France visa validation deadline months after arrival',
                        'pattern' => '/(\d+)\s*months?/i',
                        'current_value' => '3 months'
                    )
                ),
                'source_urls' => array(
                    'https://administration-etrangers-en-france.interieur.gouv.fr'
                )
            ),
            'talent' => array(
                'fields' => array(
                    'salary_threshold' => array(
                        'label' => 'Talent Passport Salary Threshold',
                        'search_query' => 'France passeport talent highly qualified salary threshold 2025',
                        'pattern' => '/€\s*([\d,\.]+)\s*(?:per year|annually|\/year)/i',
                        'current_value' => '€56,000/year'
                    ),
                    'investor_threshold' => array(
                        'label' => 'Investor Visa Minimum Investment',
                        'search_query' => 'France talent passport investor minimum investment amount',
                        'pattern' => '/€\s*([\d,\.]+)/i',
                        'current_value' => '€300,000'
                    )
                ),
                'source_urls' => array(
                    'https://france-visas.gouv.fr/en/web/france-visas/passeport-talents'
                )
            )
        ),
        'property' => array(
            'costs' => array(
                'fields' => array(
                    'notaire_fees_existing' => array(
                        'label' => 'Notaire Fees (Existing Property)',
                        'search_query' => 'France notaire fees existing property percentage 2025',
                        'pattern' => '/(\d+(?:\.\d+)?)\s*(?:%|percent)/i',
                        'current_value' => '7-8%'
                    ),
                    'notaire_fees_new' => array(
                        'label' => 'Notaire Fees (New Construction)',
                        'search_query' => 'France notaire fees new construction VEFA percentage',
                        'pattern' => '/(\d+(?:\.\d+)?)\s*(?:%|percent)/i',
                        'current_value' => '2-3%'
                    )
                ),
                'source_urls' => array(
                    'https://www.notaires.fr'
                )
            ),
            'mortgage' => array(
                'fields' => array(
                    'ltv_maximum' => array(
                        'label' => 'Maximum LTV for Non-Residents',
                        'search_query' => 'France mortgage non resident maximum LTV loan to value',
                        'pattern' => '/(\d+(?:\-\d+)?)\s*(?:%|percent)/i',
                        'current_value' => '70-80%'
                    ),
                    'dti_maximum' => array(
                        'label' => 'Maximum Debt-to-Income Ratio',
                        'search_query' => 'France mortgage maximum debt to income ratio 2025',
                        'pattern' => '/(\d+(?:\-\d+)?)\s*(?:%|percent)/i',
                        'current_value' => '33-35%'
                    )
                ),
                'source_urls' => array(
                    'https://www.banque-france.fr'
                )
            )
        ),
        'healthcare' => array(
            'puma' => array(
                'fields' => array(
                    'puma_income_threshold' => array(
                        'label' => 'PUMA Free Healthcare Income Threshold',
                        'search_query' => 'France PUMA cotisation income threshold free 2025',
                        'pattern' => '/€\s*([\d,\.]+)/i',
                        'current_value' => '€25,000/year'
                    )
                ),
                'source_urls' => array(
                    'https://www.ameli.fr'
                )
            ),
            'mutuelle' => array(
                'fields' => array(
                    'mutuelle_cost_individual' => array(
                        'label' => 'Average Mutuelle Cost (Individual)',
                        'search_query' => 'France mutuelle average cost individual per month 2025',
                        'pattern' => '/€\s*(\d+(?:\-\d+)?)/i',
                        'current_value' => '€30-100/month'
                    )
                ),
                'source_urls' => array(
                    'https://www.ameli.fr'
                )
            )
        ),
        'taxes' => array(
            'fbar' => array(
                'fields' => array(
                    'fbar_threshold' => array(
                        'label' => 'FBAR Reporting Threshold',
                        'search_query' => 'FBAR foreign bank account reporting threshold 2025',
                        'pattern' => '/\$\s*([\d,]+)/i',
                        'current_value' => '$10,000'
                    ),
                    'fatca_threshold_abroad' => array(
                        'label' => 'FATCA Threshold (Living Abroad)',
                        'search_query' => 'FATCA Form 8938 threshold US citizens living abroad',
                        'pattern' => '/\$\s*([\d,]+)/i',
                        'current_value' => '$200,000'
                    ),
                    'fbar_penalty' => array(
                        'label' => 'FBAR Non-Willful Penalty',
                        'search_query' => 'FBAR penalty non willful violation amount 2025',
                        'pattern' => '/\$\s*([\d,]+)/i',
                        'current_value' => '$12,500'
                    )
                ),
                'source_urls' => array(
                    'https://www.irs.gov/businesses/small-businesses-self-employed/report-of-foreign-bank-and-financial-accounts-fbar'
                )
            ),
            'residency' => array(
                'fields' => array(
                    'tax_residency_days' => array(
                        'label' => 'Tax Residency Day Threshold',
                        'search_query' => 'France tax residency 183 day rule',
                        'pattern' => '/(\d+)\s*days?/i',
                        'current_value' => '183 days'
                    )
                ),
                'source_urls' => array(
                    'https://www.impots.gouv.fr'
                )
            )
        ),
        'driving' => array(
            'exchange' => array(
                'fields' => array(
                    'exchange_fee' => array(
                        'label' => 'License Exchange Fee',
                        'search_query' => 'France driver license exchange fee cost 2025',
                        'pattern' => '/€\s*(\d+)/i',
                        'current_value' => '€25'
                    ),
                    'driving_school_cost' => array(
                        'label' => 'Average Driving School Cost',
                        'search_query' => 'France driving school cost auto-école price 2025',
                        'pattern' => '/€\s*([\d,]+(?:\-[\d,]+)?)/i',
                        'current_value' => '€1,500-2,500'
                    )
                ),
                'source_urls' => array(
                    'https://www.service-public.fr'
                )
            ),
            'overview' => array(
                'fields' => array(
                    'blood_alcohol_limit' => array(
                        'label' => 'Blood Alcohol Limit',
                        'search_query' => 'France drink driving blood alcohol limit legal',
                        'pattern' => '/(0\.\d+)\s*(?:%|g\/l)/i',
                        'current_value' => '0.05%'
                    )
                ),
                'source_urls' => array(
                    'https://www.securite-routiere.gouv.fr'
                )
            )
        ),
        'shipping' => array(
            'overview' => array(
                'fields' => array(
                    'container_cost_20ft' => array(
                        'label' => '20ft Container Shipping Cost',
                        'search_query' => 'shipping container USA to France cost 20ft 2025',
                        'pattern' => '/\$\s*([\d,]+(?:\-[\d,]+)?)/i',
                        'current_value' => '$3,000-6,000'
                    )
                ),
                'source_urls' => array()
            ),
            'pets' => array(
                'fields' => array(
                    'rabies_wait_period' => array(
                        'label' => 'Rabies Vaccine Wait Period',
                        'search_query' => 'EU pet travel rabies vaccine wait period days',
                        'pattern' => '/(\d+)\s*days?/i',
                        'current_value' => '21 days'
                    )
                ),
                'source_urls' => array(
                    'https://www.aphis.usda.gov/aphis/pet-travel'
                )
            )
        )
    );
    
    /**
     * Get instance
     */
    public static function get_instance() {
        if (null === self::$instance) {
            self::$instance = new self();
        }
        return self::$instance;
    }
    
    /**
     * Constructor
     */
    private function __construct() {
        // AJAX handlers
        add_action('wp_ajax_fra_start_ai_review', array($this, 'ajax_start_review'));
        add_action('wp_ajax_fra_get_review_status', array($this, 'ajax_get_review_status'));
        add_action('wp_ajax_fra_approve_change', array($this, 'ajax_approve_change'));
        add_action('wp_ajax_fra_reject_change', array($this, 'ajax_reject_change'));
        add_action('wp_ajax_fra_approve_all', array($this, 'ajax_approve_all'));
        add_action('wp_ajax_fra_reject_all', array($this, 'ajax_reject_all'));
    }
    
    /**
     * Get verifiable data points
     */
    public function get_verifiable_data() {
        return $this->verifiable_data;
    }
    
    /**
     * Get pending reviews
     */
    public function get_pending_reviews() {
        return get_option(self::PENDING_REVIEWS_OPTION, array());
    }
    
    /**
     * Start AI review process
     */
    public function ajax_start_review() {
        check_ajax_referer('fra_admin_nonce', 'nonce');
        
        if (!current_user_can('manage_options')) {
            wp_send_json_error('Unauthorized');
        }
        
        $api_key = get_option('fra_api_key', '');
        if (empty($api_key)) {
            wp_send_json_error('API key not configured. Please set up Claude API in Settings.');
        }
        
        // Start the review
        $results = $this->run_ai_review($api_key);
        
        if (is_wp_error($results)) {
            wp_send_json_error($results->get_error_message());
        }
        
        wp_send_json_success($results);
    }
    
    /**
     * Run AI review on all verifiable data
     */
    private function run_ai_review($api_key) {
        $pending_reviews = array();
        $knowledge_base = get_option('fra_knowledge_base', array());
        
        // Build a comprehensive prompt for Claude
        $data_to_verify = array();
        
        foreach ($this->verifiable_data as $category => $topics) {
            foreach ($topics as $topic_key => $topic_data) {
                foreach ($topic_data['fields'] as $field_key => $field_info) {
                    $data_to_verify[] = array(
                        'category' => $category,
                        'topic' => $topic_key,
                        'field' => $field_key,
                        'label' => $field_info['label'],
                        'current_value' => $field_info['current_value'],
                        'search_query' => $field_info['search_query'],
                        'sources' => $topic_data['source_urls'] ?? array()
                    );
                }
            }
        }
        
        // Call Claude to verify each data point
        $prompt = $this->build_verification_prompt($data_to_verify);
        
        $response = wp_remote_post('https://api.anthropic.com/v1/messages', array(
            'timeout' => 120,
            'headers' => array(
                'Content-Type' => 'application/json',
                'x-api-key' => $api_key,
                'anthropic-version' => '2023-06-01'
            ),
            'body' => json_encode(array(
                'model' => 'claude-sonnet-4-20250514',
                'max_tokens' => 4096,
                'system' => "You are a fact-checker specializing in French immigration, visa, and relocation information. Your job is to verify if data points are still accurate as of the current date. 

For each data point, determine if the current value is still accurate or if it needs updating. If you're not certain about a value, indicate that. Always cite your sources when suggesting updates.

Respond ONLY with valid JSON in the exact format specified.",
                'messages' => array(
                    array('role' => 'user', 'content' => $prompt)
                )
            ))
        ));
        
        if (is_wp_error($response)) {
            return new WP_Error('api_error', 'Failed to connect to Claude API: ' . $response->get_error_message());
        }
        
        $body = json_decode(wp_remote_retrieve_body($response), true);
        
        if (isset($body['error'])) {
            return new WP_Error('api_error', 'Claude API error: ' . ($body['error']['message'] ?? 'Unknown error'));
        }
        
        if (!isset($body['content'][0]['text'])) {
            return new WP_Error('api_error', 'Unexpected API response format');
        }
        
        // Parse Claude's response
        $ai_response = $body['content'][0]['text'];
        
        // Extract JSON from response (handle potential markdown code blocks)
        $ai_response = preg_replace('/```json\s*/', '', $ai_response);
        $ai_response = preg_replace('/```\s*/', '', $ai_response);
        $ai_response = trim($ai_response);
        
        $verification_results = json_decode($ai_response, true);
        
        if (json_last_error() !== JSON_ERROR_NONE) {
            return new WP_Error('parse_error', 'Failed to parse AI response: ' . json_last_error_msg());
        }
        
        // Process results into pending reviews
        $changes_found = 0;
        $verified_count = 0;
        $uncertain_count = 0;
        
        foreach ($verification_results as $result) {
            $review_item = array(
                'id' => uniqid('review_'),
                'category' => $result['category'],
                'topic' => $result['topic'],
                'field' => $result['field'],
                'label' => $result['label'],
                'current_value' => $result['current_value'],
                'status' => $result['status'], // 'verified', 'needs_update', 'uncertain'
                'timestamp' => current_time('timestamp')
            );
            
            if ($result['status'] === 'needs_update') {
                $review_item['suggested_value'] = $result['suggested_value'];
                $review_item['source'] = $result['source'] ?? '';
                $review_item['explanation'] = $result['explanation'] ?? '';
                $pending_reviews[] = $review_item;
                $changes_found++;
            } elseif ($result['status'] === 'uncertain') {
                $review_item['explanation'] = $result['explanation'] ?? 'Unable to verify this data point.';
                $pending_reviews[] = $review_item;
                $uncertain_count++;
            } else {
                $verified_count++;
            }
        }
        
        // Save pending reviews
        update_option(self::PENDING_REVIEWS_OPTION, $pending_reviews);
        
        // Save to history
        $history = get_option(self::REVIEW_HISTORY_OPTION, array());
        $history[] = array(
            'timestamp' => current_time('timestamp'),
            'total_checked' => count($data_to_verify),
            'verified' => $verified_count,
            'changes_found' => $changes_found,
            'uncertain' => $uncertain_count
        );
        // Keep last 20 reviews
        $history = array_slice($history, -20);
        update_option(self::REVIEW_HISTORY_OPTION, $history);
        
        return array(
            'total_checked' => count($data_to_verify),
            'verified' => $verified_count,
            'changes_found' => $changes_found,
            'uncertain' => $uncertain_count,
            'pending_reviews' => $pending_reviews
        );
    }
    
    /**
     * Build verification prompt for Claude
     */
    private function build_verification_prompt($data_to_verify) {
        $current_date = date('F j, Y');
        
        $prompt = "Today is {$current_date}. Please verify the following data points about French immigration, visas, and relocation. For each item, check if the current value is still accurate.\n\n";
        $prompt .= "DATA POINTS TO VERIFY:\n\n";
        
        foreach ($data_to_verify as $index => $item) {
            $prompt .= ($index + 1) . ". **{$item['label']}**\n";
            $prompt .= "   - Category: {$item['category']} / {$item['topic']}\n";
            $prompt .= "   - Current Value: {$item['current_value']}\n";
            $prompt .= "   - Verification Query: {$item['search_query']}\n";
            if (!empty($item['sources'])) {
                $prompt .= "   - Official Sources: " . implode(', ', $item['sources']) . "\n";
            }
            $prompt .= "\n";
        }
        
        $prompt .= "\n\nRespond with a JSON array. For each data point, include:\n";
        $prompt .= "- category: the category name\n";
        $prompt .= "- topic: the topic key\n";
        $prompt .= "- field: the field key\n";
        $prompt .= "- label: the human-readable label\n";
        $prompt .= "- current_value: the current value being checked\n";
        $prompt .= "- status: either 'verified' (correct), 'needs_update' (outdated), or 'uncertain' (can't confirm)\n";
        $prompt .= "- suggested_value: (only if status is 'needs_update') the new correct value\n";
        $prompt .= "- source: (only if status is 'needs_update') where you found the new information\n";
        $prompt .= "- explanation: (if status is 'needs_update' or 'uncertain') brief explanation\n\n";
        
        $prompt .= "Example response format:\n";
        $prompt .= "[\n";
        $prompt .= '  {"category": "visas", "topic": "visitor", "field": "visa_fee", "label": "Visa Application Fee", "current_value": "€99", "status": "verified"},';
        $prompt .= "\n";
        $prompt .= '  {"category": "visas", "topic": "validation", "field": "ofii_tax", "label": "OFII Validation Tax", "current_value": "€200", "status": "needs_update", "suggested_value": "€225", "source": "service-public.fr", "explanation": "Fee increased in January 2025"}';
        $prompt .= "\n]\n\n";
        $prompt .= "Respond ONLY with the JSON array, no other text.";
        
        return $prompt;
    }
    
    /**
     * AJAX: Get review status
     */
    public function ajax_get_review_status() {
        check_ajax_referer('fra_admin_nonce', 'nonce');
        
        if (!current_user_can('manage_options')) {
            wp_send_json_error('Unauthorized');
        }
        
        $pending = $this->get_pending_reviews();
        $history = get_option(self::REVIEW_HISTORY_OPTION, array());
        
        wp_send_json_success(array(
            'pending_count' => count($pending),
            'pending_reviews' => $pending,
            'history' => array_slice($history, -5) // Last 5 reviews
        ));
    }
    
    /**
     * AJAX: Approve a single change
     */
    public function ajax_approve_change() {
        check_ajax_referer('fra_admin_nonce', 'nonce');
        
        if (!current_user_can('manage_options')) {
            wp_send_json_error('Unauthorized');
        }
        
        $review_id = sanitize_text_field($_POST['review_id'] ?? '');
        $pending = $this->get_pending_reviews();
        
        $approved_review = null;
        $new_pending = array();
        
        foreach ($pending as $review) {
            if ($review['id'] === $review_id) {
                $approved_review = $review;
            } else {
                $new_pending[] = $review;
            }
        }
        
        if (!$approved_review) {
            wp_send_json_error('Review not found');
        }
        
        // Apply the change to knowledge base
        if ($approved_review['status'] === 'needs_update' && isset($approved_review['suggested_value'])) {
            $this->apply_change($approved_review);
        }
        
        // Update pending reviews
        update_option(self::PENDING_REVIEWS_OPTION, $new_pending);
        
        wp_send_json_success(array(
            'message' => 'Change approved and applied',
            'remaining' => count($new_pending)
        ));
    }
    
    /**
     * AJAX: Reject a single change
     */
    public function ajax_reject_change() {
        check_ajax_referer('fra_admin_nonce', 'nonce');
        
        if (!current_user_can('manage_options')) {
            wp_send_json_error('Unauthorized');
        }
        
        $review_id = sanitize_text_field($_POST['review_id'] ?? '');
        $pending = $this->get_pending_reviews();
        
        $new_pending = array_filter($pending, function($r) use ($review_id) {
            return $r['id'] !== $review_id;
        });
        
        update_option(self::PENDING_REVIEWS_OPTION, array_values($new_pending));
        
        wp_send_json_success(array(
            'message' => 'Change rejected',
            'remaining' => count($new_pending)
        ));
    }
    
    /**
     * AJAX: Approve all changes
     */
    public function ajax_approve_all() {
        check_ajax_referer('fra_admin_nonce', 'nonce');
        
        if (!current_user_can('manage_options')) {
            wp_send_json_error('Unauthorized');
        }
        
        $pending = $this->get_pending_reviews();
        $applied = 0;
        
        foreach ($pending as $review) {
            if ($review['status'] === 'needs_update' && isset($review['suggested_value'])) {
                $this->apply_change($review);
                $applied++;
            }
        }
        
        update_option(self::PENDING_REVIEWS_OPTION, array());
        
        wp_send_json_success(array(
            'message' => "Applied {$applied} changes",
            'applied' => $applied
        ));
    }
    
    /**
     * AJAX: Reject all changes
     */
    public function ajax_reject_all() {
        check_ajax_referer('fra_admin_nonce', 'nonce');
        
        if (!current_user_can('manage_options')) {
            wp_send_json_error('Unauthorized');
        }
        
        $count = count($this->get_pending_reviews());
        update_option(self::PENDING_REVIEWS_OPTION, array());
        
        wp_send_json_success(array(
            'message' => "Rejected {$count} pending changes",
            'rejected' => $count
        ));
    }
    
    /**
     * Apply a change to the knowledge base
     */
    private function apply_change($review) {
        $knowledge_base = get_option('fra_knowledge_base', array());
        
        $category = $review['category'];
        $topic = $review['topic'];
        $new_value = $review['suggested_value'];
        
        if (!isset($knowledge_base[$category][$topic])) {
            return false;
        }
        
        // Update the content by replacing the old value with the new value
        $old_value = $review['current_value'];
        $content = $knowledge_base[$category][$topic]['content'];
        
        // Replace the old value in the content
        $content = str_replace($old_value, $new_value, $content);
        $knowledge_base[$category][$topic]['content'] = $content;
        
        // Update last verified date
        $knowledge_base[$category][$topic]['lastVerified'] = date('F Y');
        
        // Add update note
        if (!isset($knowledge_base[$category][$topic]['updateHistory'])) {
            $knowledge_base[$category][$topic]['updateHistory'] = array();
        }
        $knowledge_base[$category][$topic]['updateHistory'][] = array(
            'date' => current_time('mysql'),
            'field' => $review['field'],
            'from' => $old_value,
            'to' => $new_value,
            'source' => $review['source'] ?? ''
        );
        
        // Also update the verifiable_data reference
        if (isset($this->verifiable_data[$category][$topic]['fields'][$review['field']])) {
            $this->verifiable_data[$category][$topic]['fields'][$review['field']]['current_value'] = $new_value;
        }
        
        update_option('fra_knowledge_base', $knowledge_base);
        
        return true;
    }
}

// Initialize
FRA_AI_Review::get_instance();
