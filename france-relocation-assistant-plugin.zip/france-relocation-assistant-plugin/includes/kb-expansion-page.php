<?php
/**
 * Knowledge Base Expansion Page
 * 
 * @package France_Relocation_Assistant
 */

if (!defined('ABSPATH')) {
    exit;
}

$api_key = get_option('fra_api_key', '');
$knowledge_base = France_Relocation_Assistant::get_instance()->get_knowledge_base();

$categories = array(
    'visas' => 'Visas & Immigration',
    'property' => 'Property Purchase',
    'healthcare' => 'Healthcare',
    'taxes' => 'Taxes',
    'driving' => 'Driving & Vehicles',
    'shipping' => 'Shipping & Pets',
    'banking' => 'Banking',
    'settling' => 'Settling In'
);

// Handle topic generation
$generated_topic = null;
$generation_error = null;

if (isset($_POST['fra_generate_topic']) && check_admin_referer('fra_kb_nonce')) {
    if (empty($api_key)) {
        $generation_error = 'Please configure your API key in API Settings first.';
    } else {
        $topic_title = sanitize_text_field(wp_unslash($_POST['topic_title'] ?? ''));
        $category = sanitize_text_field(wp_unslash($_POST['category'] ?? ''));
        $additional_context = sanitize_textarea_field(wp_unslash($_POST['additional_context'] ?? ''));
        
        if (empty($topic_title) || empty($category)) {
            $generation_error = 'Please provide both a topic title and category.';
        } else {
            $prompt = "Generate a comprehensive knowledge base entry for a US to France relocation guide about: \"$topic_title\"

Category: {$categories[$category]}

" . (!empty($additional_context) ? "Additional context: $additional_context\n\n" : "") . "

Please respond with a JSON object (no markdown, just raw JSON) containing:
{
    \"title\": \"The topic title\",
    \"keywords\": [\"array\", \"of\", \"search\", \"keywords\", \"at least 8\"],
    \"content\": \"The full content with **bold headers** and • bullet points. Include specific requirements, costs (in euros), timelines, and step-by-step processes where applicable. Content should be 300-500 words.\",
    \"sources\": [
        {\"name\": \"Official Source Name\", \"url\": \"https://official-source.gouv.fr/\"},
        {\"name\": \"Another Source\", \"url\": \"https://another-source.fr/\"}
    ],
    \"lastVerified\": \"" . date('F Y') . "\"
}

Focus on practical, actionable information for Americans relocating to France. Include official French government sources where possible.";

            $response = wp_remote_post('https://api.anthropic.com/v1/messages', array(
                'timeout' => 90,
                'headers' => array(
                    'Content-Type' => 'application/json',
                    'x-api-key' => $api_key,
                    'anthropic-version' => '2023-06-01'
                ),
                'body' => json_encode(array(
                    'model' => 'claude-sonnet-4-20250514',
                    'max_tokens' => 2048,
                    'messages' => array(
                        array('role' => 'user', 'content' => $prompt)
                    )
                ))
            ));
            
            if (is_wp_error($response)) {
                $generation_error = 'API request failed: ' . $response->get_error_message();
            } else {
                $body = json_decode(wp_remote_retrieve_body($response), true);
                
                if (isset($body['error'])) {
                    $generation_error = 'API error: ' . ($body['error']['message'] ?? 'Unknown error');
                } elseif (isset($body['content'][0]['text'])) {
                    $json_text = $body['content'][0]['text'];
                    // Clean up any markdown formatting
                    $json_text = preg_replace('/^```json\s*/', '', $json_text);
                    $json_text = preg_replace('/\s*```$/', '', $json_text);
                    $generated_topic = json_decode($json_text, true);
                    
                    if (!$generated_topic) {
                        $generation_error = 'Failed to parse generated content. Raw response: ' . substr($body['content'][0]['text'], 0, 200);
                    }
                }
            }
        }
    }
}

// Handle saving topic to knowledge base
if (isset($_POST['fra_save_topic']) && check_admin_referer('fra_kb_nonce')) {
    $category = sanitize_text_field(wp_unslash($_POST['save_category'] ?? ''));
    $topic_key = sanitize_key($_POST['topic_key'] ?? '');
    $topic_data = array(
        'title' => sanitize_text_field(wp_unslash($_POST['save_title'] ?? '')),
        'keywords' => array_map('sanitize_text_field', array_map('wp_unslash', explode(',', $_POST['save_keywords'] ?? ''))),
        'content' => wp_kses_post(wp_unslash($_POST['save_content'] ?? '')),
        'sources' => json_decode(wp_unslash($_POST['save_sources'] ?? '[]'), true),
        'lastVerified' => sanitize_text_field(wp_unslash($_POST['save_verified'] ?? date('F Y')))
    );
    
    if (!empty($category) && !empty($topic_key) && !empty($topic_data['title'])) {
        $knowledge_base[$category][$topic_key] = $topic_data;
        update_option('fra_knowledge_base', $knowledge_base);
        echo '<div class="notice notice-success is-dismissible"><p>Topic "' . esc_html($topic_data['title']) . '" saved successfully to ' . esc_html($categories[$category]) . '!</p></div>';
        $knowledge_base = get_option('fra_knowledge_base'); // Refresh
    }
}

// Handle deleting topic
if (isset($_POST['fra_delete_topic']) && check_admin_referer('fra_kb_nonce')) {
    $del_category = sanitize_text_field(wp_unslash($_POST['del_category'] ?? ''));
    $del_key = sanitize_key($_POST['del_key'] ?? '');
    
    if (!empty($del_category) && !empty($del_key) && isset($knowledge_base[$del_category][$del_key])) {
        $deleted_title = $knowledge_base[$del_category][$del_key]['title'];
        unset($knowledge_base[$del_category][$del_key]);
        update_option('fra_knowledge_base', $knowledge_base);
        echo '<div class="notice notice-warning is-dismissible"><p>Topic "' . esc_html($deleted_title) . '" deleted.</p></div>';
    }
}
?>

<div class="wrap fra-admin-wrap">
    <h1>
        <span class="dashicons dashicons-database-add"></span>
        <?php _e('Expand Knowledge Base', 'france-relocation-assistant'); ?>
    </h1>
    
    <div class="fra-admin-header">
        <p class="fra-description">
            <?php _e('Use Claude AI to generate new knowledge base topics, or manually add and edit existing entries.', 'france-relocation-assistant'); ?>
        </p>
    </div>
    
    <?php if ($generation_error): ?>
        <div class="notice notice-error is-dismissible">
            <p><?php echo esc_html($generation_error); ?></p>
        </div>
    <?php endif; ?>
    
    <div class="fra-admin-grid">
        <!-- AI Topic Generator -->
        <div class="fra-card">
            <h2><?php _e('🤖 AI Topic Generator', 'france-relocation-assistant'); ?></h2>
            
            <?php if (empty($api_key)): ?>
                <div class="fra-message fra-message-error">
                    <?php _e('Please configure your Anthropic API key in', 'france-relocation-assistant'); ?> 
                    <a href="<?php echo admin_url('admin.php?page=france-relocation-assistant-settings'); ?>"><?php _e('API Settings', 'france-relocation-assistant'); ?></a>
                </div>
            <?php else: ?>
                <form method="post">
                    <?php wp_nonce_field('fra_kb_nonce'); ?>
                    
                    <table class="form-table">
                        <tr>
                            <th><label for="topic_title"><?php _e('Topic Title', 'france-relocation-assistant'); ?></label></th>
                            <td>
                                <input type="text" name="topic_title" id="topic_title" class="regular-text" 
                                       placeholder="e.g., French Driver's License Test Process" required>
                                <p class="description"><?php _e('What topic should Claude research and write about?', 'france-relocation-assistant'); ?></p>
                            </td>
                        </tr>
                        <tr>
                            <th><label for="category"><?php _e('Category', 'france-relocation-assistant'); ?></label></th>
                            <td>
                                <select name="category" id="category" required>
                                    <?php foreach ($categories as $key => $label): ?>
                                        <option value="<?php echo esc_attr($key); ?>"><?php echo esc_html($label); ?></option>
                                    <?php endforeach; ?>
                                </select>
                            </td>
                        </tr>
                        <tr>
                            <th><label for="additional_context"><?php _e('Additional Context', 'france-relocation-assistant'); ?></label></th>
                            <td>
                                <textarea name="additional_context" id="additional_context" rows="3" class="large-text" 
                                          placeholder="Optional: Any specific aspects to cover, recent changes, or focus areas..."></textarea>
                            </td>
                        </tr>
                    </table>
                    
                    <p class="submit">
                        <input type="submit" name="fra_generate_topic" class="button button-primary" value="<?php _e('Generate Topic with AI', 'france-relocation-assistant'); ?>">
                        <span class="description" style="margin-left: 10px;"><?php _e('~$0.02 per generation', 'france-relocation-assistant'); ?></span>
                    </p>
                </form>
            <?php endif; ?>
        </div>
        
        <!-- Current Knowledge Base -->
        <div class="fra-card">
            <h2><?php _e('📚 Current Knowledge Base', 'france-relocation-assistant'); ?></h2>
            
            <?php foreach ($knowledge_base as $cat_key => $topics): ?>
                <div class="fra-kb-category">
                    <h3><?php echo esc_html($categories[$cat_key] ?? ucfirst($cat_key)); ?> 
                        <span class="fra-topic-count">(<?php echo count($topics); ?>)</span>
                    </h3>
                    <ul class="fra-topic-list">
                        <?php foreach ($topics as $topic_key => $topic): ?>
                            <li>
                                <span class="fra-topic-title"><?php echo esc_html($topic['title']); ?></span>
                                <span class="fra-topic-actions">
                                    <button type="button" class="button-link fra-edit-topic" 
                                            data-category="<?php echo esc_attr($cat_key); ?>"
                                            data-key="<?php echo esc_attr($topic_key); ?>"
                                            data-topic="<?php echo esc_attr(json_encode($topic)); ?>">
                                        <?php _e('Edit', 'france-relocation-assistant'); ?>
                                    </button>
                                    <form method="post" style="display:inline;" onsubmit="return confirm('Delete this topic?');">
                                        <?php wp_nonce_field('fra_kb_nonce'); ?>
                                        <input type="hidden" name="del_category" value="<?php echo esc_attr($cat_key); ?>">
                                        <input type="hidden" name="del_key" value="<?php echo esc_attr($topic_key); ?>">
                                        <button type="submit" name="fra_delete_topic" class="button-link fra-delete-topic">
                                            <?php _e('Delete', 'france-relocation-assistant'); ?>
                                        </button>
                                    </form>
                                </span>
                            </li>
                        <?php endforeach; ?>
                    </ul>
                </div>
            <?php endforeach; ?>
        </div>
        
        <!-- Generated Topic Preview / Editor -->
        <div class="fra-card fra-card-full" id="fra-topic-editor" style="<?php echo $generated_topic ? '' : 'display:none;'; ?>">
            <h2><?php _e('📝 Topic Editor', 'france-relocation-assistant'); ?></h2>
            
            <form method="post">
                <?php wp_nonce_field('fra_kb_nonce'); ?>
                
                <table class="form-table">
                    <tr>
                        <th><label for="save_category"><?php _e('Category', 'france-relocation-assistant'); ?></label></th>
                        <td>
                            <select name="save_category" id="save_category" required>
                                <?php foreach ($categories as $key => $label): ?>
                                    <option value="<?php echo esc_attr($key); ?>" <?php echo $generated_topic && isset($_POST['category']) && $_POST['category'] === $key ? 'selected' : ''; ?>>
                                        <?php echo esc_html($label); ?>
                                    </option>
                                <?php endforeach; ?>
                            </select>
                        </td>
                    </tr>
                    <tr>
                        <th><label for="topic_key"><?php _e('Topic Key', 'france-relocation-assistant'); ?></label></th>
                        <td>
                            <input type="text" name="topic_key" id="topic_key" class="regular-text" required
                                   value="<?php echo $generated_topic ? esc_attr(sanitize_key($generated_topic['title'])) : ''; ?>"
                                   placeholder="unique_topic_key">
                            <p class="description"><?php _e('Unique identifier (lowercase, underscores)', 'france-relocation-assistant'); ?></p>
                        </td>
                    </tr>
                    <tr>
                        <th><label for="save_title"><?php _e('Title', 'france-relocation-assistant'); ?></label></th>
                        <td>
                            <input type="text" name="save_title" id="save_title" class="large-text" required
                                   value="<?php echo $generated_topic ? esc_attr($generated_topic['title']) : ''; ?>">
                        </td>
                    </tr>
                    <tr>
                        <th><label for="save_keywords"><?php _e('Keywords', 'france-relocation-assistant'); ?></label></th>
                        <td>
                            <input type="text" name="save_keywords" id="save_keywords" class="large-text"
                                   value="<?php echo $generated_topic ? esc_attr(implode(', ', $generated_topic['keywords'])) : ''; ?>"
                                   placeholder="keyword1, keyword2, keyword3">
                            <p class="description"><?php _e('Comma-separated search keywords', 'france-relocation-assistant'); ?></p>
                        </td>
                    </tr>
                    <tr>
                        <th><label for="save_content"><?php _e('Content', 'france-relocation-assistant'); ?></label></th>
                        <td>
                            <textarea name="save_content" id="save_content" rows="15" class="large-text" required><?php echo $generated_topic ? esc_textarea($generated_topic['content']) : ''; ?></textarea>
                            <p class="description"><?php _e('Use **text** for bold headers, • for bullet points', 'france-relocation-assistant'); ?></p>
                        </td>
                    </tr>
                    <tr>
                        <th><label for="save_sources_display"><?php _e('Sources', 'france-relocation-assistant'); ?></label></th>
                        <td>
                            <div id="fra-sources-list">
                                <?php if ($generated_topic && !empty($generated_topic['sources'])): ?>
                                    <?php foreach ($generated_topic['sources'] as $i => $source): ?>
                                        <div class="fra-source-row">
                                            <input type="text" class="fra-source-name" placeholder="Source name" value="<?php echo esc_attr($source['name']); ?>">
                                            <input type="url" class="fra-source-url" placeholder="https://..." value="<?php echo esc_attr($source['url']); ?>">
                                            <button type="button" class="button fra-remove-source">×</button>
                                        </div>
                                    <?php endforeach; ?>
                                <?php endif; ?>
                            </div>
                            <button type="button" class="button" id="fra-add-source"><?php _e('+ Add Source', 'france-relocation-assistant'); ?></button>
                            <input type="hidden" name="save_sources" id="save_sources" value="<?php echo $generated_topic ? esc_attr(json_encode($generated_topic['sources'])) : '[]'; ?>">
                        </td>
                    </tr>
                    <tr>
                        <th><label for="save_verified"><?php _e('Last Verified', 'france-relocation-assistant'); ?></label></th>
                        <td>
                            <input type="text" name="save_verified" id="save_verified" class="regular-text"
                                   value="<?php echo $generated_topic ? esc_attr($generated_topic['lastVerified']) : date('F Y'); ?>">
                        </td>
                    </tr>
                </table>
                
                <p class="submit">
                    <input type="submit" name="fra_save_topic" class="button button-primary" value="<?php _e('Save Topic to Knowledge Base', 'france-relocation-assistant'); ?>">
                    <button type="button" class="button" id="fra-cancel-edit"><?php _e('Cancel', 'france-relocation-assistant'); ?></button>
                </p>
            </form>
        </div>
    </div>
</div>

<style>
.fra-kb-category { margin-bottom: 20px; }
.fra-kb-category h3 { margin: 0 0 10px 0; font-size: 14px; }
.fra-topic-list { list-style: none; padding: 0; margin: 0; }
.fra-topic-list li { 
    display: flex; 
    justify-content: space-between; 
    padding: 8px 10px; 
    background: #f9f9f9; 
    margin-bottom: 4px;
    border-radius: 3px;
}
.fra-topic-title { font-size: 13px; }
.fra-topic-actions { display: flex; gap: 10px; }
.fra-delete-topic { color: #dc3232 !important; }
.fra-source-row { display: flex; gap: 10px; margin-bottom: 8px; }
.fra-source-name { width: 200px; }
.fra-source-url { flex: 1; }
.fra-remove-source { color: #dc3232; }
#fra-add-source { margin-top: 5px; }
</style>

<script>
jQuery(document).ready(function($) {
    // Edit topic
    $('.fra-edit-topic').on('click', function() {
        var topic = $(this).data('topic');
        var category = $(this).data('category');
        var key = $(this).data('key');
        
        $('#save_category').val(category);
        $('#topic_key').val(key);
        $('#save_title').val(topic.title);
        $('#save_keywords').val(topic.keywords ? topic.keywords.join(', ') : '');
        $('#save_content').val(topic.content);
        $('#save_verified').val(topic.lastVerified || '<?php echo date('F Y'); ?>');
        
        // Populate sources
        $('#fra-sources-list').empty();
        if (topic.sources) {
            topic.sources.forEach(function(source) {
                addSourceRow(source.name, source.url);
            });
        }
        updateSourcesJson();
        
        $('#fra-topic-editor').show();
        $('html, body').animate({ scrollTop: $('#fra-topic-editor').offset().top - 50 }, 500);
    });
    
    // Cancel edit
    $('#fra-cancel-edit').on('click', function() {
        $('#fra-topic-editor').hide();
    });
    
    // Add source row
    function addSourceRow(name, url) {
        var html = '<div class="fra-source-row">' +
            '<input type="text" class="fra-source-name" placeholder="Source name" value="' + (name || '') + '">' +
            '<input type="url" class="fra-source-url" placeholder="https://..." value="' + (url || '') + '">' +
            '<button type="button" class="button fra-remove-source">×</button>' +
            '</div>';
        $('#fra-sources-list').append(html);
    }
    
    $('#fra-add-source').on('click', function() {
        addSourceRow('', '');
    });
    
    $(document).on('click', '.fra-remove-source', function() {
        $(this).closest('.fra-source-row').remove();
        updateSourcesJson();
    });
    
    $(document).on('change', '.fra-source-name, .fra-source-url', function() {
        updateSourcesJson();
    });
    
    function updateSourcesJson() {
        var sources = [];
        $('.fra-source-row').each(function() {
            var name = $(this).find('.fra-source-name').val();
            var url = $(this).find('.fra-source-url').val();
            if (name || url) {
                sources.push({ name: name, url: url });
            }
        });
        $('#save_sources').val(JSON.stringify(sources));
    }
    
    // Update sources on form submit
    $('form').on('submit', function() {
        updateSourcesJson();
    });
});
</script>
