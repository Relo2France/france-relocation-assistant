<?php
/**
 * Plugin Name: France Relocation Assistant
 * Plugin URI: https://relo2france.com
 * Description: A comprehensive AI-powered tool for US to France relocation guidance. Includes visa information, property purchase guides, healthcare enrollment, tax obligations, and more. Auto-updates weekly from official sources.
 * Version: 2.5.2
 * Author: Relo2France
 * Author URI: https://relo2france.com
 * License: GPL v2 or later
 * License URI: https://www.gnu.org/licenses/gpl-2.0.html
 * Text Domain: france-relocation-assistant
 * Domain Path: /languages
 */

// Prevent direct access
if (!defined('ABSPATH')) {
    exit;
}

// Define plugin constants
define('FRA_VERSION', '2.5.2');
define('FRA_PLUGIN_DIR', plugin_dir_path(__FILE__));
define('FRA_PLUGIN_URL', plugin_dir_url(__FILE__));
define('FRA_PLUGIN_BASENAME', plugin_basename(__FILE__));

/**
 * Main Plugin Class
 */
class France_Relocation_Assistant {
    
    /**
     * Instance of this class
     */
    private static $instance = null;
    
    /**
     * Knowledge base option name
     */
    const KNOWLEDGE_BASE_OPTION = 'fra_knowledge_base';
    
    /**
     * Last update option name
     */
    const LAST_UPDATE_OPTION = 'fra_last_update';
    
    /**
     * Cron hook name
     */
    const CRON_HOOK = 'fra_weekly_update';
    
    /**
     * Get singleton instance
     */
    public static function get_instance() {
        if (null === self::$instance) {
            self::$instance = new self();
        }
        return self::$instance;
    }
    
    /**
     * Constructor
     */
    private function __construct() {
        // Initialize plugin
        add_action('init', array($this, 'init'));
        
        // Register activation/deactivation hooks
        register_activation_hook(__FILE__, array($this, 'activate'));
        register_deactivation_hook(__FILE__, array($this, 'deactivate'));
        
        // Register shortcode
        add_shortcode('france_relocation_assistant', array($this, 'render_shortcode'));
        
        // Register WP-Cron action
        add_action(self::CRON_HOOK, array($this, 'run_weekly_update'));
        
        // Admin menu
        add_action('admin_menu', array($this, 'add_admin_menu'));
        
        // Register settings
        add_action('admin_init', array($this, 'register_settings'));
        
        // AJAX handlers
        add_action('wp_ajax_fra_search', array($this, 'ajax_search'));
        add_action('wp_ajax_nopriv_fra_search', array($this, 'ajax_search'));
        add_action('wp_ajax_fra_manual_update', array($this, 'ajax_manual_update'));
        add_action('wp_ajax_fra_ai_query', array($this, 'ajax_ai_query'));
        add_action('wp_ajax_nopriv_fra_ai_query', array($this, 'ajax_ai_query'));
        
        // Enqueue scripts and styles
        add_action('wp_enqueue_scripts', array($this, 'enqueue_frontend_assets'));
        add_action('admin_enqueue_scripts', array($this, 'enqueue_admin_assets'));
    }
    
    /**
     * Initialize plugin
     */
    public function init() {
        // Load text domain for translations
        load_plugin_textdomain('france-relocation-assistant', false, dirname(FRA_PLUGIN_BASENAME) . '/languages');
    }
    
    /**
     * Plugin activation
     */
    public function activate() {
        // Initialize knowledge base if not exists
        if (!get_option(self::KNOWLEDGE_BASE_OPTION)) {
            $this->initialize_knowledge_base();
        }
        
        // Schedule weekly cron job for Sunday at 1:00 AM
        if (!wp_next_scheduled(self::CRON_HOOK)) {
            // Calculate next Sunday at 1:00 AM
            $next_sunday = $this->get_next_sunday_1am();
            wp_schedule_event($next_sunday, 'weekly', self::CRON_HOOK);
        }
        
        // Log activation
        update_option(self::LAST_UPDATE_OPTION, array(
            'timestamp' => current_time('timestamp'),
            'status' => 'activated',
            'message' => 'Plugin activated successfully'
        ));
        
        // Flush rewrite rules
        flush_rewrite_rules();
    }
    
    /**
     * Plugin deactivation
     */
    public function deactivate() {
        // Remove scheduled cron job
        $timestamp = wp_next_scheduled(self::CRON_HOOK);
        if ($timestamp) {
            wp_unschedule_event($timestamp, self::CRON_HOOK);
        }
        
        // Clear all scheduled hooks
        wp_clear_scheduled_hook(self::CRON_HOOK);
    }
    
    /**
     * Calculate next Sunday at 1:00 AM
     */
    private function get_next_sunday_1am() {
        $timezone = get_option('timezone_string') ?: 'America/New_York';
        $dt = new DateTime('now', new DateTimeZone($timezone));
        
        // Find next Sunday
        $days_until_sunday = (7 - $dt->format('w')) % 7;
        if ($days_until_sunday === 0 && $dt->format('H') >= 1) {
            $days_until_sunday = 7; // If it's Sunday after 1 AM, schedule for next Sunday
        }
        
        $dt->modify("+{$days_until_sunday} days");
        $dt->setTime(1, 0, 0);
        
        return $dt->getTimestamp();
    }
    
    /**
     * Enqueue frontend assets
     */
    public function enqueue_frontend_assets() {
        // We'll enqueue from the shortcode instead for better compatibility
        // This function is kept for potential future use
    }
    
    /**
     * Enqueue frontend assets from shortcode
     */
    private function enqueue_shortcode_assets() {
        // Enqueue CSS
        wp_enqueue_style(
            'fra-frontend-style',
            FRA_PLUGIN_URL . 'assets/css/frontend.css',
            array(),
            FRA_VERSION
        );
        
        // Enqueue JS in footer WITH jQuery dependency
        wp_enqueue_script(
            'fra-frontend-script',
            FRA_PLUGIN_URL . 'assets/js/frontend.js',
            array('jquery'),  // Add jQuery dependency
            FRA_VERSION,
            true
        );
        
        // Localize script with data
        wp_localize_script('fra-frontend-script', 'fraData', array(
            'ajaxUrl' => admin_url('admin-ajax.php'),
            'nonce' => wp_create_nonce('fra_nonce'),
            'lastUpdate' => get_option(self::LAST_UPDATE_OPTION),
            'knowledgeBase' => $this->get_knowledge_base(),
            'aiEnabled' => get_option('fra_enable_ai', false) && !empty(get_option('fra_api_key', ''))
        ));
    }
    
    /**
     * Enqueue admin assets
     */
    public function enqueue_admin_assets($hook) {
        // Load on all FR Assistant pages
        if (strpos($hook, 'france-relocation-assistant') === false) {
            return;
        }
        
        wp_enqueue_style(
            'fra-admin-style',
            FRA_PLUGIN_URL . 'assets/css/admin.css',
            array(),
            FRA_VERSION
        );
        
        wp_enqueue_script(
            'fra-admin-script',
            FRA_PLUGIN_URL . 'assets/js/admin.js',
            array('jquery'),
            FRA_VERSION,
            true
        );
        
        wp_localize_script('fra-admin-script', 'fraAdminData', array(
            'ajaxUrl' => admin_url('admin-ajax.php'),
            'nonce' => wp_create_nonce('fra_admin_nonce')
        ));
        
        // Load media uploader on customizer page
        if (strpos($hook, 'customizer') !== false) {
            wp_enqueue_media();
        }
    }
    
    /**
     * Add admin menu
     */
    public function add_admin_menu() {
        add_menu_page(
            __('France Relocation Assistant', 'france-relocation-assistant'),
            __('FR Assistant', 'france-relocation-assistant'),
            'manage_options',
            'france-relocation-assistant',
            array($this, 'render_admin_page'),
            'dashicons-airplane',
            30
        );
        
        add_submenu_page(
            'france-relocation-assistant',
            __('API Settings', 'france-relocation-assistant'),
            __('API Settings', 'france-relocation-assistant'),
            'manage_options',
            'france-relocation-assistant-settings',
            array($this, 'render_settings_page')
        );
        
        add_submenu_page(
            'france-relocation-assistant',
            __('Expand Knowledge Base', 'france-relocation-assistant'),
            __('Expand KB', 'france-relocation-assistant'),
            'manage_options',
            'france-relocation-assistant-kb',
            array($this, 'render_kb_expansion_page')
        );
        
        add_submenu_page(
            'france-relocation-assistant',
            __('Front-End Customizer', 'france-relocation-assistant'),
            __('Customizer', 'france-relocation-assistant'),
            'manage_options',
            'france-relocation-assistant-customizer',
            array($this, 'render_customizer_page')
        );
        
        add_submenu_page(
            'france-relocation-assistant',
            __('SEO Settings', 'france-relocation-assistant'),
            __('SEO', 'france-relocation-assistant'),
            'manage_options',
            'france-relocation-assistant-seo',
            array($this, 'render_seo_page')
        );
        
        add_submenu_page(
            'france-relocation-assistant',
            __('Membership Settings', 'france-relocation-assistant'),
            __('Membership', 'france-relocation-assistant'),
            'manage_options',
            'france-relocation-assistant-membership',
            array($this, 'render_membership_page')
        );
        
        add_submenu_page(
            'france-relocation-assistant',
            __('AI Review', 'france-relocation-assistant'),
            __('AI Review', 'france-relocation-assistant'),
            'manage_options',
            'france-relocation-assistant-ai-review',
            array($this, 'render_ai_review_page')
        );
    }
    
    /**
     * Render AI Review page
     */
    public function render_ai_review_page() {
        include FRA_PLUGIN_DIR . 'includes/ai-review-page.php';
    }
    
    /**
     * Render membership page
     */
    public function render_membership_page() {
        // Enqueue media uploader
        wp_enqueue_media();
        include FRA_PLUGIN_DIR . 'includes/membership-page.php';
    }
    
    /**
     * Render customizer page
     */
    public function render_customizer_page() {
        include FRA_PLUGIN_DIR . 'includes/customizer-page.php';
    }
    
    /**
     * Render SEO page
     */
    public function render_seo_page() {
        include FRA_PLUGIN_DIR . 'includes/seo-page.php';
    }
    
    /**
     * Render KB expansion page
     */
    public function render_kb_expansion_page() {
        include FRA_PLUGIN_DIR . 'includes/kb-expansion-page.php';
    }
    
    /**
     * Render settings page
     */
    public function render_settings_page() {
        include FRA_PLUGIN_DIR . 'includes/settings-page.php';
    }
    
    /**
     * Render admin page
     */
    public function render_admin_page() {
        $last_update = get_option(self::LAST_UPDATE_OPTION, array());
        $next_scheduled = wp_next_scheduled(self::CRON_HOOK);
        $knowledge_base = $this->get_knowledge_base();
        
        include FRA_PLUGIN_DIR . 'includes/admin-page.php';
    }
    
    /**
     * Render shortcode
     */
    public function render_shortcode($atts) {
        // Enqueue assets when shortcode is rendered
        $this->enqueue_shortcode_assets();
        
        // Track page view for analytics
        do_action('fra_shortcode_rendered');
        
        $atts = shortcode_atts(array(
            'theme' => 'light',
            'show_day_counter' => 'true'
        ), $atts, 'france_relocation_assistant');
        
        ob_start();
        include FRA_PLUGIN_DIR . 'includes/shortcode-template.php';
        return ob_get_clean();
    }
    
    /**
     * AJAX search handler
     */
    public function ajax_search() {
        check_ajax_referer('fra_nonce', 'nonce');
        
        $query = sanitize_text_field($_POST['query'] ?? '');
        
        if (empty($query)) {
            wp_send_json_error('Query is required');
        }
        
        $results = $this->search_knowledge_base($query);
        
        wp_send_json_success($results);
    }
    
    /**
     * AJAX manual update handler (admin only)
     */
    public function ajax_manual_update() {
        check_ajax_referer('fra_admin_nonce', 'nonce');
        
        if (!current_user_can('manage_options')) {
            wp_send_json_error('Unauthorized');
        }
        
        $result = $this->run_weekly_update();
        
        wp_send_json_success($result);
    }
    
    /**
     * Search knowledge base
     */
    public function search_knowledge_base($query) {
        $knowledge_base = $this->get_knowledge_base();
        $query_lower = strtolower($query);
        $results = array();
        
        foreach ($knowledge_base as $category => $topics) {
            foreach ($topics as $topic_key => $topic) {
                $score = 0;
                
                // Check keywords
                foreach ($topic['keywords'] as $keyword) {
                    if (strpos($query_lower, strtolower($keyword)) !== false) {
                        $score += 10;
                    }
                    // Partial match
                    if (strpos(strtolower($keyword), $query_lower) !== false) {
                        $score += 5;
                    }
                }
                
                // Check title
                if (strpos(strtolower($topic['title']), $query_lower) !== false) {
                    $score += 8;
                }
                
                // Check content
                $words = array_filter(explode(' ', $query_lower), function($w) {
                    return strlen($w) > 3;
                });
                foreach ($words as $word) {
                    if (strpos(strtolower($topic['content']), $word) !== false) {
                        $score += 2;
                    }
                }
                
                if ($score > 0) {
                    $results[] = array_merge($topic, array(
                        'score' => $score,
                        'category' => $category,
                        'topicKey' => $topic_key
                    ));
                }
            }
        }
        
        // Sort by score descending
        usort($results, function($a, $b) {
            return $b['score'] - $a['score'];
        });
        
        return $results;
    }
    
    /**
     * Run weekly update
     */
    public function run_weekly_update() {
        $update_log = array(
            'timestamp' => current_time('timestamp'),
            'status' => 'running',
            'updates' => array(),
            'added_count' => 0,
            'updated_count' => 0
        );
        
        try {
            // Fetch updates from official sources
            $updates = $this->fetch_official_updates();
            
            // Update knowledge base
            $knowledge_base = $this->get_knowledge_base();
            
            foreach ($updates as $category => $category_updates) {
                foreach ($category_updates as $topic_key => $topic_updates) {
                    if (isset($knowledge_base[$category][$topic_key])) {
                        // Track if anything actually changed
                        $changed = false;
                        foreach ($topic_updates as $field => $value) {
                            if (!isset($knowledge_base[$category][$topic_key][$field]) || 
                                $knowledge_base[$category][$topic_key][$field] !== $value) {
                                $knowledge_base[$category][$topic_key][$field] = $value;
                                $changed = true;
                            }
                        }
                        if ($changed) {
                            $knowledge_base[$category][$topic_key]['lastVerified'] = date('F Y');
                            $update_log['updates'][] = "{$category}/{$topic_key}: Updated";
                            $update_log['updated_count']++;
                        }
                    } else {
                        // New topic
                        if (!isset($knowledge_base[$category])) {
                            $knowledge_base[$category] = array();
                        }
                        $knowledge_base[$category][$topic_key] = $topic_updates;
                        $knowledge_base[$category][$topic_key]['lastVerified'] = date('F Y');
                        $update_log['updates'][] = "{$category}/{$topic_key}: Added";
                        $update_log['added_count']++;
                    }
                }
            }
            
            // Save updated knowledge base
            update_option(self::KNOWLEDGE_BASE_OPTION, $knowledge_base);
            
            $update_log['status'] = 'success';
            $total = $update_log['added_count'] + $update_log['updated_count'];
            if ($total > 0) {
                $update_log['message'] = sprintf(
                    'Knowledge base updated: %d added, %d updated',
                    $update_log['added_count'],
                    $update_log['updated_count']
                );
            } else {
                $update_log['message'] = 'Knowledge base is already up to date';
            }
            
        } catch (Exception $e) {
            $update_log['status'] = 'error';
            $update_log['message'] = $e->getMessage();
        }
        
        // Save update log
        update_option(self::LAST_UPDATE_OPTION, $update_log);
        
        // Log to WordPress
        if (defined('WP_DEBUG') && WP_DEBUG) {
            error_log('France Relocation Assistant: Weekly update completed - ' . $update_log['status']);
        }
        
        return $update_log;
    }
    
    /**
     * Fetch updates from official sources
     */
    private function fetch_official_updates() {
        $updates = array();
        
        // France-Visas.gouv.fr - Visa fees and requirements
        $visa_data = $this->fetch_visa_updates();
        if ($visa_data) {
            $updates['visas'] = $visa_data;
        }
        
        // Service-Public.fr - General administrative info
        $admin_data = $this->fetch_admin_updates();
        if ($admin_data) {
            $updates = array_merge_recursive($updates, $admin_data);
        }
        
        // SMIC (minimum wage) for financial requirements
        $smic_data = $this->fetch_smic_update();
        if ($smic_data) {
            $updates['visas']['visiteur']['financial_requirement'] = $smic_data;
        }
        
        return $updates;
    }
    
    /**
     * Fetch visa updates from France-Visas
     */
    private function fetch_visa_updates() {
        $updates = array();
        
        // Note: In production, you would use proper API calls or web scraping
        // This is a placeholder that checks for cached/updated data
        
        $response = wp_remote_get('https://france-visas.gouv.fr/en/long-stay-visa', array(
            'timeout' => 30,
            'headers' => array(
                'User-Agent' => 'France Relocation Assistant WordPress Plugin/' . FRA_VERSION
            )
        ));
        
        if (!is_wp_error($response) && wp_remote_retrieve_response_code($response) === 200) {
            $body = wp_remote_retrieve_body($response);
            
            // Parse for visa fee (€99 as of 2025)
            if (preg_match('/visa fee[:\s]*€?(\d+)/i', $body, $matches)) {
                $updates['visiteur']['visa_fee'] = '€' . $matches[1];
            }
            
            // Mark as verified
            $updates['visiteur']['lastVerified'] = date('F Y');
        }
        
        return $updates;
    }
    
    /**
     * Fetch administrative updates from Service-Public
     */
    private function fetch_admin_updates() {
        $updates = array();
        
        // OFII validation fee check
        $response = wp_remote_get('https://www.service-public.fr/particuliers/vosdroits/F16162', array(
            'timeout' => 30,
            'headers' => array(
                'User-Agent' => 'France Relocation Assistant WordPress Plugin/' . FRA_VERSION
            )
        ));
        
        if (!is_wp_error($response) && wp_remote_retrieve_response_code($response) === 200) {
            $body = wp_remote_retrieve_body($response);
            
            // Parse for OFII tax amount
            if (preg_match('/€?(\d{2,3})\s*(?:euros?|€)?\s*(?:tax|timbre|stamp)/i', $body, $matches)) {
                $updates['visas']['ofiiValidation']['tax_amount'] = '€' . $matches[1];
            }
        }
        
        return $updates;
    }
    
    /**
     * Fetch current SMIC (minimum wage)
     */
    private function fetch_smic_update() {
        // SMIC is updated annually on January 1
        // 2025 SMIC net: approximately €1,450/month
        
        $response = wp_remote_get('https://www.service-public.fr/particuliers/vosdroits/F2300', array(
            'timeout' => 30
        ));
        
        if (!is_wp_error($response) && wp_remote_retrieve_response_code($response) === 200) {
            $body = wp_remote_retrieve_body($response);
            
            // Parse for SMIC mensuel net
            if (preg_match('/(\d[\d\s,\.]+)\s*€?\s*(?:net|mensuel)/i', $body, $matches)) {
                $smic = str_replace(array(' ', ','), array('', '.'), $matches[1]);
                return '€' . number_format((float)$smic, 0);
            }
        }
        
        return null;
    }
    
    /**
     * Register plugin settings
     */
    public function register_settings() {
        register_setting('fra_settings', 'fra_api_key', array(
            'type' => 'string',
            'sanitize_callback' => 'sanitize_text_field',
            'default' => ''
        ));
        
        register_setting('fra_settings', 'fra_api_model', array(
            'type' => 'string',
            'sanitize_callback' => 'sanitize_text_field',
            'default' => 'claude-sonnet-4-20250514'
        ));
        
        register_setting('fra_settings', 'fra_enable_ai', array(
            'type' => 'boolean',
            'sanitize_callback' => 'rest_sanitize_boolean',
            'default' => false
        ));
        
        // GitHub Pages URL setting
        register_setting('fra_embed_settings', 'fra_github_url', array(
            'type' => 'string',
            'sanitize_callback' => 'esc_url_raw',
            'default' => ''
        ));
    }
    
    /**
     * AJAX handler for AI queries (Tier 2)
     */
    public function ajax_ai_query() {
        check_ajax_referer('fra_nonce', 'nonce');
        
        // Accept both 'query' and 'message' for compatibility
        $query = sanitize_text_field($_POST['message'] ?? $_POST['query'] ?? '');
        $context = sanitize_textarea_field($_POST['context'] ?? '');
        
        if (empty($query)) {
            wp_send_json_error('Query is required');
        }
        
        // Check if AI is enabled
        if (!get_option('fra_enable_ai', false)) {
            wp_send_json_error('AI responses are not enabled');
        }
        
        $api_key = get_option('fra_api_key', '');
        if (empty($api_key)) {
            wp_send_json_error('API key not configured');
        }
        
        $model = get_option('fra_api_model', 'claude-sonnet-4-20250514');
        
        // Build the prompt with context
        $system_prompt = "You are a helpful assistant specializing in US to France relocation. Provide accurate, practical information about visas, immigration, property purchase, healthcare, taxes, and settling in France. Always recommend consulting professionals (immigration attorneys, tax advisors, notaires) for specific situations. Be concise but thorough.";
        
        $user_message = $query;
        if (!empty($context)) {
            $user_message = "Context from knowledge base:\n" . $context . "\n\nUser question: " . $query;
        }
        
        // Call Anthropic API
        $response = wp_remote_post('https://api.anthropic.com/v1/messages', array(
            'timeout' => 60,
            'headers' => array(
                'Content-Type' => 'application/json',
                'x-api-key' => $api_key,
                'anthropic-version' => '2023-06-01'
            ),
            'body' => json_encode(array(
                'model' => $model,
                'max_tokens' => 1024,
                'system' => $system_prompt,
                'messages' => array(
                    array('role' => 'user', 'content' => $user_message)
                )
            ))
        ));
        
        if (is_wp_error($response)) {
            wp_send_json_error('API request failed: ' . $response->get_error_message());
        }
        
        $body = json_decode(wp_remote_retrieve_body($response), true);
        
        if (isset($body['error'])) {
            wp_send_json_error('API error: ' . ($body['error']['message'] ?? 'Unknown error'));
        }
        
        if (isset($body['content'][0]['text'])) {
            wp_send_json_success(array(
                'response' => $body['content'][0]['text'],
                'model' => $model,
                'usage' => $body['usage'] ?? null
            ));
        } else {
            wp_send_json_error('Unexpected API response format');
        }
    }
    
    /**
     * Get knowledge base
     */
    public function get_knowledge_base() {
        $knowledge_base = get_option(self::KNOWLEDGE_BASE_OPTION);
        $kb_version = get_option('fra_kb_version', '1.0');
        
        // Force reload if version mismatch (new structure in v2.0)
        if (!$knowledge_base || version_compare($kb_version, '2.0', '<')) {
            $this->initialize_knowledge_base();
            update_option('fra_kb_version', '2.0');
            $knowledge_base = get_option(self::KNOWLEDGE_BASE_OPTION);
        }
        
        return $knowledge_base;
    }
    
    /**
     * Initialize knowledge base with default data
     */
    private function initialize_knowledge_base() {
        $knowledge_base = $this->get_default_knowledge_base();
        update_option(self::KNOWLEDGE_BASE_OPTION, $knowledge_base);
    }
    
    /**
     * Get default knowledge base
     */
    private function get_default_knowledge_base() {
        // Load from JSON file for easier maintenance
        $json_file = FRA_PLUGIN_DIR . 'includes/knowledge-base.json';
        
        if (file_exists($json_file)) {
            $json = file_get_contents($json_file);
            return json_decode($json, true);
        }
        
        // Fallback to embedded data
        return include FRA_PLUGIN_DIR . 'includes/knowledge-base-default.php';
    }
}

// Include SEO module
require_once FRA_PLUGIN_DIR . 'includes/class-fra-seo.php';

// Include Membership module
require_once FRA_PLUGIN_DIR . 'includes/class-fra-membership.php';

// Include Auto-Updater
require_once FRA_PLUGIN_DIR . 'includes/class-fra-updater.php';

// Initialize plugin
function fra_init() {
    return France_Relocation_Assistant::get_instance();
}

// Start the plugin
add_action('plugins_loaded', 'fra_init');

/**
 * Add custom cron schedule for weekly
 */
function fra_add_cron_schedule($schedules) {
    if (!isset($schedules['weekly'])) {
        $schedules['weekly'] = array(
            'interval' => 604800, // 7 days in seconds
            'display' => __('Once Weekly', 'france-relocation-assistant')
        );
    }
    return $schedules;
}
add_filter('cron_schedules', 'fra_add_cron_schedule');

// Load additional classes
require_once FRA_PLUGIN_DIR . 'includes/class-fra-membership.php';
require_once FRA_PLUGIN_DIR . 'includes/class-fra-seo.php';
require_once FRA_PLUGIN_DIR . 'includes/class-fra-updater.php';
require_once FRA_PLUGIN_DIR . 'includes/class-fra-ai-review.php';
require_once FRA_PLUGIN_DIR . 'includes/class-fra-site-header.php';
require_once FRA_PLUGIN_DIR . 'includes/class-fra-analytics.php';
