<?php
/**
 * Plugin Name: Relo2France AI Forms
 * Plugin URI: https://relo2france.com
 * Description: AI-powered document assistants for French visa and relocation forms. Requires France Relocation Assistant plugin.
 * Version: 1.1.0
 * Author: Relo2France
 * Author URI: https://relo2france.com
 * License: GPL v2 or later
 * License URI: https://www.gnu.org/licenses/gpl-2.0.html
 * Text Domain: relo2france-ai-forms
 * Domain Path: /languages
 */

// Prevent direct access
if (!defined('ABSPATH')) {
    exit;
}

/**
 * Check if required plugin is active
 */
function rfai_check_required_plugin() {
    // Check if the main plugin class exists (it's loaded by plugins_loaded)
    if (!class_exists('France_Relocation_Assistant')) {
        add_action('admin_notices', 'rfai_missing_plugin_notice');
        return false;
    }
    return true;
}

/**
 * Show admin notice if main plugin is missing
 */
function rfai_missing_plugin_notice() {
    ?>
    <div class="notice notice-error">
        <p><strong>Relo2France AI Forms</strong> requires the <strong>France Relocation Assistant</strong> plugin to be installed and activated. Please activate France Relocation Assistant first.</p>
    </div>
    <?php
}

// Define plugin constants
define('RFAI_VERSION', '1.1.0');
define('RFAI_PLUGIN_DIR', plugin_dir_path(__FILE__));
define('RFAI_PLUGIN_URL', plugin_dir_url(__FILE__));
define('RFAI_PLUGIN_BASENAME', plugin_basename(__FILE__));

/**
 * Main Plugin Class
 */
class Relo2France_AI_Forms {
    
    /**
     * Instance
     */
    private static $instance = null;
    
    /**
     * Get instance
     */
    public static function get_instance() {
        if (null === self::$instance) {
            self::$instance = new self();
        }
        return self::$instance;
    }
    
    /**
     * Constructor
     */
    private function __construct() {
        // Check dependencies on plugins_loaded
        add_action('plugins_loaded', array($this, 'check_dependencies'), 5);
        
        // Admin menu
        add_action('admin_menu', array($this, 'add_admin_menu'));
        
        // Register settings
        add_action('admin_init', array($this, 'register_settings'));
        
        // Enqueue assets
        add_action('wp_enqueue_scripts', array($this, 'enqueue_frontend_assets'));
        add_action('admin_enqueue_scripts', array($this, 'enqueue_admin_assets'));
        
        // Register shortcodes
        add_shortcode('rfai_form_assistant', array($this, 'render_form_assistant'));
        add_shortcode('rfai_forms_list', array($this, 'render_forms_list'));
        
        // AJAX handlers
        add_action('wp_ajax_rfai_chat_message', array($this, 'ajax_chat_message'));
        add_action('wp_ajax_rfai_save_progress', array($this, 'ajax_save_progress'));
        add_action('wp_ajax_rfai_load_progress', array($this, 'ajax_load_progress'));
        add_action('wp_ajax_rfai_generate_document', array($this, 'ajax_generate_document'));
        
        // Hook into main plugin
        add_filter('fra_ai_forms_enabled', array($this, 'is_enabled'));
        add_action('fra_premium_resources_after', array($this, 'add_forms_section'));
    }
    
    /**
     * Check if main plugin exists and AI Forms is enabled
     */
    public function check_dependencies() {
        if (!class_exists('France_Relocation_Assistant')) {
            add_action('admin_notices', array($this, 'dependency_notice'));
            return false;
        }
        return true;
    }
    
    /**
     * Show dependency notice
     */
    public function dependency_notice() {
        ?>
        <div class="notice notice-error">
            <p><strong>Relo2France AI Forms</strong> requires the <strong>France Relocation Assistant</strong> plugin to be installed and activated.</p>
        </div>
        <?php
    }
    
    /**
     * Check if AI Forms is enabled in main plugin
     */
    public function is_enabled() {
        return get_option('fra_enable_ai_forms', false);
    }
    
    /**
     * Plugin activation
     */
    public function activate() {
        // Create default forms
        if (!get_option('rfai_forms')) {
            $this->install_default_forms();
        }
        
        // Create progress table
        $this->create_tables();
        
        flush_rewrite_rules();
    }
    
    /**
     * Plugin deactivation
     */
    public function deactivate() {
        flush_rewrite_rules();
    }
    
    /**
     * Create database tables
     */
    private function create_tables() {
        global $wpdb;
        
        $table_name = $wpdb->prefix . 'rfai_progress';
        $charset_collate = $wpdb->get_charset_collate();
        
        $sql = "CREATE TABLE IF NOT EXISTS $table_name (
            id bigint(20) NOT NULL AUTO_INCREMENT,
            user_id bigint(20) NOT NULL,
            form_id varchar(50) NOT NULL,
            progress_data longtext NOT NULL,
            completed tinyint(1) DEFAULT 0,
            created_at datetime DEFAULT CURRENT_TIMESTAMP,
            updated_at datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
            PRIMARY KEY (id),
            KEY user_form (user_id, form_id)
        ) $charset_collate;";
        
        require_once(ABSPATH . 'wp-admin/includes/upgrade.php');
        dbDelta($sql);
    }
    
    /**
     * Install default forms
     */
    private function install_default_forms() {
        $default_forms = array(
            'cover_letter' => array(
                'title' => 'Visa Cover Letter',
                'description' => 'Create a professional cover letter for your French long-stay visa application.',
                'icon' => '📝',
                'category' => 'visa',
                'language' => 'english',
                'enabled' => true,
                'order' => 1,
                'system_prompt' => $this->get_default_system_prompt('cover_letter'),
                'questions' => $this->get_default_questions('cover_letter'),
                'template' => $this->get_default_template('cover_letter'),
            ),
            'attestation_honor' => array(
                'title' => 'Attestation on Honor (No Work)',
                'description' => 'Declaration that you will not work in France during your visa validity.',
                'icon' => '✋',
                'category' => 'visa',
                'language' => 'bilingual',
                'enabled' => true,
                'order' => 2,
                'system_prompt' => $this->get_default_system_prompt('attestation_honor'),
                'questions' => $this->get_default_questions('attestation_honor'),
                'template' => $this->get_default_template('attestation_honor'),
            ),
            'proof_accommodation' => array(
                'title' => 'Proof of Accommodation',
                'description' => 'Letter proving your accommodation arrangements in France.',
                'icon' => '🏠',
                'category' => 'visa',
                'language' => 'bilingual',
                'enabled' => true,
                'order' => 3,
                'system_prompt' => $this->get_default_system_prompt('proof_accommodation'),
                'questions' => $this->get_default_questions('proof_accommodation'),
                'template' => $this->get_default_template('proof_accommodation'),
            ),
            'financial_statement' => array(
                'title' => 'Financial Resources Statement',
                'description' => 'Detailed statement of your financial resources for visa application.',
                'icon' => '💰',
                'category' => 'visa',
                'language' => 'english',
                'enabled' => true,
                'order' => 4,
                'system_prompt' => $this->get_default_system_prompt('financial_statement'),
                'questions' => $this->get_default_questions('financial_statement'),
                'template' => $this->get_default_template('financial_statement'),
            ),
            'relocation_checklist' => array(
                'title' => 'Personalized Relocation Checklist',
                'description' => 'Custom checklist based on your specific situation and timeline.',
                'icon' => '✅',
                'category' => 'planning',
                'language' => 'english',
                'enabled' => true,
                'order' => 5,
                'system_prompt' => $this->get_default_system_prompt('relocation_checklist'),
                'questions' => $this->get_default_questions('relocation_checklist'),
                'template' => $this->get_default_template('relocation_checklist'),
            ),
        );
        
        update_option('rfai_forms', $default_forms);
    }
    
    /**
     * Get default system prompt for a form
     */
    private function get_default_system_prompt($form_id) {
        $prompts = array(
            'cover_letter' => "You are an expert assistant helping users create professional visa cover letters for French long-stay visa applications.

Your role:
- Ask questions one at a time to gather necessary information
- Be warm, helpful, and explain why each piece of information matters
- Stay focused ONLY on the cover letter - do not answer unrelated questions
- When you have all information, generate a formal, professional cover letter

Information to collect:
1. Full legal name (as on passport)
2. Consulate location (city where applying)
3. Visa type (Visitor VLS-TS Visiteur, Work, Talent Passport, Student)
4. Spouse/partner info - are they applying together? Name?
5. Property in France - address, purchase price, status (compromis signed? closing date?)
6. Personal motivation for moving to France
7. Work/retirement situation (retired, remote worker, CEO, etc.)
8. Will you work in France? (for visitor visa, must state no professional activity)
9. Financial resources:
   - Employment income (salary, bonus)
   - Bank account balances
   - Retirement accounts (401k, IRA)
   - Investment accounts
   - Any other assets
10. Health insurance status (must cover full visa period, medical, hospitalization, repatriation)

DOCUMENT FORMAT - Generate the letter in this exact structure:

Date: [Current Date]

Consulate General of France
Visa Section
[City], [State/Country]

**Subject:** [Visa Type] Application (e.g., Long-Stay Visitor Visa Application (VLS-TS Visiteur))

Dear Visa Officer,

[Opening paragraph: State purpose of letter, mention spouse if applying together, mention property purchase]

**[Our Property in France]** (underlined heading)
[Details about property: address, price, notaire, status, contingencies, expected closing date]
[Personal motivation: why France, connection to region, plans for property]

**[My Personal Situation]** (underlined heading)
[Work/retirement status, no professional activity statement for visitor visa, how they will spend their time]

**[Financial Resources]** (underlined heading)
[Introduction stating self-sufficiency]
Bullet points:
• Employment/retirement income with amounts
• Retirement savings with amounts
• Bank accounts with amounts
• Investments with amounts
[Statement comparing resources to minimum requirements]

**[Health Insurance]** (underlined heading)
[Confirm comprehensive coverage, duration, what it covers]

**[Conclusion]** (underlined heading)
[Express excitement, confirm preparedness, request approval, offer to provide additional documentation]

Respectfully submitted,

_________________________________
[Full Name]
Date: _________________

Style: Formal, professional, suitable for French consulate submission. Use confident but respectful tone.",

            'attestation_honor' => "You are helping users create an Attestation sur l'Honneur (Attestation on Honor) declaring they will not work in France.

Your role:
- Collect only essential information for this legal declaration
- Explain that this is a formal legal document
- Output in BOTH French and English
- Stay strictly focused on this document only

Information to collect:
1. Full legal name
2. Date of birth
3. Place of birth
4. Passport number
5. Nationality
6. Current address
7. Visa type being applied for

The document must clearly state the person commits to not exercising any professional activity in France during their visa validity.",

            'proof_accommodation' => "You are helping users create a Proof of Accommodation letter for their French visa application.

Your role:
- Determine the type of accommodation (owned property, rental, staying with family/friends)
- Collect relevant details for their situation
- Output in BOTH French and English
- Stay focused only on accommodation proof

For OWNED property, collect:
- Property address in France
- Purchase status (owned, in process)
- Notaire name if applicable

For RENTAL, collect:
- Property address
- Landlord name
- Lease dates

For STAYING WITH SOMEONE, collect:
- Host's full name
- Host's address
- Relationship to applicant",

            'financial_statement' => "You are helping users create a Financial Resources Statement for their French visa application.

Your role:
- Gather comprehensive financial information
- Help organize it in a clear, professional format
- Calculate totals and show visa requirement compliance
- Stay focused only on financial documentation

Information to collect:
1. Employment status and income (salary, self-employment, retirement)
2. Bank account balances
3. Investment accounts
4. Retirement accounts (401k, IRA, etc.)
5. Property owned
6. Other assets
7. If couple: whose name assets are in

Show how resources meet/exceed the minimum requirement (approximately €1,850/month for a single person, more for couples).",

            'relocation_checklist' => "You are helping users create a personalized relocation checklist for their move to France.

Your role:
- Understand their specific situation and timeline
- Generate a customized, chronological checklist
- Include specific tasks relevant to THEIR situation
- Stay focused on relocation planning only

Information to collect:
1. Target move date
2. Current location
3. Visa type
4. Property situation (buying, renting, TBD)
5. Family situation (single, couple, children, pets)
6. Employment situation
7. What they're shipping (furniture, car, minimal)
8. Any special circumstances (medical needs, business, etc.)

Generate a timeline-based checklist with specific action items and deadlines.",
        );
        
        return $prompts[$form_id] ?? '';
    }
    
    /**
     * Get default questions for a form
     */
    private function get_default_questions($form_id) {
        $questions = array(
            'cover_letter' => array(
                array('key' => 'full_name', 'question' => "Let's create your visa cover letter! What is your full legal name as it appears on your passport?"),
                array('key' => 'address', 'question' => "What is your current address?"),
                array('key' => 'email', 'question' => "What email address should be on the letter?"),
                array('key' => 'spouse', 'question' => "Are you applying with a spouse or partner? If yes, what is their full name? (Say 'no' if applying alone)"),
                array('key' => 'visa_type', 'question' => "What type of visa are you applying for?\n• Visitor (Visiteur) - You won't work in France\n• Talent Passport - Skilled professional\n• Work Visa - Employment with French company\n• Student - Studying in France"),
                array('key' => 'accommodation', 'question' => "What is your accommodation situation in France? (Owning, renting, address if known)"),
                array('key' => 'work_situation', 'question' => "What is your current work situation?\n• Retired\n• Remote worker (non-French company)\n• Self-employed (outside France)\n• Not currently working"),
                array('key' => 'finances', 'question' => "Please summarize your financial resources:\n• Income (amount and source)\n• Savings and investments\n• Other assets"),
                array('key' => 'insurance', 'question' => "Do you have health insurance that covers France? Please briefly describe."),
                array('key' => 'motivation', 'question' => "Finally, why do you want to live in France? (2-3 sentences about your motivation)"),
            ),
            'attestation_honor' => array(
                array('key' => 'full_name', 'question' => "I'll help you create your Attestation on Honor. What is your full legal name?"),
                array('key' => 'dob', 'question' => "What is your date of birth?"),
                array('key' => 'pob', 'question' => "What is your place of birth (city, state/country)?"),
                array('key' => 'passport', 'question' => "What is your passport number?"),
                array('key' => 'nationality', 'question' => "What is your nationality?"),
                array('key' => 'address', 'question' => "What is your current address?"),
                array('key' => 'visa_type', 'question' => "What type of visa are you applying for?"),
            ),
            'proof_accommodation' => array(
                array('key' => 'accom_type', 'question' => "Let's create your proof of accommodation. What is your situation?\n• I own/am buying property in France\n• I am renting in France\n• I am staying with family or friends"),
                array('key' => 'full_name', 'question' => "What is your full legal name?"),
                array('key' => 'address_france', 'question' => "What is the address of your accommodation in France?"),
                array('key' => 'details', 'question' => "Please provide additional details:\n• If owned: Purchase status, notaire name\n• If renting: Landlord name, lease dates\n• If staying with someone: Host's name, relationship"),
            ),
            'financial_statement' => array(
                array('key' => 'full_name', 'question' => "Let's prepare your financial statement. What is your full legal name?"),
                array('key' => 'spouse', 'question' => "Are you applying with a spouse/partner? (This affects the minimum requirement)"),
                array('key' => 'employment', 'question' => "What is your employment/income situation?\n• Salary (amount, employer)\n• Self-employed (income)\n• Retired (pension/social security)\n• Investment income"),
                array('key' => 'bank_accounts', 'question' => "What are your liquid bank balances? (Checking, savings, money market)"),
                array('key' => 'investments', 'question' => "Do you have investment accounts? (Brokerage, stocks, bonds - approximate value)"),
                array('key' => 'retirement', 'question' => "Do you have retirement accounts? (401k, IRA, pension - approximate value)"),
                array('key' => 'property', 'question' => "Do you own any real estate? (Approximate equity)"),
                array('key' => 'other', 'question' => "Any other significant assets? (Business ownership, vehicles, etc.)"),
            ),
            'relocation_checklist' => array(
                array('key' => 'move_date', 'question' => "When are you planning to move to France? (Approximate date)"),
                array('key' => 'current_location', 'question' => "Where are you currently located?"),
                array('key' => 'visa_type', 'question' => "What type of visa will you have?"),
                array('key' => 'property', 'question' => "What is your property situation?\n• Buying in France\n• Renting in France\n• Still deciding"),
                array('key' => 'family', 'question' => "Who is moving with you? (Spouse, children, pets?)"),
                array('key' => 'employment', 'question' => "What is your employment situation after the move?"),
                array('key' => 'shipping', 'question' => "What are you planning to ship?\n• Full household\n• Partial (some furniture)\n• Minimal (suitcases only)\n• Shipping a vehicle"),
                array('key' => 'special', 'question' => "Any special circumstances? (Medical needs, business to wind down, etc.)"),
            ),
        );
        
        return $questions[$form_id] ?? array();
    }
    
    /**
     * Get default template for a form
     */
    private function get_default_template($form_id) {
        // Templates will be used by AI to structure the output
        // These are simplified - the AI uses them as guidance
        $templates = array(
            'cover_letter' => "VISA COVER LETTER TEMPLATE\n\n[Full Name]\n[Address]\n[Email]\n[Date]\n\nConsulate General of France\nVisa Section\n\nSubject: Long-Stay Visa Application (VLS-TS [Visa Type])\n\nDear Visa Officer,\n\n[Introduction paragraph]\n\n[Accommodation section]\n\n[Personal/Work situation section]\n\n[Financial resources section]\n\n[Health insurance section]\n\n[Motivation/Conclusion]\n\nRespectfully submitted,\n\n[Signature line]\n[Full Name]\nDate: ___________",
            
            'attestation_honor' => "ATTESTATION SUR L'HONNEUR / ATTESTATION ON HONOR\n\n[French version]\nJe soussigné(e), [Nom complet], né(e) le [Date] à [Lieu], de nationalité [Nationalité], titulaire du passeport n° [Numéro],\n\nAtteste sur l'honneur que je n'exercerai aucune activité professionnelle en France pendant la durée de validité de mon visa [Type de visa].\n\nFait à [Ville], le [Date]\n\nSignature: _______________\n\n---\n\n[English version]\nI, the undersigned, [Full Name], born on [Date] in [Place], of [Nationality] nationality, holder of passport no. [Number],\n\nHereby declare on my honor that I will not exercise any professional activity in France during the validity of my [Visa Type] visa.\n\nDone at [City], on [Date]\n\nSignature: _______________",
            
            'proof_accommodation' => "ATTESTATION D'HÉBERGEMENT / PROOF OF ACCOMMODATION\n\n[Adapt based on accommodation type]\n\nFOR OWNED PROPERTY:\nI, [Name], certify that I own/am purchasing property at [Address], France.\n[Purchase details]\n\nFOR RENTAL:\nI, [Name], confirm I have secured rental accommodation at [Address], France.\nLandlord: [Name]\nLease period: [Dates]\n\nFOR HOST:\n[Host declaration format]",
            
            'financial_statement' => "FINANCIAL RESOURCES STATEMENT\n\n[Full Name]\n[Date]\n\nI hereby declare the following financial resources in support of my French visa application:\n\n1. INCOME\n[Employment/income details]\n\n2. LIQUID ASSETS\n[Bank accounts]\n\n3. INVESTMENTS\n[Investment accounts]\n\n4. RETIREMENT ACCOUNTS\n[401k, IRA, etc.]\n\n5. REAL ESTATE\n[Property equity]\n\n6. OTHER ASSETS\n[Other]\n\nTOTAL RESOURCES: [Sum]\n\nMinimum Requirement: [Amount]\nExceeds Requirement By: [Amount]\n\nI certify this information is accurate.\n\nSignature: _______________\nDate: _______________",
            
            'relocation_checklist' => "PERSONALIZED RELOCATION CHECKLIST\n\nPrepared for: [Name]\nTarget Move Date: [Date]\n\n[Organized by timeline: 6+ months before, 3-6 months, 1-3 months, 1 month, moving week, after arrival]\n\n□ Task 1\n□ Task 2\n...",
        );
        
        return $templates[$form_id] ?? '';
    }
    
    /**
     * Add admin menu
     */
    public function add_admin_menu() {
        // Add as submenu under France Relocation Assistant
        add_submenu_page(
            'france-relocation-assistant', // Parent slug
            __('AI Forms', 'relo2france-ai-forms'),
            __('AI Forms', 'relo2france-ai-forms'),
            'manage_options',
            'rfai-forms',
            array($this, 'render_admin_page')
        );
        
        add_submenu_page(
            'france-relocation-assistant',
            __('Add New Form', 'relo2france-ai-forms'),
            __('↳ Add Form', 'relo2france-ai-forms'),
            'manage_options',
            'rfai-forms-new',
            array($this, 'render_form_editor')
        );
        
        add_submenu_page(
            'france-relocation-assistant',
            __('AI Form Builder', 'relo2france-ai-forms'),
            __('↳ Form Builder', 'relo2france-ai-forms'),
            'manage_options',
            'rfai-forms-builder',
            array($this, 'render_form_builder')
        );
        
        add_submenu_page(
            'france-relocation-assistant',
            __('AI Forms Settings', 'relo2france-ai-forms'),
            __('↳ Forms Settings', 'relo2france-ai-forms'),
            'manage_options',
            'rfai-forms-settings',
            array($this, 'render_settings_page')
        );
    }
    
    /**
     * Register settings
     */
    public function register_settings() {
        register_setting('rfai_settings', 'rfai_api_key');
        register_setting('rfai_settings', 'rfai_use_main_api_key');
    }
    
    /**
     * Enqueue frontend assets
     */
    public function enqueue_frontend_assets() {
        // Only on pages with our shortcode
        global $post;
        if (!$post || !has_shortcode($post->post_content, 'rfai_form_assistant')) {
            return;
        }
        
        wp_enqueue_style(
            'rfai-frontend',
            RFAI_PLUGIN_URL . 'assets/css/frontend.css',
            array(),
            RFAI_VERSION
        );
        
        wp_enqueue_script(
            'rfai-frontend',
            RFAI_PLUGIN_URL . 'assets/js/frontend.js',
            array('jquery'),
            RFAI_VERSION,
            true
        );
        
        wp_localize_script('rfai-frontend', 'rfaiData', array(
            'ajaxUrl' => admin_url('admin-ajax.php'),
            'nonce' => wp_create_nonce('rfai_nonce'),
            'userId' => get_current_user_id(),
        ));
    }
    
    /**
     * Enqueue admin assets
     */
    public function enqueue_admin_assets($hook) {
        if (strpos($hook, 'rfai-forms') === false) {
            return;
        }
        
        wp_enqueue_style(
            'rfai-admin',
            RFAI_PLUGIN_URL . 'assets/css/admin.css',
            array(),
            RFAI_VERSION
        );
        
        wp_enqueue_script(
            'rfai-admin',
            RFAI_PLUGIN_URL . 'assets/js/admin.js',
            array('jquery'),
            RFAI_VERSION,
            true
        );
    }
    
    /**
     * Render admin page
     */
    public function render_admin_page() {
        include RFAI_PLUGIN_DIR . 'includes/admin-page.php';
    }
    
    /**
     * Render form editor
     */
    public function render_form_editor() {
        include RFAI_PLUGIN_DIR . 'includes/form-editor.php';
    }
    
    /**
     * Render settings page
     */
    public function render_settings_page() {
        include RFAI_PLUGIN_DIR . 'includes/settings-page.php';
    }
    
    /**
     * Render form builder page
     */
    public function render_form_builder() {
        include RFAI_PLUGIN_DIR . 'includes/form-builder.php';
    }
    
    /**
     * Render form assistant shortcode
     */
    public function render_form_assistant($atts) {
        $atts = shortcode_atts(array(
            'form' => 'cover_letter',
        ), $atts);
        
        // Check if enabled
        if (!$this->is_enabled()) {
            return '<p>' . __('AI Forms are currently disabled.', 'relo2france-ai-forms') . '</p>';
        }
        
        // Check membership
        if (!$this->user_has_access()) {
            return $this->render_upgrade_prompt();
        }
        
        // Get form data
        $forms = get_option('rfai_forms', array());
        $form = $forms[$atts['form']] ?? null;
        
        if (!$form || !$form['enabled']) {
            return '<p>' . __('This form is not available.', 'relo2france-ai-forms') . '</p>';
        }
        
        ob_start();
        include RFAI_PLUGIN_DIR . 'includes/form-assistant-template.php';
        return ob_get_clean();
    }
    
    /**
     * Render forms list shortcode
     */
    public function render_forms_list($atts) {
        $atts = shortcode_atts(array(
            'category' => '',
        ), $atts);
        
        if (!$this->is_enabled()) {
            return '';
        }
        
        $forms = get_option('rfai_forms', array());
        $has_access = $this->user_has_access();
        
        // Filter by category if specified
        if (!empty($atts['category'])) {
            $forms = array_filter($forms, function($f) use ($atts) {
                return ($f['category'] ?? '') === $atts['category'];
            });
        }
        
        // Filter to enabled only and sort
        $forms = array_filter($forms, function($f) { return !empty($f['enabled']); });
        uasort($forms, function($a, $b) { return ($a['order'] ?? 99) - ($b['order'] ?? 99); });
        
        ob_start();
        include RFAI_PLUGIN_DIR . 'includes/forms-list-template.php';
        return ob_get_clean();
    }
    
    /**
     * Check if user has premium access
     */
    private function user_has_access() {
        if (!is_user_logged_in()) {
            return false;
        }
        
        // Check via main plugin's membership system
        if (class_exists('FRA_Membership')) {
            $membership = FRA_Membership::get_instance();
            return $membership->user_has_access();
        }
        
        // Fallback: Direct MemberPress check
        if (class_exists('MeprUser')) {
            $user = new MeprUser(get_current_user_id());
            return $user->is_active();
        }
        
        // Fallback: check for admin
        return current_user_can('manage_options');
    }
    
    /**
     * Render upgrade prompt
     */
    private function render_upgrade_prompt() {
        $settings = get_option('fra_membership', array());
        $teaser = $settings['teaser_message'] ?? 'This premium content is available to members.';
        $button_text = $settings['upgrade_button_text'] ?? 'Get Lifetime Access';
        $url = $settings['upgrade_url'] ?? '#';
        
        ob_start();
        ?>
        <div class="rfai-upgrade-prompt">
            <div class="rfai-upgrade-icon">🔒</div>
            <h3><?php _e('Premium Feature', 'relo2france-ai-forms'); ?></h3>
            <p><?php echo esc_html($teaser); ?></p>
            <a href="<?php echo esc_url($url); ?>" class="rfai-upgrade-btn"><?php echo esc_html($button_text); ?></a>
        </div>
        <?php
        return ob_get_clean();
    }
    
    /**
     * Get API key (from main plugin or own)
     */
    public function get_api_key() {
        $use_main = get_option('rfai_use_main_api_key', true);
        
        if ($use_main) {
            return get_option('fra_api_key', '');
        }
        
        return get_option('rfai_api_key', '');
    }
    
    /**
     * AJAX: Handle chat message
     */
    public function ajax_chat_message() {
        check_ajax_referer('rfai_nonce', 'nonce');
        
        if (!$this->user_has_access()) {
            wp_send_json_error('Access denied');
        }
        
        $form_id = sanitize_text_field($_POST['form_id'] ?? '');
        $message = sanitize_textarea_field($_POST['message'] ?? '');
        $context = $_POST['context'] ?? array();
        
        $forms = get_option('rfai_forms', array());
        $form = $forms[$form_id] ?? null;
        
        if (!$form) {
            wp_send_json_error('Form not found');
        }
        
        $api_key = $this->get_api_key();
        if (empty($api_key)) {
            wp_send_json_error('API key not configured');
        }
        
        // Build messages for Claude
        $system_prompt = $form['system_prompt'];
        $messages = array();
        
        // Add context from previous messages
        if (!empty($context) && is_array($context)) {
            foreach ($context as $msg) {
                $messages[] = array(
                    'role' => sanitize_text_field($msg['role']),
                    'content' => sanitize_textarea_field($msg['content'])
                );
            }
        }
        
        // Add current message
        $messages[] = array(
            'role' => 'user',
            'content' => $message
        );
        
        // Call Claude API
        $response = wp_remote_post('https://api.anthropic.com/v1/messages', array(
            'timeout' => 60,
            'headers' => array(
                'Content-Type' => 'application/json',
                'x-api-key' => $api_key,
                'anthropic-version' => '2023-06-01'
            ),
            'body' => json_encode(array(
                'model' => 'claude-sonnet-4-20250514',
                'max_tokens' => 2048,
                'system' => $system_prompt,
                'messages' => $messages
            ))
        ));
        
        if (is_wp_error($response)) {
            wp_send_json_error('API request failed');
        }
        
        $body = json_decode(wp_remote_retrieve_body($response), true);
        
        if (isset($body['error'])) {
            wp_send_json_error('API error: ' . ($body['error']['message'] ?? 'Unknown'));
        }
        
        if (isset($body['content'][0]['text'])) {
            wp_send_json_success(array(
                'response' => $body['content'][0]['text']
            ));
        }
        
        wp_send_json_error('Unexpected response');
    }
    
    /**
     * AJAX: Save progress
     */
    public function ajax_save_progress() {
        check_ajax_referer('rfai_nonce', 'nonce');
        
        if (!is_user_logged_in()) {
            wp_send_json_error('Not logged in');
        }
        
        global $wpdb;
        $table = $wpdb->prefix . 'rfai_progress';
        
        $user_id = get_current_user_id();
        $form_id = sanitize_text_field($_POST['form_id'] ?? '');
        $progress_data = wp_json_encode($_POST['progress'] ?? array());
        $completed = isset($_POST['completed']) ? 1 : 0;
        
        // Check if exists
        $existing = $wpdb->get_var($wpdb->prepare(
            "SELECT id FROM $table WHERE user_id = %d AND form_id = %s",
            $user_id, $form_id
        ));
        
        if ($existing) {
            $wpdb->update($table, 
                array('progress_data' => $progress_data, 'completed' => $completed),
                array('id' => $existing)
            );
        } else {
            $wpdb->insert($table, array(
                'user_id' => $user_id,
                'form_id' => $form_id,
                'progress_data' => $progress_data,
                'completed' => $completed
            ));
        }
        
        wp_send_json_success('Saved');
    }
    
    /**
     * AJAX: Load progress
     */
    public function ajax_load_progress() {
        check_ajax_referer('rfai_nonce', 'nonce');
        
        if (!is_user_logged_in()) {
            wp_send_json_error('Not logged in');
        }
        
        global $wpdb;
        $table = $wpdb->prefix . 'rfai_progress';
        
        $user_id = get_current_user_id();
        $form_id = sanitize_text_field($_POST['form_id'] ?? '');
        
        $result = $wpdb->get_row($wpdb->prepare(
            "SELECT progress_data, completed FROM $table WHERE user_id = %d AND form_id = %s",
            $user_id, $form_id
        ));
        
        if ($result) {
            wp_send_json_success(array(
                'progress' => json_decode($result->progress_data, true),
                'completed' => (bool) $result->completed
            ));
        }
        
        wp_send_json_success(array('progress' => null));
    }
    
    /**
     * AJAX: Generate document
     */
    public function ajax_generate_document() {
        check_ajax_referer('rfai_nonce', 'nonce');
        
        if (!$this->user_has_access()) {
            wp_send_json_error('Access denied');
        }
        
        $form_id = sanitize_text_field($_POST['form_id'] ?? '');
        $answers = $_POST['answers'] ?? array();
        
        $forms = get_option('rfai_forms', array());
        $form = $forms[$form_id] ?? null;
        
        if (!$form) {
            wp_send_json_error('Form not found');
        }
        
        // Generate document using AI
        $api_key = $this->get_api_key();
        
        $prompt = "Based on the following information, generate a complete, professional " . $form['title'] . ".\n\n";
        $prompt .= "Template structure:\n" . $form['template'] . "\n\n";
        $prompt .= "User provided information:\n";
        
        foreach ($answers as $key => $value) {
            $prompt .= "- " . ucfirst(str_replace('_', ' ', $key)) . ": " . $value . "\n";
        }
        
        $prompt .= "\nGenerate the complete document now, ready for printing. ";
        if ($form['language'] === 'bilingual') {
            $prompt .= "Include both French and English versions.";
        }
        
        $response = wp_remote_post('https://api.anthropic.com/v1/messages', array(
            'timeout' => 90,
            'headers' => array(
                'Content-Type' => 'application/json',
                'x-api-key' => $api_key,
                'anthropic-version' => '2023-06-01'
            ),
            'body' => json_encode(array(
                'model' => 'claude-sonnet-4-20250514',
                'max_tokens' => 4096,
                'system' => "You are a professional document generator. Create formal, print-ready documents based on provided information. Match the style expected by French consulates and government offices.",
                'messages' => array(
                    array('role' => 'user', 'content' => $prompt)
                )
            ))
        ));
        
        if (is_wp_error($response)) {
            wp_send_json_error('Generation failed');
        }
        
        $body = json_decode(wp_remote_retrieve_body($response), true);
        
        if (isset($body['content'][0]['text'])) {
            wp_send_json_success(array(
                'document' => $body['content'][0]['text']
            ));
        }
        
        wp_send_json_error('Generation failed');
    }
}

/**
 * Activation function - runs on plugin activation
 */
function rfai_activate() {
    // Create default forms if not exist
    if (!get_option('rfai_forms')) {
        $instance = Relo2France_AI_Forms::get_instance();
        // Trigger install via a method we'll call directly
    }
    
    // Create database table
    global $wpdb;
    $table_name = $wpdb->prefix . 'rfai_progress';
    $charset_collate = $wpdb->get_charset_collate();
    
    $sql = "CREATE TABLE IF NOT EXISTS $table_name (
        id bigint(20) NOT NULL AUTO_INCREMENT,
        user_id bigint(20) NOT NULL,
        form_id varchar(50) NOT NULL,
        progress_data longtext NOT NULL,
        completed tinyint(1) DEFAULT 0,
        created_at datetime DEFAULT CURRENT_TIMESTAMP,
        updated_at datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
        PRIMARY KEY (id),
        KEY user_form (user_id, form_id)
    ) $charset_collate;";
    
    require_once(ABSPATH . 'wp-admin/includes/upgrade.php');
    dbDelta($sql);
    
    // Set default forms
    if (!get_option('rfai_forms')) {
        update_option('rfai_forms', rfai_get_default_forms());
    }
    
    flush_rewrite_rules();
}

/**
 * Get default forms configuration
 */
function rfai_get_default_forms() {
    return array(
        'cover_letter' => array(
            'title' => 'Visa Cover Letter',
            'description' => 'Create a professional cover letter for your French long-stay visa application.',
            'icon' => '📝',
            'category' => 'visa',
            'language' => 'english',
            'enabled' => true,
            'order' => 1,
            'system_prompt' => "You are an expert assistant helping users create professional visa cover letters for French long-stay visa applications.\n\nYour role:\n- Ask questions one at a time to gather necessary information\n- Be warm, helpful, and explain why each piece of information matters\n- Stay focused ONLY on the cover letter - do not answer unrelated questions\n- When you have all information, generate a formal, professional cover letter",
            'questions' => array(
                array('key' => 'full_name', 'question' => "Let's create your visa cover letter! What is your full legal name as it appears on your passport?"),
                array('key' => 'address', 'question' => "What is your current address?"),
                array('key' => 'email', 'question' => "What email address should be on the letter?"),
                array('key' => 'spouse', 'question' => "Are you applying with a spouse or partner? If yes, what is their full name? (Say 'no' if applying alone)"),
                array('key' => 'visa_type', 'question' => "What type of visa are you applying for?\n• Visitor (Visiteur) - You won't work in France\n• Talent Passport - Skilled professional\n• Work Visa - Employment with French company\n• Student - Studying in France"),
            ),
            'template' => "VISA COVER LETTER TEMPLATE",
        ),
        'attestation_honor' => array(
            'title' => 'Attestation on Honor (No Work)',
            'description' => 'Declaration that you will not work in France during your visa validity.',
            'icon' => '✋',
            'category' => 'visa',
            'language' => 'bilingual',
            'enabled' => true,
            'order' => 2,
            'system_prompt' => "You are helping users create an Attestation sur l'Honneur declaring they will not work in France. Output in BOTH French and English.",
            'questions' => array(
                array('key' => 'full_name', 'question' => "I'll help you create your Attestation on Honor. What is your full legal name?"),
                array('key' => 'dob', 'question' => "What is your date of birth?"),
                array('key' => 'passport', 'question' => "What is your passport number?"),
            ),
            'template' => "ATTESTATION SUR L'HONNEUR",
        ),
    );
}

/**
 * Deactivation function
 */
function rfai_deactivate() {
    flush_rewrite_rules();
}

// Register activation/deactivation hooks at file level (BEFORE class instantiation)
register_activation_hook(__FILE__, 'rfai_activate');
register_deactivation_hook(__FILE__, 'rfai_deactivate');

/**
 * Initialize plugin
 */
function rfai_init() {
    // Check if main plugin is active before initializing
    if (!rfai_check_required_plugin()) {
        return null;
    }
    return Relo2France_AI_Forms::get_instance();
}
add_action('plugins_loaded', 'rfai_init', 20);
