/**
 * Relo2France AI Forms - Admin JavaScript
 * 
 * @package Relo2France_AI_Forms
 */

jQuery(document).ready(function($) {
    // Any admin-specific JS can go here
});
