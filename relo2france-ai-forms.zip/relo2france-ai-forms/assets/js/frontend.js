/**
 * Relo2France AI Forms - Frontend JavaScript
 * 
 * @package Relo2France_AI_Forms
 */

(function($) {
    'use strict';
    
    // Form Assistant Class
    window.RFAI_FormAssistant = function(options) {
        this.formId = options.formId;
        this.questions = options.questions || [];
        this.systemPrompt = options.systemPrompt || '';
        this.formTitle = options.formTitle || '';
        this.isBilingual = options.isBilingual === 'true';
        
        this.currentQuestion = 0;
        this.answers = {};
        this.messages = [];
        this.isLoading = false;
        this.documentGenerated = false;
        
        this.init();
    };
    
    RFAI_FormAssistant.prototype = {
        init: function() {
            var self = this;
            
            // Cache DOM elements
            this.$container = $('.rfai-assistant[data-form-id="' + this.formId + '"]');
            this.$messages = $('#rfai-messages-' + this.formId);
            this.$input = $('#rfai-input-' + this.formId);
            this.$sendBtn = $('#rfai-send-' + this.formId);
            this.$typing = $('#rfai-typing-' + this.formId);
            this.$progress = this.$container.find('.rfai-progress-fill');
            this.$progressText = this.$container.find('.rfai-progress-text');
            this.$documentPanel = $('#rfai-document-' + this.formId);
            this.$documentContent = $('#rfai-document-content-' + this.formId);
            
            // Bind events
            this.$sendBtn.on('click', function() { self.handleSend(); });
            this.$input.on('keydown', function(e) {
                if (e.key === 'Enter' && !e.shiftKey) {
                    e.preventDefault();
                    self.handleSend();
                }
            });
            
            $('#rfai-restart-' + this.formId).on('click', function() { self.restart(); });
            $('#rfai-download-' + this.formId).on('click', function() { self.downloadPDF(); });
            $('#rfai-print-' + this.formId).on('click', function() { self.downloadPDF(); });
            
            // Load saved progress
            this.loadProgress();
        },
        
        loadProgress: function() {
            var self = this;
            
            $.ajax({
                url: rfaiData.ajaxUrl,
                type: 'POST',
                data: {
                    action: 'rfai_load_progress',
                    nonce: rfaiData.nonce,
                    form_id: this.formId
                },
                success: function(response) {
                    if (response.success && response.data.progress) {
                        self.answers = response.data.progress.answers || {};
                        self.messages = response.data.progress.messages || [];
                        self.currentQuestion = response.data.progress.currentQuestion || 0;
                        
                        // Restore messages
                        self.messages.forEach(function(msg) {
                            self.addMessageToUI(msg.role, msg.content, false);
                        });
                        
                        self.updateProgress();
                        
                        // If not completed, prompt to continue
                        if (self.currentQuestion > 0 && self.currentQuestion < self.questions.length) {
                            self.addMessageToUI('assistant', '👋 Welcome back! I saved your progress. Let\'s continue where you left off.', true);
                        }
                    } else {
                        // Start fresh
                        self.start();
                    }
                },
                error: function() {
                    self.start();
                }
            });
        },
        
        start: function() {
            var welcomeMsg = '👋 Welcome! I\'m here to help you create your ' + this.formTitle + '.\n\nI\'ll ask you a series of questions, and then generate a professional document ready to print.\n\n💾 Your progress is automatically saved if you need to take a break.';
            this.addMessage('assistant', welcomeMsg);
            
            // Ask first question after delay
            var self = this;
            setTimeout(function() {
                if (self.questions.length > 0) {
                    self.addMessage('assistant', self.questions[0].question);
                }
            }, 1000);
        },
        
        handleSend: function() {
            var input = this.$input.val().trim();
            if (!input || this.isLoading) return;
            
            this.$input.val('');
            this.addMessage('user', input);
            
            // Save answer
            if (this.currentQuestion < this.questions.length) {
                var key = this.questions[this.currentQuestion].key;
                this.answers[key] = input;
            }
            
            this.processResponse(input);
        },
        
        processResponse: function(userInput) {
            var self = this;
            this.isLoading = true;
            this.showTyping();
            
            // Check if all questions answered
            if (this.currentQuestion >= this.questions.length - 1) {
                // Generate document
                setTimeout(function() {
                    self.hideTyping();
                    self.addMessage('assistant', '✨ Perfect! I have all the information I need. Generating your document now...');
                    self.generateDocument();
                }, 800);
                return;
            }
            
            // Move to next question
            this.currentQuestion++;
            this.updateProgress();
            this.saveProgress();
            
            // Show acknowledgment and next question
            setTimeout(function() {
                self.hideTyping();
                
                var acks = ['Perfect! ✓', 'Got it! ✓', 'Great, thank you! ✓', 'Noted! ✓'];
                var ack = acks[Math.floor(Math.random() * acks.length)];
                
                var nextQuestion = self.questions[self.currentQuestion].question;
                self.addMessage('assistant', ack + '\n\n' + nextQuestion);
                self.isLoading = false;
            }, 600);
        },
        
        generateDocument: function() {
            var self = this;
            this.showTyping();
            
            $.ajax({
                url: rfaiData.ajaxUrl,
                type: 'POST',
                data: {
                    action: 'rfai_generate_document',
                    nonce: rfaiData.nonce,
                    form_id: this.formId,
                    answers: this.answers
                },
                success: function(response) {
                    self.hideTyping();
                    
                    if (response.success && response.data.document) {
                        self.documentGenerated = true;
                        self.showDocument(response.data.document);
                        self.addMessage('assistant', '🎉 **Your document is ready!**\n\nI\'ve generated a professional document based on your information. You can preview it below, download as PDF, or print it directly.');
                        self.saveProgress(true);
                    } else {
                        self.addMessage('assistant', '❌ Sorry, there was an error generating your document. Please try again or contact support.');
                    }
                    self.isLoading = false;
                },
                error: function() {
                    self.hideTyping();
                    self.addMessage('assistant', '❌ Connection error. Please check your internet and try again.');
                    self.isLoading = false;
                }
            });
        },
        
        showDocument: function(content) {
            // Format the content for display
            var formatted = content
                .replace(/\*\*(.*?)\*\*/g, '<strong>$1</strong>')
                .replace(/\n/g, '<br>');
            
            this.$documentContent.html('<pre class="rfai-doc-text">' + content + '</pre>');
            this.$documentPanel.slideDown();
            
            // Scroll to document
            $('html, body').animate({
                scrollTop: this.$documentPanel.offset().top - 100
            }, 500);
        },
        
        addMessage: function(role, content) {
            this.messages.push({ role: role, content: content });
            this.addMessageToUI(role, content, true);
        },
        
        addMessageToUI: function(role, content, animate) {
            var msgClass = role === 'user' ? 'rfai-msg-user' : 'rfai-msg-assistant';
            var avatar = role === 'user' ? '👤' : '🤖';
            
            // Format content
            var formatted = content
                .replace(/\*\*(.*?)\*\*/g, '<strong>$1</strong>')
                .replace(/\n/g, '<br>')
                .replace(/•/g, '<span class="rfai-bullet">•</span>');
            
            var $msg = $('<div class="rfai-message ' + msgClass + '">' +
                '<div class="rfai-avatar">' + avatar + '</div>' +
                '<div class="rfai-bubble">' + formatted + '</div>' +
            '</div>');
            
            if (animate) {
                $msg.hide().appendTo(this.$messages).fadeIn(300);
            } else {
                $msg.appendTo(this.$messages);
            }
            
            // Scroll to bottom
            this.$messages.scrollTop(this.$messages[0].scrollHeight);
        },
        
        showTyping: function() {
            this.$typing.show();
            this.$messages.scrollTop(this.$messages[0].scrollHeight);
        },
        
        hideTyping: function() {
            this.$typing.hide();
        },
        
        updateProgress: function() {
            var progress = Math.round((this.currentQuestion / this.questions.length) * 100);
            this.$progress.css('width', progress + '%');
            this.$progressText.text(progress + '% complete');
        },
        
        saveProgress: function(completed) {
            $.ajax({
                url: rfaiData.ajaxUrl,
                type: 'POST',
                data: {
                    action: 'rfai_save_progress',
                    nonce: rfaiData.nonce,
                    form_id: this.formId,
                    progress: {
                        answers: this.answers,
                        messages: this.messages,
                        currentQuestion: this.currentQuestion
                    },
                    completed: completed ? 1 : 0
                }
            });
        },
        
        restart: function() {
            if (!confirm('Start over? Your current progress will be lost.')) return;
            
            this.currentQuestion = 0;
            this.answers = {};
            this.messages = [];
            this.documentGenerated = false;
            
            this.$messages.empty();
            this.$documentPanel.hide();
            this.updateProgress();
            
            this.start();
            this.saveProgress();
        },
        
        downloadPDF: function() {
            var self = this;
            var content = this.$documentContent.find('.rfai-doc-text').text();
            
            if (!content) {
                alert('No document to download. Please complete the form first.');
                return;
            }
            
            // Create a clean print window
            var printWindow = window.open('', '_blank', 'width=800,height=600');
            
            // Format content for printing
            var formattedContent = content
                .replace(/\*\*\[(.*?)\]\*\*/g, '<h3 style="margin-top: 20px; border-bottom: 1px solid #333;">$1</h3>')
                .replace(/\*\*(.*?)\*\*/g, '<strong>$1</strong>')
                .replace(/^• (.*?)$/gm, '<li>$1</li>')
                .replace(/\n\n/g, '</p><p>')
                .replace(/\n/g, '<br>');
            
            // Wrap bullet points in ul
            formattedContent = formattedContent.replace(/(<li>.*?<\/li>)+/gs, '<ul style="margin: 10px 0 10px 20px;">$&</ul>');
            
            var printContent = `
                <!DOCTYPE html>
                <html>
                <head>
                    <title>${this.formTitle}</title>
                    <style>
                        @page {
                            margin: 1in;
                            size: letter;
                        }
                        body {
                            font-family: 'Times New Roman', Times, serif;
                            font-size: 12pt;
                            line-height: 1.5;
                            color: #000;
                            max-width: 6.5in;
                            margin: 0 auto;
                            padding: 20px;
                        }
                        h3 {
                            font-size: 12pt;
                            font-weight: bold;
                            text-decoration: underline;
                            margin: 20px 0 10px 0;
                            border: none !important;
                        }
                        p {
                            margin: 0 0 12px 0;
                            text-align: justify;
                        }
                        ul {
                            margin: 10px 0 10px 30px;
                        }
                        li {
                            margin-bottom: 5px;
                        }
                        strong {
                            font-weight: bold;
                        }
                        .signature-line {
                            margin-top: 40px;
                            border-top: 1px solid #000;
                            width: 250px;
                            padding-top: 5px;
                        }
                        @media print {
                            body { padding: 0; }
                        }
                    </style>
                </head>
                <body>
                    <div class="document-content">
                        <p>${formattedContent}</p>
                    </div>
                    <script>
                        window.onload = function() {
                            window.print();
                        };
                    </script>
                </body>
                </html>
            `;
            
            printWindow.document.write(printContent);
            printWindow.document.close();
        }
    };
    
})(jQuery);
