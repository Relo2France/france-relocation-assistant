<?php
/**
 * AI Forms Admin Page
 * 
 * @package Relo2France_AI_Forms
 */

if (!defined('ABSPATH')) {
    exit;
}

// Handle form actions
if (isset($_POST['rfai_toggle_form']) && check_admin_referer('rfai_admin_nonce')) {
    $form_id = sanitize_text_field($_POST['form_id']);
    $forms = get_option('rfai_forms', array());
    if (isset($forms[$form_id])) {
        $forms[$form_id]['enabled'] = !$forms[$form_id]['enabled'];
        update_option('rfai_forms', $forms);
    }
}

if (isset($_POST['rfai_delete_form']) && check_admin_referer('rfai_admin_nonce')) {
    $form_id = sanitize_text_field($_POST['form_id']);
    $forms = get_option('rfai_forms', array());
    if (isset($forms[$form_id])) {
        unset($forms[$form_id]);
        update_option('rfai_forms', $forms);
        echo '<div class="notice notice-success is-dismissible"><p>' . __('Form deleted.', 'relo2france-ai-forms') . '</p></div>';
    }
}

$forms = get_option('rfai_forms', array());
$is_enabled = get_option('fra_enable_ai_forms', false);

// Sort by order
uasort($forms, function($a, $b) {
    return ($a['order'] ?? 99) - ($b['order'] ?? 99);
});
?>

<div class="wrap rfai-admin-wrap">
    <h1>
        <span class="dashicons dashicons-format-aside"></span>
        <?php _e('AI Form Assistants', 'relo2france-ai-forms'); ?>
    </h1>
    
    <div class="rfai-admin-header">
        <p class="rfai-description">
            <?php _e('AI-powered document assistants help your premium members create professional visa and relocation documents.', 'relo2france-ai-forms'); ?>
        </p>
    </div>
    
    <?php if (!$is_enabled): ?>
    <div class="notice notice-warning">
        <p>
            <strong><?php _e('AI Forms are currently disabled.', 'relo2france-ai-forms'); ?></strong>
            <?php _e('Enable them in', 'relo2france-ai-forms'); ?> 
            <a href="<?php echo admin_url('admin.php?page=france-relocation-assistant-membership'); ?>"><?php _e('FR Assistant → Membership', 'relo2france-ai-forms'); ?></a>
        </p>
    </div>
    <?php endif; ?>
    
    <div class="rfai-admin-grid">
        <!-- Quick Stats -->
        <div class="rfai-card rfai-card-highlight">
            <h2><?php _e('📊 Overview', 'relo2france-ai-forms'); ?></h2>
            
            <div class="rfai-stats-row">
                <div class="rfai-stat">
                    <span class="rfai-stat-number"><?php echo count($forms); ?></span>
                    <span class="rfai-stat-label"><?php _e('Total Forms', 'relo2france-ai-forms'); ?></span>
                </div>
                <div class="rfai-stat">
                    <span class="rfai-stat-number"><?php echo count(array_filter($forms, function($f) { return $f['enabled']; })); ?></span>
                    <span class="rfai-stat-label"><?php _e('Active', 'relo2france-ai-forms'); ?></span>
                </div>
                <div class="rfai-stat">
                    <span class="rfai-stat-number <?php echo $is_enabled ? 'rfai-stat-success' : 'rfai-stat-warning'; ?>">
                        <?php echo $is_enabled ? '✓' : '✗'; ?>
                    </span>
                    <span class="rfai-stat-label"><?php _e('Plugin Status', 'relo2france-ai-forms'); ?></span>
                </div>
            </div>
        </div>
        
        <!-- Shortcodes -->
        <div class="rfai-card">
            <h2><?php _e('📝 Shortcodes', 'relo2france-ai-forms'); ?></h2>
            
            <table class="rfai-shortcode-table">
                <tr>
                    <td><code>[rfai_forms_list]</code></td>
                    <td><?php _e('Display all available forms', 'relo2france-ai-forms'); ?></td>
                </tr>
                <tr>
                    <td><code>[rfai_form_assistant form="cover_letter"]</code></td>
                    <td><?php _e('Display a specific form assistant', 'relo2france-ai-forms'); ?></td>
                </tr>
            </table>
        </div>
    </div>
    
    <!-- Forms List -->
    <div class="rfai-card rfai-card-full" style="margin-top: 20px;">
        <div class="rfai-card-header">
            <h2><?php _e('📋 Form Assistants', 'relo2france-ai-forms'); ?></h2>
            <a href="<?php echo admin_url('admin.php?page=rfai-forms-new'); ?>" class="button button-primary">
                <span class="dashicons dashicons-plus-alt" style="margin-top: 3px;"></span>
                <?php _e('Add New Form', 'relo2france-ai-forms'); ?>
            </a>
        </div>
        
        <table class="wp-list-table widefat fixed striped rfai-forms-table">
            <thead>
                <tr>
                    <th style="width: 50px;"><?php _e('Icon', 'relo2france-ai-forms'); ?></th>
                    <th><?php _e('Form Name', 'relo2france-ai-forms'); ?></th>
                    <th style="width: 100px;"><?php _e('Category', 'relo2france-ai-forms'); ?></th>
                    <th style="width: 100px;"><?php _e('Language', 'relo2france-ai-forms'); ?></th>
                    <th style="width: 100px;"><?php _e('Status', 'relo2france-ai-forms'); ?></th>
                    <th style="width: 200px;"><?php _e('Shortcode', 'relo2france-ai-forms'); ?></th>
                    <th style="width: 150px;"><?php _e('Actions', 'relo2france-ai-forms'); ?></th>
                </tr>
            </thead>
            <tbody>
                <?php if (empty($forms)): ?>
                <tr>
                    <td colspan="7" style="text-align: center; padding: 40px;">
                        <?php _e('No forms created yet.', 'relo2france-ai-forms'); ?>
                        <a href="<?php echo admin_url('admin.php?page=rfai-forms-new'); ?>"><?php _e('Create your first form', 'relo2france-ai-forms'); ?></a>
                    </td>
                </tr>
                <?php else: ?>
                <?php foreach ($forms as $form_id => $form): ?>
                <tr>
                    <td style="font-size: 24px; text-align: center;"><?php echo esc_html($form['icon'] ?? '📄'); ?></td>
                    <td>
                        <strong><a href="<?php echo admin_url('admin.php?page=rfai-forms-new&edit=' . esc_attr($form_id)); ?>"><?php echo esc_html($form['title']); ?></a></strong>
                        <div class="row-actions">
                            <span class="edit">
                                <a href="<?php echo admin_url('admin.php?page=rfai-forms-new&edit=' . esc_attr($form_id)); ?>"><?php _e('Edit', 'relo2france-ai-forms'); ?></a> |
                            </span>
                            <span class="view">
                                <a href="#" onclick="rfaiPreviewForm('<?php echo esc_js($form_id); ?>', '<?php echo esc_js($form['title']); ?>'); return false;"><?php _e('Preview', 'relo2france-ai-forms'); ?></a> |
                            </span>
                            <span class="shortcode">
                                <a href="#" onclick="rfaiCopyShortcode('<?php echo esc_js($form_id); ?>'); return false;"><?php _e('Copy Shortcode', 'relo2france-ai-forms'); ?></a>
                            </span>
                        </div>
                        <p class="description" style="margin: 5px 0 0 0;"><?php echo esc_html($form['description'] ?? ''); ?></p>
                    </td>
                    <td>
                        <span class="rfai-category-badge rfai-cat-<?php echo esc_attr($form['category'] ?? 'other'); ?>">
                            <?php echo esc_html(ucfirst($form['category'] ?? 'Other')); ?>
                        </span>
                    </td>
                    <td>
                        <?php if (($form['language'] ?? 'english') === 'bilingual'): ?>
                            <span class="rfai-lang-badge rfai-lang-bilingual">🇫🇷🇺🇸</span>
                        <?php else: ?>
                            <span class="rfai-lang-badge rfai-lang-english">🇺🇸</span>
                        <?php endif; ?>
                    </td>
                    <td>
                        <form method="post" style="display: inline;">
                            <?php wp_nonce_field('rfai_admin_nonce'); ?>
                            <input type="hidden" name="form_id" value="<?php echo esc_attr($form_id); ?>">
                            <button type="submit" name="rfai_toggle_form" class="rfai-status-toggle <?php echo $form['enabled'] ? 'rfai-enabled' : 'rfai-disabled'; ?>">
                                <?php echo $form['enabled'] ? __('Enabled', 'relo2france-ai-forms') : __('Disabled', 'relo2france-ai-forms'); ?>
                            </button>
                        </form>
                    </td>
                    <td>
                        <code style="font-size: 11px;">[rfai_form_assistant form="<?php echo esc_attr($form_id); ?>"]</code>
                    </td>
                    <td>
                        <a href="<?php echo admin_url('admin.php?page=rfai-forms-new&edit=' . esc_attr($form_id)); ?>" class="button button-small">
                            <?php _e('Edit', 'relo2france-ai-forms'); ?>
                        </a>
                        <form method="post" style="display: inline;" onsubmit="return confirm('<?php _e('Delete this form?', 'relo2france-ai-forms'); ?>');">
                            <?php wp_nonce_field('rfai_admin_nonce'); ?>
                            <input type="hidden" name="form_id" value="<?php echo esc_attr($form_id); ?>">
                            <button type="submit" name="rfai_delete_form" class="button button-small button-link-delete">
                                <?php _e('Delete', 'relo2france-ai-forms'); ?>
                            </button>
                        </form>
                    </td>
                </tr>
                <?php endforeach; ?>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>

<style>
.rfai-admin-wrap {
    max-width: 1400px;
}
.rfai-admin-header {
    margin-bottom: 20px;
}
.rfai-description {
    font-size: 14px;
    color: #646970;
}
.rfai-admin-grid {
    display: grid;
    grid-template-columns: repeat(2, 1fr);
    gap: 20px;
}
@media (max-width: 1200px) {
    .rfai-admin-grid { grid-template-columns: 1fr; }
}
.rfai-card {
    background: #fff;
    border: 1px solid #ddd;
    border-radius: 8px;
    padding: 20px;
}
.rfai-card h2 {
    margin: 0 0 15px 0;
    padding: 0;
    font-size: 16px;
    border: none;
}
.rfai-card-highlight {
    border-left: 4px solid #ff6b00;
}
.rfai-card-full {
    grid-column: 1 / -1;
}
.rfai-card-header {
    display: flex;
    justify-content: space-between;
    align-items: center;
    margin-bottom: 15px;
}
.rfai-card-header h2 {
    margin: 0;
}
.rfai-stats-row {
    display: flex;
    gap: 30px;
}
.rfai-stat {
    text-align: center;
}
.rfai-stat-number {
    display: block;
    font-size: 32px;
    font-weight: 600;
    color: #1e3a5f;
}
.rfai-stat-success { color: #00a32a; }
.rfai-stat-warning { color: #dba617; }
.rfai-stat-label {
    font-size: 13px;
    color: #646970;
}
.rfai-shortcode-table {
    width: 100%;
}
.rfai-shortcode-table td {
    padding: 8px 0;
    border-bottom: 1px solid #f0f0f0;
}
.rfai-shortcode-table code {
    background: #f0f0f0;
    padding: 4px 8px;
    border-radius: 4px;
    font-size: 12px;
}
.rfai-forms-table .row-actions {
    visibility: hidden;
}
.rfai-forms-table tr:hover .row-actions {
    visibility: visible;
}
.rfai-category-badge {
    display: inline-block;
    padding: 3px 10px;
    border-radius: 12px;
    font-size: 11px;
    font-weight: 500;
}
.rfai-cat-visa { background: #e0f2fe; color: #0369a1; }
.rfai-cat-planning { background: #fef3c7; color: #b45309; }
.rfai-cat-property { background: #dcfce7; color: #15803d; }
.rfai-cat-other { background: #f3f4f6; color: #4b5563; }
.rfai-lang-badge {
    font-size: 16px;
}
.rfai-status-toggle {
    padding: 4px 12px;
    border-radius: 12px;
    border: none;
    font-size: 11px;
    font-weight: 500;
    cursor: pointer;
}
.rfai-status-toggle.rfai-enabled {
    background: #dcfce7;
    color: #15803d;
}
.rfai-status-toggle.rfai-disabled {
    background: #fee2e2;
    color: #b91c1c;
}
.button-link-delete {
    color: #b32d2e !important;
}
/* Preview modal */
.rfai-preview-modal {
    display: none;
    position: fixed;
    top: 0;
    left: 0;
    right: 0;
    bottom: 0;
    background: rgba(0,0,0,0.8);
    z-index: 100000;
    padding: 40px;
}
.rfai-preview-modal.active {
    display: flex;
    align-items: center;
    justify-content: center;
}
.rfai-preview-frame {
    background: #fff;
    border-radius: 12px;
    width: 100%;
    max-width: 800px;
    max-height: 90vh;
    overflow: hidden;
    display: flex;
    flex-direction: column;
}
.rfai-preview-header {
    padding: 15px 20px;
    border-bottom: 1px solid #eee;
    display: flex;
    justify-content: space-between;
    align-items: center;
}
.rfai-preview-header h3 {
    margin: 0;
}
.rfai-preview-close {
    background: none;
    border: none;
    font-size: 24px;
    cursor: pointer;
    color: #666;
}
.rfai-preview-body {
    flex: 1;
    overflow-y: auto;
    padding: 20px;
}
.rfai-preview-body iframe {
    width: 100%;
    height: 500px;
    border: 1px solid #ddd;
    border-radius: 8px;
}
.rfai-shortcode-copied {
    position: fixed;
    bottom: 20px;
    right: 20px;
    background: #15803d;
    color: #fff;
    padding: 12px 20px;
    border-radius: 8px;
    z-index: 10000;
    animation: fadeInOut 2s ease-in-out;
}
@keyframes fadeInOut {
    0%, 100% { opacity: 0; transform: translateY(10px); }
    20%, 80% { opacity: 1; transform: translateY(0); }
}
</style>

<!-- Preview Modal -->
<div id="rfai-preview-modal" class="rfai-preview-modal">
    <div class="rfai-preview-frame">
        <div class="rfai-preview-header">
            <h3 id="rfai-preview-title"><?php _e('Form Preview', 'relo2france-ai-forms'); ?></h3>
            <button type="button" class="rfai-preview-close" onclick="rfaiClosePreview()">&times;</button>
        </div>
        <div class="rfai-preview-body">
            <p><?php _e('This is how the form will appear to your members. Use the shortcode below to add it to any page:', 'relo2france-ai-forms'); ?></p>
            <code id="rfai-preview-shortcode" style="display: block; padding: 10px; background: #f0f0f0; margin: 10px 0; border-radius: 4px;"></code>
            <p class="description"><?php _e('Note: The form requires an active API key to function. Preview shows the form interface only.', 'relo2france-ai-forms'); ?></p>
            <div id="rfai-preview-content"></div>
        </div>
    </div>
</div>

<script>
function rfaiPreviewForm(formId, formTitle) {
    document.getElementById('rfai-preview-title').textContent = formTitle + ' - Preview';
    document.getElementById('rfai-preview-shortcode').textContent = '[rfai_form_assistant form="' + formId + '"]';
    
    // Show shortcode info and link
    document.getElementById('rfai-preview-content').innerHTML = 
        '<p style="margin-top: 20px;"><strong><?php _e('To preview the full form:', 'relo2france-ai-forms'); ?></strong></p>' +
        '<ol>' +
        '<li><?php _e('Create a new page or post', 'relo2france-ai-forms'); ?></li>' +
        '<li><?php _e('Add the shortcode above', 'relo2france-ai-forms'); ?></li>' +
        '<li><?php _e('Preview/publish the page', 'relo2france-ai-forms'); ?></li>' +
        '</ol>' +
        '<p><a href="<?php echo admin_url('post-new.php?post_type=page'); ?>" class="button button-primary" target="_blank"><?php _e('Create Test Page', 'relo2france-ai-forms'); ?></a></p>';
    
    document.getElementById('rfai-preview-modal').classList.add('active');
}

function rfaiClosePreview() {
    document.getElementById('rfai-preview-modal').classList.remove('active');
}

function rfaiCopyShortcode(formId) {
    var shortcode = '[rfai_form_assistant form="' + formId + '"]';
    navigator.clipboard.writeText(shortcode).then(function() {
        // Show toast
        var toast = document.createElement('div');
        toast.className = 'rfai-shortcode-copied';
        toast.textContent = '<?php _e('Shortcode copied!', 'relo2france-ai-forms'); ?>';
        document.body.appendChild(toast);
        setTimeout(function() { toast.remove(); }, 2000);
    });
}

// Close modal on escape or backdrop click
document.addEventListener('keydown', function(e) {
    if (e.key === 'Escape') rfaiClosePreview();
});
document.getElementById('rfai-preview-modal').addEventListener('click', function(e) {
    if (e.target === this) rfaiClosePreview();
});
</script>
