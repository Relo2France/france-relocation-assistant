<?php
/**
 * AI Form Builder
 * 
 * Upload a template document and Claude auto-generates the form questions
 * 
 * @package Relo2France_AI_Forms
 */

if (!defined('ABSPATH')) {
    exit;
}

/**
 * Extract text from a .docx file using PHP ZipArchive
 */
function rfai_extract_docx_text($filepath) {
    if (!class_exists('ZipArchive')) {
        return '';
    }
    
    $zip = new ZipArchive();
    if ($zip->open($filepath) !== true) {
        return '';
    }
    
    // Read the main document XML
    $xml = $zip->getFromName('word/document.xml');
    $zip->close();
    
    if (empty($xml)) {
        return '';
    }
    
    // Parse XML and extract text
    $dom = new DOMDocument();
    @$dom->loadXML($xml, LIBXML_NOENT | LIBXML_XINCLUDE | LIBXML_NOERROR | LIBXML_NOWARNING);
    
    $text = '';
    $paragraphs = $dom->getElementsByTagNameNS('http://schemas.openxmlformats.org/wordprocessingml/2006/main', 't');
    
    $current_paragraph = '';
    foreach ($paragraphs as $p) {
        $current_paragraph .= $p->nodeValue;
    }
    
    // Get paragraphs properly by looking at w:p elements
    $xpath = new DOMXPath($dom);
    $xpath->registerNamespace('w', 'http://schemas.openxmlformats.org/wordprocessingml/2006/main');
    
    $paragraphs = $xpath->query('//w:p');
    $lines = array();
    
    foreach ($paragraphs as $p) {
        $line = '';
        $texts = $xpath->query('.//w:t', $p);
        foreach ($texts as $t) {
            $line .= $t->nodeValue;
        }
        if (!empty(trim($line))) {
            $lines[] = trim($line);
        }
    }
    
    return implode("\n\n", $lines);
}

// Handle form submission
$generated_form = null;
$error_message = null;

if (isset($_POST['rfai_analyze_template']) && check_admin_referer('rfai_form_builder_nonce')) {
    // Check for uploaded file
    if (!empty($_FILES['template_file']['tmp_name'])) {
        $file = $_FILES['template_file'];
        $file_type = wp_check_filetype($file['name']);
        
        // Validate file type
        $allowed_types = array('docx', 'doc', 'txt', 'pdf');
        if (!in_array(strtolower($file_type['ext']), $allowed_types)) {
            $error_message = __('Please upload a .docx, .doc, .txt, or .pdf file.', 'relo2france-ai-forms');
        } else {
            // Extract text content based on file type
            $content = '';
            $ext = strtolower($file_type['ext']);
            
            if ($ext === 'txt') {
                $content = file_get_contents($file['tmp_name']);
            } elseif ($ext === 'docx') {
                // Extract text from docx using PHP ZipArchive
                $content = rfai_extract_docx_text($file['tmp_name']);
                if (empty($content)) {
                    $error_message = __('Could not extract text from document.', 'relo2france-ai-forms');
                }
            } elseif ($ext === 'doc') {
                // For .doc files, try antiword or catdoc
                $temp_txt = '/tmp/rfai_doc_' . time() . '.txt';
                exec('antiword "' . $file['tmp_name'] . '" > ' . escapeshellarg($temp_txt) . ' 2>&1', $output, $return);
                if ($return !== 0) {
                    // Try catdoc as fallback
                    exec('catdoc "' . $file['tmp_name'] . '" > ' . escapeshellarg($temp_txt) . ' 2>&1', $output, $return);
                }
                if ($return === 0 && file_exists($temp_txt)) {
                    $content = file_get_contents($temp_txt);
                    unlink($temp_txt);
                } else {
                    $error_message = __('Could not extract text from .doc file. Please convert to .docx or .txt.', 'relo2france-ai-forms');
                }
            } elseif ($ext === 'pdf') {
                exec('pdftotext "' . $file['tmp_name'] . '" - 2>&1', $output, $return);
                if ($return === 0) {
                    $content = implode("\n", $output);
                } else {
                    $error_message = __('Could not extract text from PDF.', 'relo2france-ai-forms');
                }
            }
            
            if (!empty($content) && !$error_message) {
                // Get form details
                $form_name = sanitize_text_field($_POST['form_name'] ?? 'Custom Form');
                $form_description = sanitize_textarea_field($_POST['form_description'] ?? '');
                $form_category = sanitize_text_field($_POST['form_category'] ?? 'custom');
                $form_language = sanitize_text_field($_POST['form_language'] ?? 'english');
                $claude_instructions = sanitize_textarea_field($_POST['claude_instructions'] ?? '');
                
                // Call Claude to analyze template and generate form
                $generated_form = rfai_analyze_template_with_claude($content, $form_name, $form_description, $form_category, $form_language, $claude_instructions);
                
                if (is_wp_error($generated_form)) {
                    $error_message = $generated_form->get_error_message();
                    $generated_form = null;
                }
            }
        }
    } else {
        $error_message = __('Please upload a template file.', 'relo2france-ai-forms');
    }
}

// Handle saving generated form
if (isset($_POST['rfai_save_generated_form']) && check_admin_referer('rfai_form_builder_nonce')) {
    $form_data = json_decode(stripslashes($_POST['generated_form_data']), true);
    
    if ($form_data) {
        $forms = get_option('rfai_forms', array());
        $form_id = sanitize_title($form_data['title']) . '_' . time();
        
        $forms[$form_id] = array(
            'title' => $form_data['title'],
            'description' => $form_data['description'],
            'icon' => $form_data['icon'] ?? '📄',
            'category' => $form_data['category'] ?? 'custom',
            'language' => $form_data['language'] ?? 'english',
            'enabled' => true,
            'order' => count($forms) + 1,
            'system_prompt' => $form_data['system_prompt'],
            'questions' => $form_data['questions'],
            'template' => $form_data['template'],
        );
        
        update_option('rfai_forms', $forms);
        
        echo '<div class="notice notice-success is-dismissible"><p>' . 
             sprintf(__('Form "%s" created successfully! <a href="%s">View all forms</a>', 'relo2france-ai-forms'), 
                     esc_html($form_data['title']), 
                     admin_url('admin.php?page=rfai-forms')) . 
             '</p></div>';
    }
}

/**
 * Analyze template with Claude and generate form structure
 */
function rfai_analyze_template_with_claude($template_content, $form_name, $form_description, $category, $language, $custom_instructions = '') {
    // Get API key
    $use_main_key = get_option('rfai_use_main_api_key', true);
    $api_key = $use_main_key ? get_option('fra_api_key', '') : get_option('rfai_api_key', '');
    
    if (empty($api_key)) {
        return new WP_Error('no_api_key', __('No API key configured. Please set up your API key in Settings.', 'relo2france-ai-forms'));
    }
    
    $language_instruction = $language === 'bilingual' 
        ? 'The final document should be generated in BOTH English and French.' 
        : 'The final document should be in ' . ucfirst($language) . '.';
    
    $custom_instructions_section = '';
    if (!empty($custom_instructions)) {
        $custom_instructions_section = <<<INSTRUCTIONS

## IMPORTANT - Custom Instructions from Form Creator:
{$custom_instructions}

These instructions take priority. Follow them carefully when designing the questions and system prompt.
INSTRUCTIONS;
    }
    
    $prompt = <<<PROMPT
You are analyzing a document template to create an AI-powered form that will help users generate similar personalized documents.

## Template Document:
```
{$template_content}
```

## Form Details:
- Form Name: {$form_name}
- Description: {$form_description}
- Category: {$category}
- Language: {$language_instruction}
{$custom_instructions_section}

## Your Task:
Analyze this template and create a complete form configuration. Identify ALL variable information that would need to be collected from a user to generate a personalized version of this document.

The template shows ONE specific example, but your form should be flexible enough to handle DIFFERENT situations. For example:
- The template might show property ownership, but users might be renting or staying with friends
- The template might show a married couple, but users might be single
- The template might show retirement income, but users might have employment income

Your questions should FIRST determine the user's situation, THEN ask relevant follow-up questions based on their answers.

Respond with a JSON object in this exact format:
```json
{
    "title": "Form Title",
    "description": "Brief description of what this form creates",
    "icon": "📄",
    "category": "{$category}",
    "language": "{$language}",
    "system_prompt": "Detailed instructions for Claude on how to conduct the conversation and generate the final document. Include: 1) How to handle different user situations/branches, 2) The document structure and sections, 3) Tone and formatting requirements, 4) How to adapt the template based on user answers.",
    "questions": [
        {
            "key": "unique_key",
            "question": "The question to ask the user",
            "helper": "Optional helper text explaining why this is needed",
            "type": "text|choice|conditional",
            "options": ["Option 1", "Option 2"],
            "condition": "Only ask if previous answer was X"
        }
    ],
    "template": "A template outline showing the structure of the final document with [PLACEHOLDER] markers for variable content"
}
```

## Guidelines:
1. Questions should be conversational and friendly
2. Ask for one piece of information at a time
3. START with branching questions that determine the user's situation
4. Include conditional questions that depend on previous answers
5. The system_prompt should be comprehensive and explain how to handle ALL situations
6. The system_prompt should tell Claude to adapt sections based on user's situation
7. Include helper text for complex questions
8. Include 10-20 questions depending on document complexity and branching needs
9. For "choice" type questions, include the options array
10. For "conditional" questions, explain when to ask them

Return ONLY the JSON object, no other text.
PROMPT;

    $response = wp_remote_post('https://api.anthropic.com/v1/messages', array(
        'timeout' => 120,
        'headers' => array(
            'Content-Type' => 'application/json',
            'x-api-key' => $api_key,
            'anthropic-version' => '2023-06-01',
        ),
        'body' => json_encode(array(
            'model' => 'claude-sonnet-4-20250514',
            'max_tokens' => 4096,
            'messages' => array(
                array('role' => 'user', 'content' => $prompt)
            )
        ))
    ));
    
    if (is_wp_error($response)) {
        return $response;
    }
    
    $body = json_decode(wp_remote_retrieve_body($response), true);
    
    if (isset($body['error'])) {
        return new WP_Error('api_error', $body['error']['message'] ?? 'API error occurred');
    }
    
    if (!isset($body['content'][0]['text'])) {
        return new WP_Error('invalid_response', 'Invalid response from API');
    }
    
    $text = $body['content'][0]['text'];
    
    // Extract JSON from response (handle markdown code blocks)
    if (preg_match('/```json\s*(.*?)\s*```/s', $text, $matches)) {
        $text = $matches[1];
    } elseif (preg_match('/```\s*(.*?)\s*```/s', $text, $matches)) {
        $text = $matches[1];
    }
    
    $form_data = json_decode(trim($text), true);
    
    if (!$form_data || !isset($form_data['questions'])) {
        return new WP_Error('parse_error', 'Could not parse form structure from AI response');
    }
    
    return $form_data;
}
?>

<div class="wrap rfai-admin-wrap">
    <h1>
        <span class="dashicons dashicons-hammer"></span>
        <?php _e('AI Form Builder', 'relo2france-ai-forms'); ?>
    </h1>
    
    <div class="rfai-admin-header">
        <p class="rfai-description">
            <?php _e('Upload a template document and let Claude automatically generate a form that collects the right information to create personalized versions.', 'relo2france-ai-forms'); ?>
        </p>
    </div>
    
    <?php if ($error_message): ?>
    <div class="notice notice-error is-dismissible">
        <p><?php echo esc_html($error_message); ?></p>
    </div>
    <?php endif; ?>
    
    <div class="rfai-builder-container">
        <?php if (!$generated_form): ?>
        <!-- Upload Form -->
        <div class="rfai-card rfai-card-full">
            <h2><?php _e('📤 Step 1: Upload Template', 'relo2france-ai-forms'); ?></h2>
            <p class="description"><?php _e('Upload an example document (like a cover letter, attestation, or any form) that you want users to be able to generate.', 'relo2france-ai-forms'); ?></p>
            
            <form method="post" enctype="multipart/form-data" class="rfai-builder-form">
                <?php wp_nonce_field('rfai_form_builder_nonce'); ?>
                
                <table class="form-table">
                    <tr>
                        <th><label for="template_file"><?php _e('Template File', 'relo2france-ai-forms'); ?> *</label></th>
                        <td>
                            <input type="file" name="template_file" id="template_file" accept=".docx,.doc,.txt,.pdf" required>
                            <p class="description"><?php _e('Supported: .docx, .doc, .txt, .pdf', 'relo2france-ai-forms'); ?></p>
                        </td>
                    </tr>
                    <tr>
                        <th><label for="form_name"><?php _e('Form Name', 'relo2france-ai-forms'); ?> *</label></th>
                        <td>
                            <input type="text" name="form_name" id="form_name" class="regular-text" required placeholder="<?php _e('e.g., Visa Cover Letter', 'relo2france-ai-forms'); ?>">
                        </td>
                    </tr>
                    <tr>
                        <th><label for="form_description"><?php _e('Description', 'relo2france-ai-forms'); ?></label></th>
                        <td>
                            <textarea name="form_description" id="form_description" rows="2" class="large-text" placeholder="<?php _e('Brief description of what this form creates...', 'relo2france-ai-forms'); ?>"></textarea>
                        </td>
                    </tr>
                    <tr>
                        <th><label for="form_category"><?php _e('Category', 'relo2france-ai-forms'); ?></label></th>
                        <td>
                            <select name="form_category" id="form_category">
                                <option value="visa"><?php _e('📋 Visa & Immigration', 'relo2france-ai-forms'); ?></option>
                                <option value="property"><?php _e('🏠 Property & Finance', 'relo2france-ai-forms'); ?></option>
                                <option value="planning"><?php _e('📅 Relocation Planning', 'relo2france-ai-forms'); ?></option>
                                <option value="legal"><?php _e('⚖️ Legal Documents', 'relo2france-ai-forms'); ?></option>
                                <option value="custom"><?php _e('📄 Custom', 'relo2france-ai-forms'); ?></option>
                            </select>
                        </td>
                    </tr>
                    <tr>
                        <th><label for="form_language"><?php _e('Output Language', 'relo2france-ai-forms'); ?></label></th>
                        <td>
                            <select name="form_language" id="form_language">
                                <option value="english"><?php _e('English only', 'relo2france-ai-forms'); ?></option>
                                <option value="french"><?php _e('French only', 'relo2france-ai-forms'); ?></option>
                                <option value="bilingual"><?php _e('Both English & French', 'relo2france-ai-forms'); ?></option>
                            </select>
                        </td>
                    </tr>
                    <tr>
                        <th><label for="claude_instructions"><?php _e('Instructions for Claude', 'relo2france-ai-forms'); ?></label></th>
                        <td>
                            <textarea name="claude_instructions" id="claude_instructions" rows="6" class="large-text" placeholder="<?php _e('Give Claude specific guidance on how to build this form...', 'relo2france-ai-forms'); ?>"></textarea>
                            <p class="description"><?php _e('Tell Claude what variations to handle, what branching logic to include, and how to adapt the template for different situations.', 'relo2france-ai-forms'); ?></p>
                            <details class="rfai-instructions-examples">
                                <summary><?php _e('💡 Example instructions (click to expand)', 'relo2france-ai-forms'); ?></summary>
                                <div class="rfai-examples-content">
                                    <p><strong><?php _e('For a Cover Letter:', 'relo2france-ai-forms'); ?></strong></p>
                                    <pre>- First ask what type of accommodation they have: owned property, rental, or staying with someone
- If owned: ask about property details, purchase status, price
- If rental: ask about lease details, landlord info
- If staying with someone: ask about host details
- Ask if they're applying with a spouse - if yes, collect spouse info
- The template shows property ownership, but adapt sections based on their situation
- Not everyone will have retirement accounts - make financial questions flexible</pre>
                                    
                                    <p><strong><?php _e('For an Attestation:', 'relo2france-ai-forms'); ?></strong></p>
                                    <pre>- Ask if this is for the primary applicant or a spouse
- Include option for different visa types (visitor, talent, student)
- Make sure to collect passport details for the correct person</pre>
                                </div>
                            </details>
                        </td>
                    </tr>
                </table>
                
                <p class="submit">
                    <button type="submit" name="rfai_analyze_template" class="button button-primary button-hero">
                        <span class="dashicons dashicons-superhero" style="margin-top: 5px;"></span>
                        <?php _e('Analyze with Claude', 'relo2france-ai-forms'); ?>
                    </button>
                </p>
            </form>
        </div>
        
        <!-- How It Works -->
        <div class="rfai-card">
            <h2><?php _e('🤖 How It Works', 'relo2france-ai-forms'); ?></h2>
            <ol class="rfai-steps-list">
                <li>
                    <strong><?php _e('Upload a template', 'relo2france-ai-forms'); ?></strong>
                    <p><?php _e('Upload any document you want users to be able to generate (cover letter, attestation, etc.)', 'relo2france-ai-forms'); ?></p>
                </li>
                <li>
                    <strong><?php _e('Claude analyzes it', 'relo2france-ai-forms'); ?></strong>
                    <p><?php _e('AI identifies all variable information and creates conversational questions to collect it', 'relo2france-ai-forms'); ?></p>
                </li>
                <li>
                    <strong><?php _e('Review & customize', 'relo2france-ai-forms'); ?></strong>
                    <p><?php _e('Edit the generated questions, reorder them, or add your own', 'relo2france-ai-forms'); ?></p>
                </li>
                <li>
                    <strong><?php _e('Save & publish', 'relo2france-ai-forms'); ?></strong>
                    <p><?php _e('Your new form is ready for members to use!', 'relo2france-ai-forms'); ?></p>
                </li>
            </ol>
        </div>
        
        <!-- Tips -->
        <div class="rfai-card">
            <h2><?php _e('💡 Tips for Best Results', 'relo2france-ai-forms'); ?></h2>
            <ul class="rfai-tips-list">
                <li><?php _e('Use a complete, real example document (with placeholder names if needed)', 'relo2france-ai-forms'); ?></li>
                <li><?php _e('Include all sections you want in the final output', 'relo2france-ai-forms'); ?></li>
                <li><?php _e('The more detailed your template, the better the generated questions', 'relo2france-ai-forms'); ?></li>
                <li><?php _e('You can always edit the questions after generation', 'relo2france-ai-forms'); ?></li>
            </ul>
        </div>
        
        <?php else: ?>
        <!-- Generated Form Preview -->
        <div class="rfai-card rfai-card-full rfai-generated-preview">
            <h2><?php _e('✅ Step 2: Review Generated Form', 'relo2france-ai-forms'); ?></h2>
            <p class="description"><?php _e('Claude has analyzed your template and generated the following form. Review and customize as needed.', 'relo2france-ai-forms'); ?></p>
            
            <form method="post" class="rfai-save-form" id="rfai-edit-form">
                <?php wp_nonce_field('rfai_form_builder_nonce'); ?>
                <input type="hidden" name="generated_form_data" id="generated_form_data" value="">
                
                <div class="rfai-preview-header">
                    <span class="rfai-preview-icon"><?php echo esc_html($generated_form['icon'] ?? '📄'); ?></span>
                    <div class="rfai-preview-header-edit">
                        <input type="text" id="edit_title" value="<?php echo esc_attr($generated_form['title']); ?>" class="rfai-edit-title">
                        <input type="text" id="edit_description" value="<?php echo esc_attr($generated_form['description']); ?>" class="rfai-edit-description">
                    </div>
                </div>
                
                <div class="rfai-preview-section">
                    <div class="rfai-section-header">
                        <h4><?php _e('📝 Questions to Ask', 'relo2france-ai-forms'); ?> (<span id="question-count"><?php echo count($generated_form['questions']); ?></span>)</h4>
                        <button type="button" id="add-question-btn" class="button button-small">+ <?php _e('Add Question', 'relo2france-ai-forms'); ?></button>
                    </div>
                    <p class="description"><?php _e('Drag to reorder. Click to edit. These guide the conversation flow.', 'relo2france-ai-forms'); ?></p>
                    <div class="rfai-questions-list" id="questions-list">
                        <?php foreach ($generated_form['questions'] as $i => $q): ?>
                        <div class="rfai-question-item" data-index="<?php echo $i; ?>">
                            <span class="rfai-question-drag">☰</span>
                            <span class="rfai-question-num"><?php echo $i + 1; ?></span>
                            <div class="rfai-question-content">
                                <input type="text" class="rfai-question-input" value="<?php echo esc_attr($q['question']); ?>" placeholder="<?php _e('Question text...', 'relo2france-ai-forms'); ?>">
                                <input type="text" class="rfai-helper-input" value="<?php echo esc_attr($q['helper'] ?? ''); ?>" placeholder="<?php _e('Helper text (optional)...', 'relo2france-ai-forms'); ?>">
                                <div class="rfai-question-meta">
                                    <code class="rfai-question-key"><?php echo esc_html($q['key']); ?></code>
                                    <?php if (!empty($q['type']) && $q['type'] !== 'text'): ?>
                                    <span class="rfai-question-type"><?php echo esc_html($q['type']); ?></span>
                                    <?php endif; ?>
                                    <?php if (!empty($q['condition'])): ?>
                                    <span class="rfai-question-condition" title="<?php echo esc_attr($q['condition']); ?>">⚡ <?php _e('Conditional', 'relo2france-ai-forms'); ?></span>
                                    <?php endif; ?>
                                </div>
                            </div>
                            <button type="button" class="rfai-question-delete" title="<?php _e('Delete question', 'relo2france-ai-forms'); ?>">×</button>
                        </div>
                        <?php endforeach; ?>
                    </div>
                </div>
                
                <div class="rfai-preview-section">
                    <div class="rfai-section-header">
                        <h4><?php _e('🤖 System Prompt', 'relo2france-ai-forms'); ?></h4>
                        <button type="button" id="toggle-prompt-btn" class="button button-small"><?php _e('Expand', 'relo2france-ai-forms'); ?></button>
                    </div>
                    <p class="description"><?php _e('Instructions that guide Claude on how to conduct the conversation and generate the document.', 'relo2france-ai-forms'); ?></p>
                    <textarea id="edit_system_prompt" class="rfai-system-prompt-edit" rows="8"><?php echo esc_textarea($generated_form['system_prompt']); ?></textarea>
                </div>
                
                <div class="rfai-preview-section rfai-template-section">
                    <div class="rfai-section-header">
                        <h4><?php _e('📄 Document Template', 'relo2france-ai-forms'); ?></h4>
                        <button type="button" id="toggle-template-btn" class="button button-small"><?php _e('Show', 'relo2france-ai-forms'); ?></button>
                    </div>
                    <textarea id="edit_template" class="rfai-template-edit" rows="10" style="display:none;"><?php echo esc_textarea($generated_form['template'] ?? ''); ?></textarea>
                </div>
                
                <div class="rfai-preview-actions">
                    <button type="submit" name="rfai_save_generated_form" class="button button-primary button-hero">
                        <span class="dashicons dashicons-saved" style="margin-top: 5px;"></span>
                        <?php _e('Save Form', 'relo2france-ai-forms'); ?>
                    </button>
                    <a href="<?php echo admin_url('admin.php?page=rfai-forms-builder'); ?>" class="button button-secondary button-hero">
                        <?php _e('Start Over', 'relo2france-ai-forms'); ?>
                    </a>
                </div>
            </form>
            
            <script>
            jQuery(document).ready(function($) {
                // Store original form data
                var formData = <?php echo json_encode($generated_form); ?>;
                
                // Update hidden field before submit
                $('#rfai-edit-form').on('submit', function() {
                    // Update form data from inputs
                    formData.title = $('#edit_title').val();
                    formData.description = $('#edit_description').val();
                    formData.system_prompt = $('#edit_system_prompt').val();
                    formData.template = $('#edit_template').val();
                    
                    // Collect questions
                    formData.questions = [];
                    $('#questions-list .rfai-question-item').each(function(i) {
                        var $item = $(this);
                        formData.questions.push({
                            key: $item.find('.rfai-question-key').text(),
                            question: $item.find('.rfai-question-input').val(),
                            helper: $item.find('.rfai-helper-input').val()
                        });
                    });
                    
                    $('#generated_form_data').val(JSON.stringify(formData));
                });
                
                // Toggle system prompt expand
                $('#toggle-prompt-btn').on('click', function() {
                    var $textarea = $('#edit_system_prompt');
                    var rows = $textarea.attr('rows');
                    if (rows == 8) {
                        $textarea.attr('rows', 20);
                        $(this).text('<?php _e('Collapse', 'relo2france-ai-forms'); ?>');
                    } else {
                        $textarea.attr('rows', 8);
                        $(this).text('<?php _e('Expand', 'relo2france-ai-forms'); ?>');
                    }
                });
                
                // Toggle template show/hide
                $('#toggle-template-btn').on('click', function() {
                    var $textarea = $('#edit_template');
                    if ($textarea.is(':visible')) {
                        $textarea.hide();
                        $(this).text('<?php _e('Show', 'relo2france-ai-forms'); ?>');
                    } else {
                        $textarea.show();
                        $(this).text('<?php _e('Hide', 'relo2france-ai-forms'); ?>');
                    }
                });
                
                // Delete question
                $(document).on('click', '.rfai-question-delete', function() {
                    if (confirm('<?php _e('Delete this question?', 'relo2france-ai-forms'); ?>')) {
                        $(this).closest('.rfai-question-item').remove();
                        updateQuestionNumbers();
                    }
                });
                
                // Add question
                $('#add-question-btn').on('click', function() {
                    var newIndex = $('#questions-list .rfai-question-item').length;
                    var newKey = 'custom_' + Date.now();
                    var html = `
                        <div class="rfai-question-item" data-index="${newIndex}">
                            <span class="rfai-question-drag">☰</span>
                            <span class="rfai-question-num">${newIndex + 1}</span>
                            <div class="rfai-question-content">
                                <input type="text" class="rfai-question-input" value="" placeholder="<?php _e('Question text...', 'relo2france-ai-forms'); ?>">
                                <input type="text" class="rfai-helper-input" value="" placeholder="<?php _e('Helper text (optional)...', 'relo2france-ai-forms'); ?>">
                                <div class="rfai-question-meta">
                                    <code class="rfai-question-key">${newKey}</code>
                                </div>
                            </div>
                            <button type="button" class="rfai-question-delete" title="<?php _e('Delete question', 'relo2france-ai-forms'); ?>">×</button>
                        </div>
                    `;
                    $('#questions-list').append(html);
                    updateQuestionNumbers();
                    $('#questions-list .rfai-question-item:last .rfai-question-input').focus();
                });
                
                function updateQuestionNumbers() {
                    $('#questions-list .rfai-question-item').each(function(i) {
                        $(this).find('.rfai-question-num').text(i + 1);
                    });
                    $('#question-count').text($('#questions-list .rfai-question-item').length);
                }
                
                // Make questions sortable (if jQuery UI available)
                if ($.fn.sortable) {
                    $('#questions-list').sortable({
                        handle: '.rfai-question-drag',
                        update: function() {
                            updateQuestionNumbers();
                        }
                    });
                }
            });
            </script>
        </div>
        <?php endif; ?>
    </div>
</div>

<style>
.rfai-builder-container {
    display: grid;
    grid-template-columns: 1fr 350px;
    gap: 20px;
    max-width: 1400px;
}
.rfai-builder-container .rfai-card-full {
    grid-column: 1 / -1;
}
.rfai-card {
    background: #fff;
    border: 1px solid #ddd;
    border-radius: 8px;
    padding: 20px;
}
.rfai-card h2 {
    margin: 0 0 15px 0;
    padding: 0 0 15px 0;
    border-bottom: 1px solid #eee;
}
.rfai-steps-list, .rfai-tips-list {
    margin: 0;
    padding: 0 0 0 20px;
}
.rfai-steps-list li, .rfai-tips-list li {
    margin-bottom: 15px;
}
.rfai-steps-list li p, .rfai-tips-list li {
    color: #666;
    margin: 5px 0 0 0;
}
.rfai-preview-header {
    display: flex;
    align-items: center;
    gap: 15px;
    padding: 20px;
    background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
    border-radius: 8px;
    color: #fff;
    margin-bottom: 20px;
}
.rfai-preview-icon {
    font-size: 48px;
}
.rfai-preview-header h3 {
    margin: 0;
    color: #fff;
}
.rfai-preview-header p {
    margin: 5px 0 0 0;
    opacity: 0.9;
}
.rfai-preview-section {
    margin-bottom: 25px;
}
.rfai-preview-section h4 {
    margin: 0 0 15px 0;
    color: #333;
}
.rfai-questions-list {
    display: flex;
    flex-direction: column;
    gap: 10px;
}
.rfai-question-item {
    display: flex;
    gap: 12px;
    padding: 12px;
    background: #f9f9f9;
    border-radius: 6px;
    border-left: 3px solid #667eea;
}
.rfai-question-num {
    flex-shrink: 0;
    width: 28px;
    height: 28px;
    background: #667eea;
    color: #fff;
    border-radius: 50%;
    display: flex;
    align-items: center;
    justify-content: center;
    font-size: 13px;
    font-weight: 600;
}
.rfai-question-content strong {
    display: block;
    margin-bottom: 4px;
}
.rfai-question-helper {
    margin: 0;
    font-size: 12px;
    color: #666;
}
.rfai-question-key {
    display: inline-block;
    margin-top: 6px;
    padding: 2px 8px;
    background: #e5e7eb;
    border-radius: 4px;
    font-size: 11px;
    color: #666;
}
.rfai-system-prompt-preview {
    padding: 15px;
    background: #1e293b;
    color: #e2e8f0;
    border-radius: 6px;
    font-family: monospace;
    font-size: 12px;
    line-height: 1.6;
    max-height: 200px;
    overflow-y: auto;
}
.rfai-truncated {
    color: #94a3b8;
    font-style: italic;
}
.rfai-preview-actions {
    display: flex;
    gap: 15px;
    padding-top: 20px;
    border-top: 1px solid #eee;
    margin-top: 20px;
}

/* Instructions examples */
.rfai-instructions-examples {
    margin-top: 10px;
    background: #f0f9ff;
    border: 1px solid #bae6fd;
    border-radius: 6px;
    padding: 10px 15px;
}
.rfai-instructions-examples summary {
    cursor: pointer;
    font-weight: 500;
    color: #0369a1;
}
.rfai-instructions-examples[open] summary {
    margin-bottom: 10px;
}
.rfai-examples-content pre {
    background: #fff;
    padding: 12px;
    border-radius: 4px;
    font-size: 12px;
    line-height: 1.6;
    white-space: pre-wrap;
    margin: 8px 0;
    border: 1px solid #e0e0e0;
}
.rfai-examples-content p {
    margin: 15px 0 5px 0;
    font-weight: 600;
}

/* Editable form styles */
.rfai-preview-header-edit {
    flex: 1;
}
.rfai-edit-title {
    width: 100%;
    background: rgba(255,255,255,0.2);
    border: 1px solid rgba(255,255,255,0.3);
    border-radius: 4px;
    padding: 8px 12px;
    color: #fff;
    font-size: 20px;
    font-weight: 600;
    margin-bottom: 8px;
}
.rfai-edit-title::placeholder {
    color: rgba(255,255,255,0.6);
}
.rfai-edit-description {
    width: 100%;
    background: rgba(255,255,255,0.15);
    border: 1px solid rgba(255,255,255,0.2);
    border-radius: 4px;
    padding: 6px 12px;
    color: rgba(255,255,255,0.9);
    font-size: 14px;
}
.rfai-section-header {
    display: flex;
    justify-content: space-between;
    align-items: center;
    margin-bottom: 10px;
}
.rfai-section-header h4 {
    margin: 0 !important;
}
.rfai-question-drag {
    cursor: grab;
    color: #999;
    padding: 0 5px;
    font-size: 16px;
}
.rfai-question-drag:hover {
    color: #667eea;
}
.rfai-question-item {
    display: flex;
    gap: 10px;
    padding: 12px;
    background: #f9f9f9;
    border-radius: 6px;
    border-left: 3px solid #667eea;
    align-items: flex-start;
}
.rfai-question-content {
    flex: 1;
}
.rfai-question-input {
    width: 100%;
    padding: 8px 10px;
    border: 1px solid #ddd;
    border-radius: 4px;
    font-size: 14px;
    margin-bottom: 6px;
}
.rfai-question-input:focus {
    border-color: #667eea;
    outline: none;
    box-shadow: 0 0 0 2px rgba(102, 126, 234, 0.2);
}
.rfai-helper-input {
    width: 100%;
    padding: 6px 10px;
    border: 1px solid #e5e7eb;
    border-radius: 4px;
    font-size: 12px;
    color: #666;
    background: #fff;
}
.rfai-helper-input:focus {
    border-color: #667eea;
    outline: none;
}
.rfai-question-meta {
    display: flex;
    gap: 8px;
    align-items: center;
    margin-top: 8px;
    flex-wrap: wrap;
}
.rfai-question-type {
    padding: 2px 8px;
    background: #dbeafe;
    color: #1e40af;
    border-radius: 4px;
    font-size: 11px;
}
.rfai-question-condition {
    padding: 2px 8px;
    background: #fef3c7;
    color: #92400e;
    border-radius: 4px;
    font-size: 11px;
    cursor: help;
}
.rfai-question-delete {
    background: none;
    border: none;
    color: #999;
    font-size: 20px;
    cursor: pointer;
    padding: 0 5px;
    line-height: 1;
}
.rfai-question-delete:hover {
    color: #dc2626;
}
.rfai-system-prompt-edit,
.rfai-template-edit {
    width: 100%;
    padding: 15px;
    border: 1px solid #ddd;
    border-radius: 6px;
    font-family: monospace;
    font-size: 13px;
    line-height: 1.6;
    resize: vertical;
}
.rfai-system-prompt-edit:focus,
.rfai-template-edit:focus {
    border-color: #667eea;
    outline: none;
    box-shadow: 0 0 0 2px rgba(102, 126, 234, 0.2);
}

@media (max-width: 1024px) {
    .rfai-builder-container {
        grid-template-columns: 1fr;
    }
}
</style>
