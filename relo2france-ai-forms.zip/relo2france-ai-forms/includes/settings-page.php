<?php
/**
 * AI Forms Settings Page
 * 
 * @package Relo2France_AI_Forms
 */

if (!defined('ABSPATH')) {
    exit;
}

// Handle save
if (isset($_POST['rfai_save_settings']) && check_admin_referer('rfai_settings_nonce')) {
    update_option('rfai_use_main_api_key', isset($_POST['use_main_api_key']));
    update_option('rfai_api_key', sanitize_text_field($_POST['api_key'] ?? ''));
    update_option('rfai_save_conversations', isset($_POST['save_conversations']));
    update_option('rfai_max_messages', absint($_POST['max_messages'] ?? 50));
    
    echo '<div class="notice notice-success is-dismissible"><p>' . __('Settings saved!', 'relo2france-ai-forms') . '</p></div>';
}

$use_main_key = get_option('rfai_use_main_api_key', true);
$api_key = get_option('rfai_api_key', '');
$main_api_key = get_option('fra_api_key', '');
$save_conversations = get_option('rfai_save_conversations', true);
$max_messages = get_option('rfai_max_messages', 50);
?>

<div class="wrap rfai-admin-wrap">
    <h1>
        <span class="dashicons dashicons-admin-settings"></span>
        <?php _e('AI Forms Settings', 'relo2france-ai-forms'); ?>
    </h1>
    
    <form method="post">
        <?php wp_nonce_field('rfai_settings_nonce'); ?>
        
        <div class="rfai-settings-grid">
            <!-- API Settings -->
            <div class="rfai-card">
                <h2><?php _e('🔑 API Configuration', 'relo2france-ai-forms'); ?></h2>
                
                <table class="form-table">
                    <tr>
                        <th><?php _e('API Key Source', 'relo2france-ai-forms'); ?></th>
                        <td>
                            <label>
                                <input type="checkbox" name="use_main_api_key" <?php checked($use_main_key); ?>>
                                <?php _e('Use API key from France Relocation Assistant', 'relo2france-ai-forms'); ?>
                            </label>
                            <p class="description">
                                <?php _e('Recommended: Use the same API key configured in the main plugin.', 'relo2france-ai-forms'); ?>
                            </p>
                            
                            <?php if (!empty($main_api_key)): ?>
                            <p style="margin-top: 10px;">
                                <span class="rfai-key-status rfai-key-active">✓ <?php _e('Main plugin API key is configured', 'relo2france-ai-forms'); ?></span>
                            </p>
                            <?php else: ?>
                            <p style="margin-top: 10px;">
                                <span class="rfai-key-status rfai-key-missing">✗ <?php _e('Main plugin API key is NOT configured', 'relo2france-ai-forms'); ?></span>
                                <a href="<?php echo admin_url('admin.php?page=france-relocation-assistant-settings'); ?>"><?php _e('Configure now →', 'relo2france-ai-forms'); ?></a>
                            </p>
                            <?php endif; ?>
                        </td>
                    </tr>
                    <tr id="separate-key-row" style="<?php echo $use_main_key ? 'opacity: 0.5;' : ''; ?>">
                        <th><label for="api_key"><?php _e('Separate API Key', 'relo2france-ai-forms'); ?></label></th>
                        <td>
                            <input type="password" name="api_key" id="api_key" value="<?php echo esc_attr($api_key); ?>" class="regular-text" <?php echo $use_main_key ? 'disabled' : ''; ?>>
                            <button type="button" class="button" onclick="toggleKeyVisibility()">
                                <?php _e('Show', 'relo2france-ai-forms'); ?>
                            </button>
                            <p class="description">
                                <?php _e('Only used if the checkbox above is unchecked.', 'relo2france-ai-forms'); ?>
                            </p>
                        </td>
                    </tr>
                </table>
            </div>
            
            <!-- Conversation Settings -->
            <div class="rfai-card">
                <h2><?php _e('💬 Conversation Settings', 'relo2france-ai-forms'); ?></h2>
                
                <table class="form-table">
                    <tr>
                        <th><?php _e('Save Progress', 'relo2france-ai-forms'); ?></th>
                        <td>
                            <label>
                                <input type="checkbox" name="save_conversations" <?php checked($save_conversations); ?>>
                                <?php _e('Save user progress so they can continue later', 'relo2france-ai-forms'); ?>
                            </label>
                            <p class="description">
                                <?php _e('Members can leave mid-form and pick up where they left off.', 'relo2france-ai-forms'); ?>
                            </p>
                        </td>
                    </tr>
                    <tr>
                        <th><label for="max_messages"><?php _e('Max Messages', 'relo2france-ai-forms'); ?></label></th>
                        <td>
                            <input type="number" name="max_messages" id="max_messages" value="<?php echo esc_attr($max_messages); ?>" min="10" max="100" class="small-text">
                            <p class="description">
                                <?php _e('Maximum messages per form session. Prevents runaway API costs.', 'relo2france-ai-forms'); ?>
                            </p>
                        </td>
                    </tr>
                </table>
            </div>
            
            <!-- Integration Status -->
            <div class="rfai-card">
                <h2><?php _e('🔗 Integration Status', 'relo2france-ai-forms'); ?></h2>
                
                <table class="rfai-status-table">
                    <tr>
                        <th><?php _e('Main Plugin', 'relo2france-ai-forms'); ?></th>
                        <td>
                            <?php if (class_exists('France_Relocation_Assistant')): ?>
                            <span class="rfai-status-badge rfai-status-ok">✓ <?php _e('Connected', 'relo2france-ai-forms'); ?></span>
                            <?php else: ?>
                            <span class="rfai-status-badge rfai-status-error">✗ <?php _e('Not Found', 'relo2france-ai-forms'); ?></span>
                            <?php endif; ?>
                        </td>
                    </tr>
                    <tr>
                        <th><?php _e('AI Forms Enabled', 'relo2france-ai-forms'); ?></th>
                        <td>
                            <?php if (get_option('fra_enable_ai_forms', false)): ?>
                            <span class="rfai-status-badge rfai-status-ok">✓ <?php _e('Enabled', 'relo2france-ai-forms'); ?></span>
                            <?php else: ?>
                            <span class="rfai-status-badge rfai-status-warning">✗ <?php _e('Disabled', 'relo2france-ai-forms'); ?></span>
                            <a href="<?php echo admin_url('admin.php?page=france-relocation-assistant-membership'); ?>"><?php _e('Enable in FR Assistant →', 'relo2france-ai-forms'); ?></a>
                            <?php endif; ?>
                        </td>
                    </tr>
                    <tr>
                        <th><?php _e('Membership System', 'relo2france-ai-forms'); ?></th>
                        <td>
                            <?php if (defined('MEPR_VERSION')): ?>
                            <span class="rfai-status-badge rfai-status-ok">✓ <?php _e('MemberPress Active', 'relo2france-ai-forms'); ?></span>
                            <?php elseif (class_exists('FRA_Membership')): ?>
                            <span class="rfai-status-badge rfai-status-ok">✓ <?php _e('Available', 'relo2france-ai-forms'); ?></span>
                            <?php else: ?>
                            <span class="rfai-status-badge rfai-status-warning">⚠ <?php _e('Not configured', 'relo2france-ai-forms'); ?></span>
                            <?php endif; ?>
                        </td>
                    </tr>
                    <tr>
                        <th><?php _e('API Key', 'relo2france-ai-forms'); ?></th>
                        <td>
                            <?php 
                            $effective_key = $use_main_key ? $main_api_key : $api_key;
                            if (!empty($effective_key)): 
                            ?>
                            <span class="rfai-status-badge rfai-status-ok">✓ <?php _e('Configured', 'relo2france-ai-forms'); ?></span>
                            <?php else: ?>
                            <span class="rfai-status-badge rfai-status-error">✗ <?php _e('Missing', 'relo2france-ai-forms'); ?></span>
                            <?php endif; ?>
                        </td>
                    </tr>
                </table>
            </div>
            
            <!-- Usage Guide -->
            <div class="rfai-card">
                <h2><?php _e('📖 How It Works', 'relo2france-ai-forms'); ?></h2>
                
                <div class="rfai-how-it-works">
                    <div class="rfai-step">
                        <div class="rfai-step-num">1</div>
                        <div class="rfai-step-text">
                            <strong><?php _e('Enable in Main Plugin', 'relo2france-ai-forms'); ?></strong>
                            <p><?php _e('Go to FR Assistant → Membership and check "Enable AI Forms"', 'relo2france-ai-forms'); ?></p>
                        </div>
                    </div>
                    <div class="rfai-step">
                        <div class="rfai-step-num">2</div>
                        <div class="rfai-step-text">
                            <strong><?php _e('Create/Configure Forms', 'relo2france-ai-forms'); ?></strong>
                            <p><?php _e('Use the form editor to customize questions and prompts', 'relo2france-ai-forms'); ?></p>
                        </div>
                    </div>
                    <div class="rfai-step">
                        <div class="rfai-step-num">3</div>
                        <div class="rfai-step-text">
                            <strong><?php _e('Add to Pages', 'relo2france-ai-forms'); ?></strong>
                            <p><?php _e('Use shortcodes to embed form assistants on member pages', 'relo2france-ai-forms'); ?></p>
                        </div>
                    </div>
                    <div class="rfai-step">
                        <div class="rfai-step-num">4</div>
                        <div class="rfai-step-text">
                            <strong><?php _e('Members Create Documents', 'relo2france-ai-forms'); ?></strong>
                            <p><?php _e('AI guides them through questions and generates professional documents', 'relo2france-ai-forms'); ?></p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        
        <p class="submit">
            <button type="submit" name="rfai_save_settings" class="button button-primary">
                <?php _e('Save Settings', 'relo2france-ai-forms'); ?>
            </button>
        </p>
    </form>
</div>

<style>
.rfai-settings-grid {
    display: grid;
    grid-template-columns: repeat(2, 1fr);
    gap: 20px;
    margin-top: 20px;
}
@media (max-width: 1200px) {
    .rfai-settings-grid { grid-template-columns: 1fr; }
}
.rfai-card {
    background: #fff;
    border: 1px solid #ddd;
    border-radius: 8px;
    padding: 20px;
}
.rfai-card h2 {
    margin: 0 0 15px 0;
    padding: 0;
    font-size: 15px;
    border: none;
}
.rfai-key-status {
    display: inline-block;
    padding: 4px 12px;
    border-radius: 4px;
    font-size: 12px;
}
.rfai-key-active { background: #dcfce7; color: #15803d; }
.rfai-key-missing { background: #fee2e2; color: #b91c1c; }
.rfai-status-table {
    width: 100%;
}
.rfai-status-table th,
.rfai-status-table td {
    padding: 10px 0;
    border-bottom: 1px solid #f0f0f0;
}
.rfai-status-table th {
    font-weight: normal;
    color: #646970;
    width: 140px;
}
.rfai-status-badge {
    display: inline-block;
    padding: 3px 10px;
    border-radius: 12px;
    font-size: 11px;
    font-weight: 500;
}
.rfai-status-ok { background: #dcfce7; color: #15803d; }
.rfai-status-warning { background: #fef3c7; color: #b45309; }
.rfai-status-error { background: #fee2e2; color: #b91c1c; }
.rfai-how-it-works {
    display: flex;
    flex-direction: column;
    gap: 15px;
}
.rfai-step {
    display: flex;
    gap: 15px;
    align-items: flex-start;
}
.rfai-step-num {
    width: 28px;
    height: 28px;
    background: #ff6b00;
    color: white;
    border-radius: 50%;
    display: flex;
    align-items: center;
    justify-content: center;
    font-weight: bold;
    font-size: 14px;
    flex-shrink: 0;
}
.rfai-step-text strong {
    display: block;
    margin-bottom: 4px;
}
.rfai-step-text p {
    margin: 0;
    color: #646970;
    font-size: 13px;
}
</style>

<script>
jQuery(document).ready(function($) {
    $('input[name="use_main_api_key"]').on('change', function() {
        var useMain = $(this).is(':checked');
        $('#separate-key-row').css('opacity', useMain ? 0.5 : 1);
        $('#api_key').prop('disabled', useMain);
    });
});

function toggleKeyVisibility() {
    var input = document.getElementById('api_key');
    input.type = input.type === 'password' ? 'text' : 'password';
}
</script>
