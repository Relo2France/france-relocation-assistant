<?php
/**
 * Forms List Template
 * 
 * @package Relo2France_AI_Forms
 */

if (!defined('ABSPATH')) {
    exit;
}

// $forms and $has_access are passed from shortcode
$categories = array(
    'visa' => array('icon' => '📋', 'label' => __('Visa & Immigration', 'relo2france-ai-forms')),
    'property' => array('icon' => '🏠', 'label' => __('Property & Finance', 'relo2france-ai-forms')),
    'planning' => array('icon' => '📅', 'label' => __('Planning & Logistics', 'relo2france-ai-forms')),
    'taxes' => array('icon' => '💰', 'label' => __('Taxes', 'relo2france-ai-forms')),
    'other' => array('icon' => '📄', 'label' => __('Other', 'relo2france-ai-forms')),
);

// Group forms by category
$grouped = array();
foreach ($forms as $id => $form) {
    $cat = $form['category'] ?? 'other';
    if (!isset($grouped[$cat])) $grouped[$cat] = array();
    $grouped[$cat][$id] = $form;
}
?>

<div class="rfai-forms-list">
    <?php if (!$has_access): ?>
    <div class="rfai-premium-banner">
        <div class="rfai-premium-icon">🔒</div>
        <div class="rfai-premium-content">
            <h3><?php _e('Premium Document Assistants', 'relo2france-ai-forms'); ?></h3>
            <p><?php _e('Get AI-powered help creating professional visa applications, cover letters, and relocation documents.', 'relo2france-ai-forms'); ?></p>
            <?php 
            $settings = get_option('fra_membership', array());
            $url = $settings['upgrade_url'] ?? '#';
            $btn_text = $settings['upgrade_button_text'] ?? __('Get Lifetime Access', 'relo2france-ai-forms');
            ?>
            <a href="<?php echo esc_url($url); ?>" class="rfai-upgrade-btn"><?php echo esc_html($btn_text); ?></a>
        </div>
    </div>
    <?php endif; ?>
    
    <div class="rfai-categories <?php echo !$has_access ? 'rfai-locked' : ''; ?>">
        <?php foreach ($grouped as $cat_key => $cat_forms): 
            $cat_info = $categories[$cat_key] ?? $categories['other'];
        ?>
        <div class="rfai-category-section">
            <h3 class="rfai-category-title">
                <span><?php echo $cat_info['icon']; ?></span>
                <?php echo esc_html($cat_info['label']); ?>
            </h3>
            
            <div class="rfai-forms-grid">
                <?php foreach ($cat_forms as $form_id => $form): ?>
                <div class="rfai-form-card">
                    <div class="rfai-form-icon"><?php echo esc_html($form['icon'] ?? '📄'); ?></div>
                    <div class="rfai-form-info">
                        <h4><?php echo esc_html($form['title']); ?></h4>
                        <p><?php echo esc_html($form['description']); ?></p>
                        <?php if (($form['language'] ?? 'english') === 'bilingual'): ?>
                        <span class="rfai-lang-tag">🇫🇷🇺🇸 <?php _e('Bilingual', 'relo2france-ai-forms'); ?></span>
                        <?php endif; ?>
                    </div>
                    <?php if ($has_access): ?>
                    <a href="<?php echo esc_url(add_query_arg('form', $form_id, get_permalink())); ?>" class="rfai-form-btn">
                        <?php _e('Start', 'relo2france-ai-forms'); ?> →
                    </a>
                    <?php else: ?>
                    <span class="rfai-locked-badge">🔒</span>
                    <?php endif; ?>
                </div>
                <?php endforeach; ?>
            </div>
        </div>
        <?php endforeach; ?>
    </div>
</div>

<style>
.rfai-forms-list {
    max-width: 1000px;
    margin: 0 auto;
}
.rfai-premium-banner {
    display: flex;
    align-items: center;
    gap: 24px;
    padding: 32px;
    background: linear-gradient(135deg, #fff7ed 0%, #ffedd5 100%);
    border: 2px solid #fed7aa;
    border-radius: 16px;
    margin-bottom: 32px;
}
.rfai-premium-icon {
    font-size: 48px;
    flex-shrink: 0;
}
.rfai-premium-content h3 {
    margin: 0 0 8px 0;
    color: #c2410c;
    font-size: 20px;
}
.rfai-premium-content p {
    margin: 0 0 16px 0;
    color: #9a3412;
}
.rfai-upgrade-btn {
    display: inline-block;
    background: linear-gradient(135deg, #f97316 0%, #ea580c 100%);
    color: white !important;
    padding: 12px 28px;
    border-radius: 8px;
    font-weight: 600;
    text-decoration: none;
    transition: all 0.2s ease;
    box-shadow: 0 4px 12px rgba(249, 115, 22, 0.3);
}
.rfai-upgrade-btn:hover {
    transform: translateY(-2px);
    box-shadow: 0 6px 16px rgba(249, 115, 22, 0.4);
}
.rfai-categories.rfai-locked {
    opacity: 0.6;
    pointer-events: none;
    filter: blur(2px);
}
.rfai-category-section {
    margin-bottom: 32px;
}
.rfai-category-title {
    display: flex;
    align-items: center;
    gap: 10px;
    font-size: 18px;
    color: #1e3a5f;
    margin: 0 0 16px 0;
    padding-bottom: 12px;
    border-bottom: 2px solid #e5e7eb;
}
.rfai-forms-grid {
    display: grid;
    grid-template-columns: repeat(auto-fill, minmax(300px, 1fr));
    gap: 16px;
}
.rfai-form-card {
    display: flex;
    align-items: center;
    gap: 16px;
    padding: 20px;
    background: #fff;
    border: 1px solid #e5e7eb;
    border-radius: 12px;
    transition: all 0.2s ease;
}
.rfai-form-card:hover {
    border-color: #d1d5db;
    box-shadow: 0 4px 12px rgba(0,0,0,0.08);
}
.rfai-form-icon {
    font-size: 36px;
    flex-shrink: 0;
}
.rfai-form-info {
    flex: 1;
    min-width: 0;
}
.rfai-form-info h4 {
    margin: 0 0 4px 0;
    font-size: 15px;
    color: #1e293b;
}
.rfai-form-info p {
    margin: 0;
    font-size: 13px;
    color: #64748b;
    line-height: 1.4;
}
.rfai-lang-tag {
    display: inline-block;
    margin-top: 6px;
    padding: 2px 8px;
    background: #f0f9ff;
    color: #0369a1;
    border-radius: 4px;
    font-size: 11px;
}
.rfai-form-btn {
    display: inline-block;
    padding: 10px 20px;
    background: #ff6b00;
    color: white !important;
    border-radius: 8px;
    font-weight: 500;
    font-size: 14px;
    text-decoration: none;
    white-space: nowrap;
    transition: background 0.2s;
}
.rfai-form-btn:hover {
    background: #e55f00;
}
.rfai-locked-badge {
    font-size: 24px;
    opacity: 0.5;
}
</style>
