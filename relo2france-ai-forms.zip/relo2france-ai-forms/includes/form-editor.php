<?php
/**
 * Form Editor Page
 * 
 * @package Relo2France_AI_Forms
 */

if (!defined('ABSPATH')) {
    exit;
}

$forms = get_option('rfai_forms', array());
$editing = isset($_GET['edit']) ? sanitize_text_field($_GET['edit']) : '';
$form_data = $editing && isset($forms[$editing]) ? $forms[$editing] : array();
$is_new = empty($editing);

// Handle save
if (isset($_POST['rfai_save_form']) && check_admin_referer('rfai_form_nonce')) {
    $form_id = sanitize_key($_POST['form_id']);
    
    if (empty($form_id)) {
        $form_id = sanitize_key($_POST['title']);
        $form_id = str_replace(' ', '_', strtolower($form_id));
    }
    
    // Parse questions
    $questions = array();
    if (!empty($_POST['questions'])) {
        foreach ($_POST['questions'] as $q) {
            if (!empty($q['key']) && !empty($q['question'])) {
                $questions[] = array(
                    'key' => sanitize_key($q['key']),
                    'question' => sanitize_textarea_field($q['question']),
                );
            }
        }
    }
    
    $form_data = array(
        'title' => sanitize_text_field($_POST['title']),
        'description' => sanitize_textarea_field($_POST['description']),
        'icon' => sanitize_text_field($_POST['icon']),
        'category' => sanitize_text_field($_POST['category']),
        'language' => sanitize_text_field($_POST['language']),
        'enabled' => isset($_POST['enabled']),
        'order' => absint($_POST['order']),
        'system_prompt' => sanitize_textarea_field($_POST['system_prompt']),
        'questions' => $questions,
        'template' => sanitize_textarea_field($_POST['template']),
    );
    
    $forms[$form_id] = $form_data;
    update_option('rfai_forms', $forms);
    
    echo '<div class="notice notice-success is-dismissible"><p>' . __('Form saved successfully!', 'relo2france-ai-forms') . '</p></div>';
    
    // Redirect to edit mode if was new
    if ($is_new) {
        echo '<script>window.location.href = "' . admin_url('admin.php?page=rfai-forms-new&edit=' . $form_id) . '";</script>';
    }
}

// Defaults for new form
if (empty($form_data)) {
    $form_data = array(
        'title' => '',
        'description' => '',
        'icon' => '📄',
        'category' => 'visa',
        'language' => 'english',
        'enabled' => true,
        'order' => 99,
        'system_prompt' => '',
        'questions' => array(),
        'template' => '',
    );
}
?>

<div class="wrap rfai-admin-wrap">
    <h1>
        <a href="<?php echo admin_url('admin.php?page=rfai-forms'); ?>" class="rfai-back-link">← <?php _e('All Forms', 'relo2france-ai-forms'); ?></a>
        <?php echo $is_new ? __('Add New Form', 'relo2france-ai-forms') : __('Edit Form', 'relo2france-ai-forms'); ?>
    </h1>
    
    <form method="post" class="rfai-form-editor">
        <?php wp_nonce_field('rfai_form_nonce'); ?>
        <input type="hidden" name="form_id" value="<?php echo esc_attr($editing); ?>">
        
        <div class="rfai-editor-grid">
            <!-- Main Content -->
            <div class="rfai-editor-main">
                <!-- Basic Info -->
                <div class="rfai-card">
                    <h2><?php _e('Basic Information', 'relo2france-ai-forms'); ?></h2>
                    
                    <table class="form-table">
                        <tr>
                            <th><label for="title"><?php _e('Form Title', 'relo2france-ai-forms'); ?></label></th>
                            <td>
                                <input type="text" name="title" id="title" value="<?php echo esc_attr($form_data['title']); ?>" class="regular-text" required>
                            </td>
                        </tr>
                        <tr>
                            <th><label for="description"><?php _e('Description', 'relo2france-ai-forms'); ?></label></th>
                            <td>
                                <textarea name="description" id="description" rows="2" class="large-text"><?php echo esc_textarea($form_data['description']); ?></textarea>
                                <p class="description"><?php _e('Brief description shown to users.', 'relo2france-ai-forms'); ?></p>
                            </td>
                        </tr>
                        <tr>
                            <th><label for="icon"><?php _e('Icon', 'relo2france-ai-forms'); ?></label></th>
                            <td>
                                <input type="text" name="icon" id="icon" value="<?php echo esc_attr($form_data['icon']); ?>" class="small-text" style="font-size: 24px; width: 60px; text-align: center;">
                                <span class="description"><?php _e('Emoji icon for the form', 'relo2france-ai-forms'); ?></span>
                            </td>
                        </tr>
                    </table>
                </div>
                
                <!-- System Prompt -->
                <div class="rfai-card">
                    <h2><?php _e('🤖 AI System Prompt', 'relo2france-ai-forms'); ?></h2>
                    <p class="description"><?php _e('Instructions for the AI assistant. This defines its personality, scope, and how it should guide users.', 'relo2france-ai-forms'); ?></p>
                    
                    <textarea name="system_prompt" id="system_prompt" rows="12" class="large-text code"><?php echo esc_textarea($form_data['system_prompt']); ?></textarea>
                    
                    <div class="rfai-prompt-tips">
                        <strong><?php _e('Tips for effective prompts:', 'relo2france-ai-forms'); ?></strong>
                        <ul>
                            <li><?php _e('Define the AI\'s role clearly (e.g., "You are an expert assistant helping create...")', 'relo2france-ai-forms'); ?></li>
                            <li><?php _e('List specific information to collect', 'relo2france-ai-forms'); ?></li>
                            <li><?php _e('Specify to ask ONE question at a time', 'relo2france-ai-forms'); ?></li>
                            <li><?php _e('Include instructions to stay on-topic', 'relo2france-ai-forms'); ?></li>
                            <li><?php _e('Define the output format/style', 'relo2france-ai-forms'); ?></li>
                        </ul>
                    </div>
                </div>
                
                <!-- Questions -->
                <div class="rfai-card">
                    <h2><?php _e('❓ Question Flow', 'relo2france-ai-forms'); ?></h2>
                    <p class="description"><?php _e('Define the questions the AI will ask. These serve as a guide - the AI may adapt based on user responses.', 'relo2france-ai-forms'); ?></p>
                    
                    <div id="rfai-questions-list">
                        <?php 
                        $questions = $form_data['questions'] ?? array();
                        if (empty($questions)) {
                            $questions = array(array('key' => '', 'question' => ''));
                        }
                        foreach ($questions as $i => $q): 
                        ?>
                        <div class="rfai-question-item" data-index="<?php echo $i; ?>">
                            <div class="rfai-question-header">
                                <span class="rfai-question-number"><?php echo $i + 1; ?></span>
                                <button type="button" class="rfai-remove-question" title="<?php _e('Remove', 'relo2france-ai-forms'); ?>">×</button>
                            </div>
                            <div class="rfai-question-fields">
                                <input type="text" name="questions[<?php echo $i; ?>][key]" value="<?php echo esc_attr($q['key']); ?>" placeholder="<?php _e('Field key (e.g., full_name)', 'relo2france-ai-forms'); ?>" class="regular-text">
                                <textarea name="questions[<?php echo $i; ?>][question]" rows="2" placeholder="<?php _e('Question text...', 'relo2france-ai-forms'); ?>" class="large-text"><?php echo esc_textarea($q['question']); ?></textarea>
                            </div>
                        </div>
                        <?php endforeach; ?>
                    </div>
                    
                    <button type="button" id="rfai-add-question" class="button">
                        <span class="dashicons dashicons-plus-alt" style="margin-top: 3px;"></span>
                        <?php _e('Add Question', 'relo2france-ai-forms'); ?>
                    </button>
                </div>
                
                <!-- Template -->
                <div class="rfai-card">
                    <h2><?php _e('📄 Document Template', 'relo2france-ai-forms'); ?></h2>
                    <p class="description"><?php _e('Template structure for the generated document. Use [placeholders] for dynamic content.', 'relo2france-ai-forms'); ?></p>
                    
                    <textarea name="template" id="template" rows="15" class="large-text code"><?php echo esc_textarea($form_data['template']); ?></textarea>
                </div>
            </div>
            
            <!-- Sidebar -->
            <div class="rfai-editor-sidebar">
                <!-- Publish Box -->
                <div class="rfai-card rfai-publish-box">
                    <h2><?php _e('Publish', 'relo2france-ai-forms'); ?></h2>
                    
                    <div class="rfai-publish-options">
                        <label>
                            <input type="checkbox" name="enabled" <?php checked($form_data['enabled']); ?>>
                            <?php _e('Enabled (visible to members)', 'relo2france-ai-forms'); ?>
                        </label>
                    </div>
                    
                    <div class="rfai-publish-actions">
                        <button type="submit" name="rfai_save_form" class="button button-primary button-large">
                            <?php echo $is_new ? __('Create Form', 'relo2france-ai-forms') : __('Update Form', 'relo2france-ai-forms'); ?>
                        </button>
                    </div>
                    
                    <?php if (!$is_new): ?>
                    <div class="rfai-shortcode-display">
                        <strong><?php _e('Shortcode:', 'relo2france-ai-forms'); ?></strong>
                        <code>[rfai_form_assistant form="<?php echo esc_attr($editing); ?>"]</code>
                    </div>
                    <?php endif; ?>
                </div>
                
                <!-- Settings -->
                <div class="rfai-card">
                    <h2><?php _e('Settings', 'relo2france-ai-forms'); ?></h2>
                    
                    <table class="form-table rfai-compact-table">
                        <tr>
                            <th><label for="category"><?php _e('Category', 'relo2france-ai-forms'); ?></label></th>
                            <td>
                                <select name="category" id="category">
                                    <option value="visa" <?php selected($form_data['category'], 'visa'); ?>><?php _e('Visa & Immigration', 'relo2france-ai-forms'); ?></option>
                                    <option value="property" <?php selected($form_data['category'], 'property'); ?>><?php _e('Property & Finance', 'relo2france-ai-forms'); ?></option>
                                    <option value="planning" <?php selected($form_data['category'], 'planning'); ?>><?php _e('Planning & Logistics', 'relo2france-ai-forms'); ?></option>
                                    <option value="taxes" <?php selected($form_data['category'], 'taxes'); ?>><?php _e('Taxes', 'relo2france-ai-forms'); ?></option>
                                    <option value="other" <?php selected($form_data['category'], 'other'); ?>><?php _e('Other', 'relo2france-ai-forms'); ?></option>
                                </select>
                            </td>
                        </tr>
                        <tr>
                            <th><label for="language"><?php _e('Output Language', 'relo2france-ai-forms'); ?></label></th>
                            <td>
                                <select name="language" id="language">
                                    <option value="english" <?php selected($form_data['language'], 'english'); ?>><?php _e('English Only', 'relo2france-ai-forms'); ?></option>
                                    <option value="bilingual" <?php selected($form_data['language'], 'bilingual'); ?>><?php _e('Bilingual (FR + EN)', 'relo2france-ai-forms'); ?></option>
                                    <option value="french" <?php selected($form_data['language'], 'french'); ?>><?php _e('French Only', 'relo2france-ai-forms'); ?></option>
                                </select>
                            </td>
                        </tr>
                        <tr>
                            <th><label for="order"><?php _e('Display Order', 'relo2france-ai-forms'); ?></label></th>
                            <td>
                                <input type="number" name="order" id="order" value="<?php echo esc_attr($form_data['order']); ?>" min="1" max="99" class="small-text">
                            </td>
                        </tr>
                    </table>
                </div>
                
                <!-- Help -->
                <div class="rfai-card">
                    <h2><?php _e('💡 Tips', 'relo2france-ai-forms'); ?></h2>
                    <ul class="rfai-tips-list">
                        <li><?php _e('Keep questions focused and one topic at a time', 'relo2france-ai-forms'); ?></li>
                        <li><?php _e('Use bilingual for documents submitted in France', 'relo2france-ai-forms'); ?></li>
                        <li><?php _e('Test the flow yourself before enabling', 'relo2france-ai-forms'); ?></li>
                        <li><?php _e('The system prompt is key to quality output', 'relo2france-ai-forms'); ?></li>
                    </ul>
                </div>
            </div>
        </div>
    </form>
</div>

<style>
.rfai-back-link {
    font-size: 13px;
    font-weight: normal;
    text-decoration: none;
    color: #646970;
    margin-right: 10px;
}
.rfai-back-link:hover {
    color: #135e96;
}
.rfai-editor-grid {
    display: grid;
    grid-template-columns: 1fr 300px;
    gap: 20px;
    margin-top: 20px;
}
@media (max-width: 1200px) {
    .rfai-editor-grid {
        grid-template-columns: 1fr;
    }
}
.rfai-editor-main .rfai-card {
    margin-bottom: 20px;
}
.rfai-card {
    background: #fff;
    border: 1px solid #ddd;
    border-radius: 8px;
    padding: 20px;
    margin-bottom: 15px;
}
.rfai-card h2 {
    margin: 0 0 15px 0;
    padding: 0;
    font-size: 15px;
    border: none;
}
.rfai-publish-box {
    border-left: 4px solid #ff6b00;
}
.rfai-publish-options {
    padding: 10px 0;
    border-bottom: 1px solid #eee;
    margin-bottom: 15px;
}
.rfai-publish-actions {
    text-align: right;
}
.rfai-shortcode-display {
    margin-top: 15px;
    padding-top: 15px;
    border-top: 1px solid #eee;
    font-size: 12px;
}
.rfai-shortcode-display code {
    display: block;
    margin-top: 5px;
    padding: 8px;
    background: #f5f5f5;
    border-radius: 4px;
    word-break: break-all;
}
.rfai-compact-table th,
.rfai-compact-table td {
    padding: 8px 0;
}
.rfai-compact-table th {
    width: 100px;
    font-weight: normal;
}
.rfai-tips-list {
    margin: 0;
    padding-left: 20px;
    font-size: 13px;
    color: #646970;
}
.rfai-tips-list li {
    margin-bottom: 8px;
}
.rfai-prompt-tips {
    margin-top: 15px;
    padding: 15px;
    background: #f9f9f9;
    border-radius: 6px;
    font-size: 13px;
}
.rfai-prompt-tips ul {
    margin: 10px 0 0 20px;
}
.rfai-prompt-tips li {
    margin-bottom: 5px;
}
.rfai-question-item {
    border: 1px solid #ddd;
    border-radius: 6px;
    padding: 15px;
    margin-bottom: 10px;
    background: #fafafa;
}
.rfai-question-header {
    display: flex;
    justify-content: space-between;
    align-items: center;
    margin-bottom: 10px;
}
.rfai-question-number {
    display: inline-block;
    width: 24px;
    height: 24px;
    background: #1e3a5f;
    color: white;
    border-radius: 50%;
    text-align: center;
    line-height: 24px;
    font-size: 12px;
    font-weight: bold;
}
.rfai-remove-question {
    background: none;
    border: none;
    font-size: 20px;
    color: #b32d2e;
    cursor: pointer;
    padding: 0 5px;
}
.rfai-question-fields {
    display: flex;
    flex-direction: column;
    gap: 8px;
}
#rfai-add-question {
    margin-top: 10px;
}
textarea.code {
    font-family: Consolas, Monaco, monospace;
    font-size: 13px;
}
</style>

<script>
jQuery(document).ready(function($) {
    var questionIndex = <?php echo count($questions); ?>;
    
    // Add question
    $('#rfai-add-question').on('click', function() {
        var template = `
            <div class="rfai-question-item" data-index="${questionIndex}">
                <div class="rfai-question-header">
                    <span class="rfai-question-number">${questionIndex + 1}</span>
                    <button type="button" class="rfai-remove-question" title="<?php _e('Remove', 'relo2france-ai-forms'); ?>">×</button>
                </div>
                <div class="rfai-question-fields">
                    <input type="text" name="questions[${questionIndex}][key]" placeholder="<?php _e('Field key (e.g., full_name)', 'relo2france-ai-forms'); ?>" class="regular-text">
                    <textarea name="questions[${questionIndex}][question]" rows="2" placeholder="<?php _e('Question text...', 'relo2france-ai-forms'); ?>" class="large-text"></textarea>
                </div>
            </div>
        `;
        $('#rfai-questions-list').append(template);
        questionIndex++;
    });
    
    // Remove question
    $(document).on('click', '.rfai-remove-question', function() {
        $(this).closest('.rfai-question-item').remove();
        // Renumber
        $('.rfai-question-item').each(function(i) {
            $(this).find('.rfai-question-number').text(i + 1);
        });
    });
});
</script>
