<?php
/**
 * Form Assistant Template
 * 
 * @package Relo2France_AI_Forms
 */

if (!defined('ABSPATH')) {
    exit;
}

// $form is passed from shortcode
$form_id = $atts['form'];
$questions_json = wp_json_encode($form['questions'] ?? array());
?>

<div class="rfai-assistant" data-form-id="<?php echo esc_attr($form_id); ?>">
    <!-- Header -->
    <div class="rfai-header">
        <div class="rfai-header-content">
            <span class="rfai-header-icon"><?php echo esc_html($form['icon'] ?? '📄'); ?></span>
            <div class="rfai-header-text">
                <h2><?php echo esc_html($form['title']); ?></h2>
                <p><?php echo esc_html($form['description']); ?></p>
            </div>
        </div>
        <div class="rfai-progress-wrap">
            <div class="rfai-progress-bar">
                <div class="rfai-progress-fill" style="width: 0%;"></div>
            </div>
            <span class="rfai-progress-text">0% complete</span>
        </div>
    </div>
    
    <!-- Chat Container -->
    <div class="rfai-chat-container">
        <!-- Messages Area -->
        <div class="rfai-messages" id="rfai-messages-<?php echo esc_attr($form_id); ?>">
            <!-- Welcome message will be added by JS -->
        </div>
        
        <!-- Input Area -->
        <div class="rfai-input-area">
            <textarea 
                id="rfai-input-<?php echo esc_attr($form_id); ?>" 
                class="rfai-input" 
                placeholder="<?php _e('Type your answer...', 'relo2france-ai-forms'); ?>"
                rows="3"
            ></textarea>
            <button type="button" class="rfai-send-btn" id="rfai-send-<?php echo esc_attr($form_id); ?>">
                <span class="rfai-send-icon">→</span>
            </button>
        </div>
        
        <!-- Typing Indicator (hidden by default) -->
        <div class="rfai-typing" id="rfai-typing-<?php echo esc_attr($form_id); ?>" style="display: none;">
            <span class="rfai-dot"></span>
            <span class="rfai-dot"></span>
            <span class="rfai-dot"></span>
        </div>
    </div>
    
    <!-- Document Preview (hidden until generated) -->
    <div class="rfai-document-panel" id="rfai-document-<?php echo esc_attr($form_id); ?>" style="display: none;">
        <div class="rfai-document-header">
            <h3><?php _e('📄 Your Document', 'relo2france-ai-forms'); ?></h3>
            <div class="rfai-document-actions">
                <button type="button" class="rfai-btn rfai-btn-primary" id="rfai-download-<?php echo esc_attr($form_id); ?>">
                    ⬇ <?php _e('Download PDF', 'relo2france-ai-forms'); ?>
                </button>
                <button type="button" class="rfai-btn rfai-btn-secondary" id="rfai-print-<?php echo esc_attr($form_id); ?>">
                    🖨 <?php _e('Print', 'relo2france-ai-forms'); ?>
                </button>
                <button type="button" class="rfai-btn rfai-btn-tertiary" id="rfai-restart-<?php echo esc_attr($form_id); ?>">
                    ↺ <?php _e('Start Over', 'relo2france-ai-forms'); ?>
                </button>
            </div>
        </div>
        <div class="rfai-document-content" id="rfai-document-content-<?php echo esc_attr($form_id); ?>">
            <!-- Generated document will appear here -->
        </div>
    </div>
    
    <!-- Footer -->
    <div class="rfai-footer">
        <span>💾 <?php _e('Progress auto-saved', 'relo2france-ai-forms'); ?></span>
        <span>🔒 <?php _e('Premium member content', 'relo2france-ai-forms'); ?></span>
    </div>
</div>

<!-- Initialize this form assistant -->
<script>
(function() {
    var formId = '<?php echo esc_js($form_id); ?>';
    var questions = <?php echo $questions_json; ?>;
    var systemPrompt = <?php echo wp_json_encode($form['system_prompt'] ?? ''); ?>;
    var formTitle = <?php echo wp_json_encode($form['title']); ?>;
    var isBilingual = <?php echo ($form['language'] ?? 'english') === 'bilingual' ? 'true' : 'false'; ?>;
    
    // Wait for DOM and rfaiData
    document.addEventListener('DOMContentLoaded', function() {
        if (typeof RFAI_FormAssistant !== 'undefined') {
            new RFAI_FormAssistant({
                formId: formId,
                questions: questions,
                systemPrompt: systemPrompt,
                formTitle: formTitle,
                isBilingual: isBilingual
            });
        }
    });
})();
</script>
