=== France Relocation Member Tools ===
Contributors: relo2france
Tags: france, relocation, visa, membership, documents
Requires at least: 5.8
Tested up to: 6.4
Requires PHP: 7.4
Stable tag: 1.1.8
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

Premium member features for the France Relocation Assistant - document generation, checklists, guides, and personalized relocation planning.

== Description ==

France Relocation Member Tools is an add-on plugin that extends the France Relocation Assistant with premium features for members.

**Features:**

* **Personalized Dashboard** - Welcome message, progress stats, recommended next steps
* **Member Profile** - AI-guided onboarding, profile management, document status tracking
* **Document Generation** - Create personalized visa documents through conversational chat
* **Interactive Checklists** - Track your visa application progress
* **Glossary** - Comprehensive glossary of French relocation terms
* **Guides** - Personalized guides for apostilles, pet relocation, mortgages
* **Upload & Verify** - Track your document collection progress
* **Lead Time Planning** - Tasks ordered by how long they take

**Document Types:**

* Visa Cover Letter
* Proof of Sufficient Means (Financial Statement)
* No Work Attestation (Attestation sur l'honneur)
* Proof of Accommodation Letter

**Requirements:**

* France Relocation Assistant (main plugin)
* MemberPress (recommended) or compatible membership plugin
* PHP 7.4+
* WordPress 5.8+

== Installation ==

1. Ensure the France Relocation Assistant plugin is installed and activated
2. Install and configure MemberPress (recommended) for membership management
3. Upload the `france-relocation-member-tools` folder to `/wp-content/plugins/`
4. Activate the plugin through the 'Plugins' menu in WordPress
5. Configure membership levels in MemberPress

== Frequently Asked Questions ==

= What membership plugin do I need? =

We recommend MemberPress for the best experience. The plugin also supports Paid Memberships Pro, Restrict Content Pro, and WooCommerce Memberships.

= Can I test without a membership plugin? =

Yes! Enable "Demo Mode" in settings to test member features without a membership plugin.

= Are documents generated in French or English? =

Documents are generated based on application location. US applications generate English documents; renewals from France generate French documents.

== Changelog ==

= 1.1.8 =
* Fixed: PDF generation now creates proper PDF files instead of HTML print dialogs
* Improved: PDF documents use FRAMT_Simple_PDF class for reliable cross-browser support
* Improved: PDF content properly handles markdown formatting from AI-generated documents

= 1.1.7 =
* Fixed: Plugin initialization moved outside class to prevent deactivation on errors
* Fixed: Activation/deactivation hooks registered before class instantiation
* Improved: Additional error handling layer around entire plugin bootstrap
* Improved: Static failed flag prevents repeated initialization attempts

= 1.1.6 =
* Improved: Defensive error handling throughout plugin initialization
* Improved: Try-catch blocks prevent fatal errors from deactivating plugin
* Improved: File existence checks before loading dependencies
* Improved: Component initialization with graceful degradation
* Improved: Activation process wrapped in error handlers
* Added: Error logging for debugging (when WP_DEBUG is enabled)

= 1.1.5 =
* Fixed: Timeline checkbox properly persists state (fixed re-trigger on API response)
* Fixed: REST API authentication with proper wp_rest nonce for task updates
* Improved: Added processing flag to prevent checkbox double-toggling

= 1.1.4 =
* New: Research Tool - Dedicated Claude chat for France relocation questions
* Fixed: Timeline checkbox now works reliably (fixed duplicate event listeners)
* Changed: Renamed "Guides" to "Custom In-Depth Guides"
* Improved: Event delegation for timeline to prevent re-binding issues

= 1.1.3 =
* Fixed: Timeline event handlers now initialize after AJAX loads dashboard content
* Fixed: Phase toggle and guide links now work correctly

= 1.1.2 =
* Fixed: Guide links now properly navigate to the Guides section within Member Tools

= 1.1.1 =
* Fixed: Phase toggle now works on all phases (not just active)
* Fixed: Guide links now open within the chat frame instead of navigating away
* Improved: Timeline integration with collapsible phase sections

= 1.1.0 =
* New: Main Plugin Bridge - Integration with France Relocation Assistant v3.6.0+ features
* New: Profile sync between Member Tools and main plugin basic profile
* New: Checklist sync - completions now sync to main plugin progress dashboard
* New: Extended rate limits for members using API proxy
* New: Pre-fill Member Tools profile from main plugin onboarding data
* Improved: Better integration with main plugin's new REST API endpoints
* Requires: France Relocation Assistant v3.6.0+

= 1.0.9 =
* Fixed: Navigation functions now correctly use FRAMemberTools.navigateToSection
* Fixed: Glossary accordions now expand/collapse properly
* Fixed: Dashboard action buttons now navigate correctly
* Improved: Glossary terms with full content now display inline (removed non-functional Learn More button)
* New: Upload & Verify feature with full implementation
* New: Document tracking for 7 common visa documents
* Added: Full term details for Apostille displayed inline
* Added: File upload tracking and "I Have This" marking

= 1.0.8 =
* Fixed: Profile and My Documents render functions

= 1.0.0 =
* Initial release
* Dashboard with progress tracking
* Profile management with AI onboarding
* Document generation (4 document types)
* Interactive checklists
* Glossary with French relocation terms
* Guides for apostilles, pets, mortgages
* MemberPress integration

== Upgrade Notice ==

= 1.0.9 =
Important bug fixes for navigation and glossary functionality. Upload & Verify feature now fully implemented.
