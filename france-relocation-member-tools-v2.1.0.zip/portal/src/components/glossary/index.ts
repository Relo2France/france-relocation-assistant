export { default as GlossaryView } from './GlossaryView';
