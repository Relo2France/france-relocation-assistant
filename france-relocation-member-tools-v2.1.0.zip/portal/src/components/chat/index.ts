export { default as KnowledgeBaseChat } from './KnowledgeBaseChat';
