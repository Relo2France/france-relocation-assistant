/**
 * France Relocation Member Tools - Admin JavaScript
 * @package FRA_Member_Tools
 * @since 1.0.0
 */

(function($) {
    'use strict';
    // Admin scripts - placeholder for future admin features
})(jQuery);
